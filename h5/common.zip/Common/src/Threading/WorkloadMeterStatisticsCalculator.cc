
#include "Threading/WorkloadMeterStatisticsCalculator.h"

#include <boost/range/adaptors.hpp>

#include "Logging/StreamableCollection.h"


namespace threading {

const std::chrono::milliseconds WorkloadMeterStatisticsCalculator::kLongTermPollingPeriod(10000);
const std::chrono::milliseconds WorkloadMeterStatisticsCalculator::kShortTermPollingPeriod(1000);

WorkloadMeterStatisticsCalculator::WorkloadMeterStatisticsCalculator(
    const std::string& description,
    const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
    const std::shared_ptr<const math::ThroughputCalculatorsFactory>& throughputCalculatorsFactory,
    const std::shared_ptr<logging::Logger>& logger)
    : description_(description),
      throughputCalculatorsFactory_(throughputCalculatorsFactory),
      logger_(logger),

      stats_(),
      longTermStatisticsCalculator_(
          throughputCalculatorsFactory_->CreateThroughputCalculators<std::string>(kLongTermPollingPeriod)),
      shortTermStatisticsCalculator_(
          throughputCalculatorsFactory_->CreateThroughputCalculators<std::string>(kShortTermPollingPeriod)) {}

WorkloadMeterStatisticsCalculator::~WorkloadMeterStatisticsCalculator() {}

void WorkloadMeterStatisticsCalculator::MeasureWorkPerformed(
    const char* const description, const size_t workPerformed) {
  static constexpr size_t kCallCount = 1;

  std::stringstream stringDescriptionStream;
  stringDescriptionStream << std::hex << static_cast<const void* const>(description);
  auto stringDescription = stringDescriptionStream.str();
  auto tagsAndBytes = std::unordered_map<std::string, system::ByteCount>{
      {stringDescription, workPerformed * system::ByteCountUnit()},
      {stringDescription + "(#)", kCallCount * system::ByteCountUnit()}};

  const auto inserted = stats_.emplace(stringDescription);
  if (inserted.second) {
    _LOG(
        logger_,
        logging::LogLevel::kInfo,
        "[" << description_ << "]: mapping [" << stringDescription << "] to [" << description << "]");
  }

  std::unordered_map<std::string, math::ThroughputCalculation<>> throughputs;
  auto longtermLog = longTermStatisticsCalculator_->UpdateAndTryGetThroughputs(tagsAndBytes, &throughputs);
  if (longtermLog) {
    LogStatistics(logging::LogLevel::kInfo, longTermStatisticsCalculator_->GetPollingPeriod(), throughputs);
  }

  auto shorttermLog = shortTermStatisticsCalculator_->UpdateAndTryGetThroughputs(tagsAndBytes, &throughputs);
  if (shorttermLog) {
    LogStatistics(logging::LogLevel::kInfo, shortTermStatisticsCalculator_->GetPollingPeriod(), throughputs);
  }
}

void WorkloadMeterStatisticsCalculator::LogStatistics(
    const logging::LogLevel logLevel,
    const std::chrono::duration<double>& pollingPeriod,
    const std::unordered_map<std::string, math::ThroughputCalculation<>>& throughputs) const {
  const double pollingPeriodInSeconds = pollingPeriod.count();

  struct nonZeroFilterStruct {
    bool operator()(const std::pair<std::string, math::ThroughputCalculation<>>& pair) const {
      return pair.second.value.value() > 1;
    }
  };

  _LOG(
      logger_,
      logLevel,
      "[" << description_ << "]: over past [" << pollingPeriodInSeconds << "s] Statistics [" << std::setprecision(1)
          << std::fixed
          << logging::StreamableCollectionHelper::CreateStreamableKeyValuePairsCollection(
                 throughputs | boost::adaptors::filtered(nonZeroFilterStruct()), ";")
          << "]");
}

}  // namespace threading

