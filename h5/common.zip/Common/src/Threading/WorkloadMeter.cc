
#include "Threading/WorkloadMeter.h"

#include "Environment/ITimeProvider.h"
#include "System/Assert.h"
#include "System/DebugAssert.h"
#include "System/DebugFail.h"
#include "Threading/IWorkloadMeterStatisticsCalculator.h"
#include "Threading/Thread.h"
#include "Threading/WorkloadMeterStatisticsCalculatorFactory.h"


namespace threading {

WorkloadMeter::Work::Work(TimePoint&& _started, Duration&& _duration, const char* const _description)
    : started(std::move(_started)), duration(std::move(_duration)), description(_description) {}

WorkloadMeter::WorkPerformed::WorkPerformed()
    : buffer(), shortTermWindowStart(buffer.end()), longTermWindowStart(buffer.end()) {}

constexpr size_t WorkloadMeter::kMaxWorkPerformedSamples;

std::shared_ptr<WorkloadMeter> WorkloadMeter::CreateWorkloadMeter(
    const std::string& threadName,
    const std::shared_ptr<const WorkloadMeterStatisticsCalculatorFactory>& workloadMeterStatisticsCalculatorFactory,
    const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
    const Duration& shortTermWindowSize,
    const Duration& longTermWindowSize) {
  std::shared_ptr<WorkloadMeter> instance(new WorkloadMeter(
      threadName, workloadMeterStatisticsCalculatorFactory, timeProvider, shortTermWindowSize, longTermWindowSize));

  return instance;
}

WorkloadMeter::WorkloadMeter(
    const std::string& threadName,
    const std::shared_ptr<const WorkloadMeterStatisticsCalculatorFactory>& workloadMeterStatisticsCalculatorFactory,
    const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
    const Duration& shortTermWindowSize,
    const Duration& longTermWindowSize)
    : timeProvider_{timeProvider},
      shortTermWindowSize_{shortTermWindowSize},
      longTermWindowSize_{longTermWindowSize},
      threadAsserter_{},
      workloadMeterStatisticsCalculator_{
          workloadMeterStatisticsCalculatorFactory->CreateWorkloadMeterStatisticsCalculator(threadName)},
      workPerformed_{},
      totalWorkPerformedInShortTermWindow_{0},
      totalWorkPerformedInLongTermWindow_{0},
      totalUnitsOfWorkPerformedInShortTermWindow_{0},
      totalUnitsOfWorkPerformedInLongTermWindow_{0} {
  _ASSERT(
      shortTermWindowSize > Duration::zero() && longTermWindowSize > Duration::zero() &&
          shortTermWindowSize < longTermWindowSize,
      "Short term window size [" << shortTermWindowSize << "] needs to be less than long term window size ["
                                 << longTermWindowSize << "] and both need to be greater than 0.");

  workPerformed_.buffer.set_capacity(kMaxWorkPerformedSamples);
}

system::ScopeExit WorkloadMeter::MeasureWorkPerformed(const char* const description) {
#if !defined(NDEBUG)
  _SINGLETHREADED_ASSERT_CURRENT_FUNCTION(threadAsserter_);
#endif  // !defined(NDEBUG)

  auto start = timeProvider_->GetSteadyClockTimePoint();
  return system::ScopeExit([start = std::move(start), description, this]() mutable {
    auto duration = timeProvider_->GetSteadyClockTimePoint() - start;

    AddWork(Work(std::move(start), std::move(duration), description));
  });
}

void WorkloadMeter::UpdateWorkloadWindowsNow() {
#if !defined(NDEBUG)
  _SINGLETHREADED_ASSERT_CURRENT_FUNCTION(threadAsserter_);
#endif  // !defined(NDEBUG)

  const auto now = timeProvider_->GetSteadyClockTimePoint();

  UpdateWorkloadWindows(now);
}

IWorkloadProvider::Workloads WorkloadMeter::GetWorkloads() const {
  return IWorkloadProvider::Workloads{
      shortTermWindowSize_,
      longTermWindowSize_,
      GetWorkload(
          totalUnitsOfWorkPerformedInShortTermWindow_, shortTermWindowSize_, totalWorkPerformedInShortTermWindow_),
      GetWorkload(
          totalUnitsOfWorkPerformedInLongTermWindow_, longTermWindowSize_, totalWorkPerformedInLongTermWindow_)};
}

void WorkloadMeter::AddWork(Work&& workPerformed) {
  _DEBUG_ASSERT_OR_RETURN(
      workPerformed.duration >= Duration::zero(),
      "Attempting to add WorkPerformed with negative duration [" << workPerformed.duration << "]");

  const auto now = workPerformed.started + workPerformed.duration;

  UpdateWorkloadWindows(now);

  if (GetCurrentNumberOfItemsInLongTermWindow() == workPerformed_.buffer.capacity()) {
    MakeRoomInWorkPerformedBufferForCurrentThread();
  }

  totalWorkPerformedInShortTermWindow_ += workPerformed.duration.count();
  totalWorkPerformedInLongTermWindow_ += workPerformed.duration.count();
  totalUnitsOfWorkPerformedInShortTermWindow_++;
  totalUnitsOfWorkPerformedInLongTermWindow_++;

  workloadMeterStatisticsCalculator_->MeasureWorkPerformed(workPerformed.description, workPerformed.duration.count());
  workPerformed_.buffer.push_back(std::move(workPerformed));

  const auto bufferEnd = workPerformed_.buffer.end();
  if (workPerformed_.shortTermWindowStart == bufferEnd) {
    workPerformed_.shortTermWindowStart = std::prev(bufferEnd);
  }

  if (workPerformed_.longTermWindowStart == bufferEnd) {
    workPerformed_.longTermWindowStart = std::prev(bufferEnd);
  }
}

void WorkloadMeter::UpdateWorkloadWindows(const TimePoint& now) {
  const auto shortTermWindowStart = now - shortTermWindowSize_;

  EnsureIteratorWithinWindow(
      shortTermWindowStart,
      &workPerformed_.shortTermWindowStart,
      &totalWorkPerformedInShortTermWindow_,
      &totalUnitsOfWorkPerformedInShortTermWindow_);

  const auto longTermWindowStart = now - longTermWindowSize_;

  EnsureIteratorWithinWindow(
      longTermWindowStart,
      &workPerformed_.longTermWindowStart,
      &totalWorkPerformedInLongTermWindow_,
      &totalUnitsOfWorkPerformedInLongTermWindow_);
}

IWorkloadProvider::Workload WorkloadMeter::GetWorkload(
    const size_t numberCalls, const Duration& windowSize, const Duration::rep& totalWorkPerformedInWindow) const {
  const double workloadValue = std::min(static_cast<double>(totalWorkPerformedInWindow) / windowSize.count(), 1.0);
  return Workload{numberCalls, workloadValue};
}

void WorkloadMeter::EnsureIteratorWithinWindow(
    const TimePoint& windowStart,
    WorkPerformedBuffer::iterator* iterator,
    std::atomic<Duration::rep>* totalDuration,
    std::atomic<size_t>* totalNumberOfCalls) const {
  const auto end = workPerformed_.buffer.end();

  while ((*iterator) != end && (((*iterator)->started + (*iterator)->duration) <= windowStart)) {
    (*totalDuration) -= (*iterator)->duration.count();
    (*totalNumberOfCalls)--;
    ++(*iterator);
  }
}

void WorkloadMeter::MakeRoomInWorkPerformedBufferForCurrentThread() {
  // Need to free up one slot:

  const auto durationToRemoveFromWindow = workPerformed_.longTermWindowStart->duration;
  bool removedDurationFromShortTermWindow = false;

  // In the unlikely case that short and long term window point to the same location, we also must update the
  // short term window accounting (usually the long term window start iterator would be pointing to a much earlier
  // entry than its short term counterpart):
  if (workPerformed_.shortTermWindowStart == workPerformed_.longTermWindowStart) {
    totalWorkPerformedInShortTermWindow_ -= durationToRemoveFromWindow.count();
    totalUnitsOfWorkPerformedInShortTermWindow_--;
    ++workPerformed_.shortTermWindowStart;
    removedDurationFromShortTermWindow = true;
  }

  totalWorkPerformedInLongTermWindow_ -= durationToRemoveFromWindow.count();
  totalUnitsOfWorkPerformedInLongTermWindow_--;
  ++workPerformed_.longTermWindowStart;

  _DEBUG_FAIL(
      "A lot of work is being performed on the current thread. The circular buffer capacity of ["
      << kMaxWorkPerformedSamples << "] is not sufficient to hold all samples in the long term "
      << (removedDurationFromShortTermWindow ? "or short term " : "") << "window. Had to remove ["
      << durationToRemoveFromWindow << "] from the long term "
      << (removedDurationFromShortTermWindow ? "and short term " : "") << "window. Long term window ["
      << longTermWindowSize_ << "], short term window [" << shortTermWindowSize_ << "].");
}

size_t WorkloadMeter::GetCurrentNumberOfItemsInLongTermWindow() const {
  return static_cast<size_t>(workPerformed_.buffer.end() - workPerformed_.longTermWindowStart);
}
}  // namespace threading

