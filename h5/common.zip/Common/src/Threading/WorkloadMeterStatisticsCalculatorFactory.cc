
#include "Threading/WorkloadMeterStatisticsCalculatorFactory.h"

#include "Logging/LoggingConfigurationProvider.h"
#include "Threading/NullWorkloadMeterStatisticsCalculator.h"
#include "Threading/WorkloadMeterStatisticsCalculator.h"


namespace threading {

WorkloadMeterStatisticsCalculatorFactory::WorkloadMeterStatisticsCalculatorFactory(
    const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
    const std::shared_ptr<const math::ThroughputCalculatorsFactory>& throughputCalculatorsFactory,
    const std::shared_ptr<logging::Logger>& logger)
    : timeProvider_(timeProvider), throughputCalculatorsFactory_(throughputCalculatorsFactory), logger_(logger) {}

WorkloadMeterStatisticsCalculatorFactory::~WorkloadMeterStatisticsCalculatorFactory() {}

std::shared_ptr<IWorkloadMeterStatisticsCalculator>
WorkloadMeterStatisticsCalculatorFactory::CreateWorkloadMeterStatisticsCalculator(
    const std::string& description) const {
  if (!logging::LoggingConfigurationProvider::debugLoggingEnabled) {
    return std::make_shared<NullWorkloadMeterStatisticsCalculator>();
  } else {
    return std::make_shared<WorkloadMeterStatisticsCalculator>(
        description, timeProvider_, throughputCalculatorsFactory_, logger_);
  }
}

}  // namespace threading

