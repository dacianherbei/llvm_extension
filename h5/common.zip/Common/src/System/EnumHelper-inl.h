
#pragma once

#ifndef SYSTEM_INCLUDE_ENUMHELPER_H_
#error "This file should be included only from EnumHelper.h"
#endif  // SYSTEM_INCLUDE_ENUMHELPER_H_

#include "System/BasicEnum.h"


namespace system {

template <class DestinationType, class SourceType>
boost::optional<DestinationType> EnumHelper::TryCastTo(const SourceType value) {
  DestinationType result;
  if (!system::CheckedEnumTryCast<decltype(result)>(value, &result)) {
    return boost::none;
  }

  return result;
}

}  // namespace system

