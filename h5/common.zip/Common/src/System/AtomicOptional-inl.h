
#pragma once

#include "System/AtomicOptional.h"


namespace system {

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>::AtomicOptional() : inner_(), lock_() {}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>::AtomicOptional(const AtomicOptional<T, TLockType>& other)
    : inner_(other.Load()), lock_() {}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>::AtomicOptional(const boost::optional<T>& value) : inner_(value), lock_() {}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>& AtomicOptional<T, TLockType>::operator=(const AtomicOptional<T, TLockType>& other) {
  Store(other.Load());
  return *this;
}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>& AtomicOptional<T, TLockType>::operator=(const boost::optional<T>& other) {
  std::lock_guard<TLockType> guard(lock_);
  inner_ = other;
  return *this;
}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>& AtomicOptional<T, TLockType>::operator=(boost::optional<T>&& other) {
  std::lock_guard<TLockType> guard(lock_);
  inner_ = std::move(other);
  return *this;
}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>& AtomicOptional<T, TLockType>::operator=(T&& other) {
  std::lock_guard<TLockType> guard(lock_);
  inner_ = std::move(other);
  return *this;
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::operator==(const AtomicOptional<T, TLockType>& other) const {
  const auto otherInner = other.Load();

  std::lock_guard<TLockType> guard(lock_);
  return inner_ == otherInner;
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::operator!=(const AtomicOptional<T, TLockType>& other) const {
  return !(*this == other);
}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>::operator bool() const {
  std::lock_guard<TLockType> guard(lock_);
  return inner_.operator bool();
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::IsLockFree() const {
  return false;
}

template <typename T, typename TLockType>
void AtomicOptional<T, TLockType>::Store(const boost::optional<T>& newValue, const std::memory_order order) {
  std::lock_guard<TLockType> guard(lock_);
  inner_ = newValue;
}

template <typename T, typename TLockType>
void AtomicOptional<T, TLockType>::Store(boost::optional<T>&& newValue, const std::memory_order order) {
  std::lock_guard<TLockType> guard(lock_);
  inner_ = std::move(newValue);
}

template <typename T, typename TLockType>
boost::optional<T> AtomicOptional<T, TLockType>::Load(const std::memory_order order) const {
  std::lock_guard<TLockType> guard(lock_);
  return inner_;
}

template <typename T, typename TLockType>
AtomicOptional<T, TLockType>::operator boost::optional<T>() const {
  std::lock_guard<TLockType> guard(lock_);
  return inner_;
}

template <typename T, typename TLockType>
boost::optional<T> AtomicOptional<T, TLockType>::Exchange(
    const boost::optional<T>& newValue, const std::memory_order order) {
  std::lock_guard<TLockType> guard(lock_);
  const auto previous = inner_;
  inner_ = newValue;
  return previous;
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::CompareExchangeWeak(
    boost::optional<T>& expected,  // NOLINT(runtime/references)
    const boost::optional<T>& desired,
    const std::memory_order success,
    const std::memory_order failure) {
  std::lock_guard<TLockType> guard(lock_);
  if (inner_ == expected) {
    inner_ = desired;
    return true;
  } else {
    expected = inner_;
    return false;
  }
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::CompareExchangeWeak(
    boost::optional<T>& expected,  // NOLINT(runtime/references)
    const boost::optional<T>& desired,
    const std::memory_order order) {
  return CompareExchangeWeak(expected, desired, order, order);
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::CompareExchangeStrong(
    boost::optional<T>& expected,  // NOLINT(runtime/references)
    const boost::optional<T>& desired,
    const std::memory_order success,
    const std::memory_order failure) {
  boost::optional<T> localExpected = expected;
  do {
    if (CompareExchangeWeak(expected, desired, success, failure)) {
      return true;
    }
    // Handle spurious failure, where 'expected' does equal 'inner_' but did return false
    // For a discussion about the underlying mechanics, see here:
    // http://www.codeproject.com/Articles/808305/Understand-std-atomic-compare-exchange-weak-in-Cpl

    // CompareExchangeWeak returned false, 'expected' now points to same object as 'inner_', therefore, if 'expected'
    // equals 'localExpected' then we know we are dealing with a spuirous failure and should continue trying:
  } while (expected == localExpected);
  return false;
}

template <typename T, typename TLockType>
bool AtomicOptional<T, TLockType>::CompareExchangeStrong(
    boost::optional<T>& expected,  // NOLINT(runtime/references)
    const boost::optional<T>& desired,
    const std::memory_order order) {
  return CompareExchangeStrong(expected, desired, order, order);
}

template <typename T, typename TLockType>
bool operator==(const boost::optional<T>& left, const AtomicOptional<T, TLockType>& right) {
  return right == left;
}

template <typename T, typename TLockType>
bool operator!=(const boost::optional<T>& left, const AtomicOptional<T, TLockType>& right) {
  return right != left;
}

}  // namespace system

