
#include "System/BitRateUtilities.h"


namespace system {

BitsPerSecond BitRateUtilities::ToBitsPerSecond(const KiloBitsPerSecond& kiloBitsPerSecondValue) {
  return kiloBitsPerSecondValue.t * 1000 * BitsPerSecondUnit();
}

KiloBitsPerSecond BitRateUtilities::ToKiloBitsPerSecond(const BitsPerSecond& bitsPerSecondValue) {
  return KiloBitsPerSecond(bitsPerSecondValue.value() / 1000);
}

}  // namespace system

