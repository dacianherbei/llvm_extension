
#pragma once

#include <algorithm>
#include <map>
#include <stdexcept>
#include <string>

#include "Exceptions/ExceptionCatcherFactory.h"
#include "System/TrackingSharedPtr.h"


namespace system {

template <typename TValueType>
const std::shared_ptr<exceptions::IStackTraceProvider> TrackingSharedPtr<TValueType>::stackTraceProvider_ =
    exceptions::ExceptionCatcherFactory(std::make_shared<logging::Logger>()).CreateStackTraceProvider();

template <typename TValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr()
    : stackTraceByInstance_(std::make_shared<container::ThreadsafeLookupTable<void*, std::string>>()), pointer_() {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(std::nullptr_t)
    : stackTraceByInstance_(std::make_shared<container::ThreadsafeLookupTable<void*, std::string>>()), pointer_() {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(const TrackingSharedPtr& other)
    : stackTraceByInstance_(other.stackTraceByInstance_), pointer_(other.pointer_) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    const TrackingSharedPtr<TOtherValueType>& other,
    typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(other.stackTraceByInstance_), pointer_(other.pointer_) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    const std::shared_ptr<TValueType>& p, const std::shared_ptr<StackTraceByInstanceType>& stackTraceByInstance)
    : stackTraceByInstance_(stackTraceByInstance), pointer_(p) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    const std::shared_ptr<TOtherValueType>& p,
    const std::shared_ptr<StackTraceByInstanceType>& stackTraceByInstance,
    typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(stackTraceByInstance), pointer_(p) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    std::shared_ptr<TOtherValueType>&& p,
    typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(std::make_shared<StackTraceByInstanceType>()), pointer_(std::move(p)) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    std::unique_ptr<TOtherValueType>&& p,
    typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(std::make_shared<StackTraceByInstanceType>()), pointer_(std::move(p)) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    TOtherValueType* p, typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(std::make_shared<StackTraceByInstanceType>()), pointer_(p) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType, typename TDeleterType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(
    TOtherValueType* p,
    TDeleterType d,
    typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type)
    : stackTraceByInstance_(std::make_shared<StackTraceByInstanceType>()), pointer_(p, d) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
template <typename TOtherValueType>
TrackingSharedPtr<TValueType>::TrackingSharedPtr(TrackingSharedPtr<TOtherValueType> const& own, TValueType* p)
    : stackTraceByInstance_(own->stackTraceByInstance_),
      pointer_(static_cast<std::shared_ptr<TOtherValueType>>(own), p) {
  stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  _Enable_tracking_shared(this, pointer_.get());
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::~TrackingSharedPtr() {
  if (stackTraceByInstance_) {
    stackTraceByInstance_->RemoveMapping(this);
  }
}

template <typename TValueType>
TrackingSharedPtr<TValueType> TrackingSharedPtr<TValueType>::operator=(const TrackingSharedPtr<TValueType>& other) {
  this->pointer_ = other.pointer_;
  this->stackTraceByInstance_ = other.stackTraceByInstance_;
  this->stackTraceByInstance_->Insert(this, stackTraceProvider_->GetStackTrace());
  return *this;
}

template <typename TValueType>
TrackingSharedPtr<TValueType> TrackingSharedPtr<TValueType>::operator=(TrackingSharedPtr<TValueType>&& other) {
  this->pointer_ = std::move(other.pointer_);
  other.stackTraceByInstance_->Insert(this, other.stackTraceByInstance_->ValueFor(&other));
  other.stackTraceByInstance_->RemoveMapping(&other);
  this->stackTraceByInstance_ = std::move(other.stackTraceByInstance_);
  return *this;
}

template <typename TValueType>
TrackingSharedPtr<TValueType> TrackingSharedPtr<TValueType>::operator=(std::nullptr_t) {
  reset();
  return *this;
}

template <typename TValueType>
template <typename TInternalValueType, typename TOtherValueType>
typename std::enable_if<
    std::is_convertible<TOtherValueType*, TInternalValueType*>::value,
    TrackingSharedPtr<TInternalValueType>&>::type
TrackingSharedPtr<TValueType>::operator=(const TrackingSharedPtr<TOtherValueType>& other) {
  *this = std::move(dynamic_pointer_cast<TValueType, TOtherValueType>(other));
  return *this;
}

template <typename TValueType>
template <typename TInternalValueType, typename TOtherValueType>
typename std::enable_if<
    std::is_convertible<TOtherValueType*, TInternalValueType*>::value,
    TrackingSharedPtr<TInternalValueType>&>::type
TrackingSharedPtr<TValueType>::operator=(TrackingSharedPtr<TOtherValueType>&& other) {
  *this = std::move(dynamic_pointer_cast<TValueType, TOtherValueType>(other));
  other.stackTraceByInstance_->RemoveMapping(&other);
  other.pointer_ = nullptr;
  other.stackTraceByInstance_ = nullptr;
  return *this;
}

template <typename TValueType>
void TrackingSharedPtr<TValueType>::reset() {
  TrackingSharedPtr<TValueType>().swap(*this);
}

template <typename TValueType>
TValueType& TrackingSharedPtr<TValueType>::operator*() const {
  return *pointer_.get();
}

template <typename TValueType>
TValueType* TrackingSharedPtr<TValueType>::operator->() const {
  return pointer_.get();
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::operator bool() const {
  return pointer_ != nullptr;
}

template <typename TValueType>
TValueType* TrackingSharedPtr<TValueType>::get() const {
  return pointer_.get();
}

template <typename TValueType>
bool TrackingSharedPtr<TValueType>::unique() const {
  return pointer_.unique();
}

template <typename TValueType>
long TrackingSharedPtr<TValueType>::use_count() const {  // NOLINT(runtime/int)
  return pointer_.use_count();
}

template <typename TValueType>
void TrackingSharedPtr<TValueType>::swap(TrackingSharedPtr& other) {
  stackTraceByInstance_.swap(other.stackTraceByInstance_);
  pointer_.swap(other.pointer_);

  const auto stackTrace = stackTraceProvider_->GetStackTrace();
  other.stackTraceByInstance_->RemoveMapping(this);
  other.stackTraceByInstance_->Insert(&other, stackTrace);

  stackTraceByInstance_->RemoveMapping(&other);
  stackTraceByInstance_->Insert(this, stackTrace);
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::operator std::shared_ptr<TValueType>() const {
  return pointer_;
}

template <typename TValueType>
TrackingSharedPtr<TValueType>::operator std::weak_ptr<TValueType>() const {
  return std::weak_ptr<TValueType>(pointer_);
}

template <typename TValueType>
template <
    typename TOtherValueType,
    typename std::enable_if<std::is_convertible<TValueType*, TOtherValueType*>::value>::type>
TrackingSharedPtr<TValueType>::operator std::shared_ptr<TOtherValueType>() const {
  return pointer_;
}

template <typename TValueType>
template <
    typename TOtherValueType,
    typename std::enable_if<std::is_convertible<TValueType*, TOtherValueType*>::value>::type>
TrackingSharedPtr<TValueType>::operator std::weak_ptr<TOtherValueType>() const {
  return std::weak_ptr<TOtherValueType>(pointer_);
}

template <typename TValueType>
template <class TOtherValueType>
bool TrackingSharedPtr<TValueType>::owner_before(const TrackingSharedPtr& ptr) const {
  return pointer_.owner_before(ptr.pointer_);
}

template <typename TValueType>
template <class TOtherValueType>
bool TrackingSharedPtr<TValueType>::owner_before(const std::shared_ptr<TOtherValueType>& ptr) const {
  return pointer_.owner_before(ptr);
}

template <typename TValueType>
template <class TDeleterType, class TOtherValueType>
TDeleterType* TrackingSharedPtr<TValueType>::get_deleter(TrackingSharedPtr<TOtherValueType> const& ptr) const {
  return pointer_.get_deleter();
}

template <typename TValueType>
std::map<void*, std::string> TrackingSharedPtr<TValueType>::GetStackTraceMap() const {
  std::map<void*, std::string> returnMap;

  auto populateMap = [&returnMap](void* key, const std::string& value) { returnMap[key] = value; };

  stackTraceByInstance_->Visit(populateMap);

  return returnMap;
}

template <typename TValueType>
std::shared_ptr<TValueType> TrackingSharedPtr<TValueType>::GetSharedPointer() const {
  return pointer_;
}

}  // namespace system

