
#pragma once

#include "System/NumericLimits.h"


namespace system {

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsDuration<U, U> NumericLimits<T>::Min() {
  return U::min();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsBoostUnitsQuanity<U, U> NumericLimits<T>::Min() {
  return std::numeric_limits<typename U::value_type>::min() * typename U::unit_type();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfSpecialized<U, U> NumericLimits<T>::Min() {
  return std::numeric_limits<U>::min();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfNotSpecialized<U, U> NumericLimits<T>::Min() {
  static_assert(!std::is_same<T, T>::value, "Incompatible type");
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfHasNestedType<U, U> NumericLimits<T>::Min() {
  return U(Min<typename ExtractValueType<U>::type>());
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfSpecialized<U, U> NumericLimits<T>::Lowest() {
  return std::numeric_limits<U>::lowest();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsDuration<U, U> NumericLimits<T>::Lowest() {
  return U::min();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsBoostUnitsQuanity<U, U> NumericLimits<T>::Lowest() {
  return std::numeric_limits<typename U::value_type>::lowest() * typename U::unit_type();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfNotSpecialized<U, U> NumericLimits<T>::Lowest() {
  static_assert(!std::is_same<T, T>::value, "Incompatible type");
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfHasNestedType<U, U> NumericLimits<T>::Lowest() {
  return U(Lowest<typename ExtractValueType<U>::type>());
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsDuration<U, U> NumericLimits<T>::Max() {
  return U::max();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsBoostUnitsQuanity<U, U> NumericLimits<T>::Max() {
  return std::numeric_limits<typename U::value_type>::max() * typename U::unit_type();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfSpecialized<U, U> NumericLimits<T>::Max() {
  return std::numeric_limits<U>::max();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfNotSpecialized<U, U> NumericLimits<T>::Max() {
  static_assert(!std::is_same<T, T>::value, "Incompatible type");
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfHasNestedType<U, U> NumericLimits<T>::Max() {
  return U(Max<typename ExtractValueType<U>::type>());
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsDuration<U, int> NumericLimits<T>::Digits() {
  return NumericLimits<decltype(U().count())>::Digits();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsBoostUnitsQuanity<U, int> NumericLimits<T>::Digits() {
  return std::numeric_limits<typename U::value_type>::digits;
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfSpecialized<U, int> NumericLimits<T>::Digits() {
  return std::numeric_limits<U>::digits;
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfNotSpecialized<U, int> NumericLimits<T>::Digits() {
  static_assert(!std::is_same<T, T>::value, "Incompatible type");
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfHasNestedType<U, int> NumericLimits<T>::Digits() {
  return Digits<typename ExtractValueType<U>::type>();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsDuration<U, bool> NumericLimits<T>::IsSigned() {
  return NumericLimits<decltype(U().count())>::IsSigned();
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfIsBoostUnitsQuanity<U, bool> NumericLimits<T>::IsSigned() {
  return std::numeric_limits<typename U::value_type>::is_signed;
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfSpecialized<U, bool> NumericLimits<T>::IsSigned() {
  return std::numeric_limits<U>::is_signed;
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfNotSpecialized<U, bool> NumericLimits<T>::IsSigned() {
  static_assert(!std::is_same<T, T>::value, "Incompatible type");
}

template <typename T>
template <typename U>
constexpr typename NumericLimits<T>::template EnableIfHasNestedType<U, bool> NumericLimits<T>::IsSigned() {
  return IsSigned<typename ExtractValueType<U>::type>();
}

}  // namespace system

