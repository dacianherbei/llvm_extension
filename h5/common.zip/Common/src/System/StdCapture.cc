
#include "System/StdCapture.h"

#include "System/DebugFail.h"
#include "System/ScopeExit.h"
#include "Threading/Thread.h"

#if defined(_MSC_VER)
#include <io.h>
#define popen _popen
#define pclose _pclose
#define stat _stat
#define dup _dup
#define dup2 _dup2
#define fileno _fileno
#define close _close
#define pipe _pipe
#define eof _eof
#define STD_OUT_FD _fileno(stdout)
#define STD_ERR_FD _fileno(stderr)
#else  // defined(_MSC_VER)
#include <unistd.h>
#define STD_OUT_FD fileno(stdout)
#define STD_ERR_FD fileno(stderr)
#endif  // defined(_MSC_VER)


namespace system {

bool StdCapture::capturing_ = false;
std::atomic_flag StdCapture::anInstanceExists_ = ATOMIC_FLAG_INIT;

StdCapture::StdCapture() : StdCapture(StdCaptureMode::kBoth) {}

StdCapture::StdCapture(const StdCaptureMode& captureMode) : captureMode_(captureMode), oldStdOut_(0), oldStdErr_(0) {
  pipe_[READ] = 0;
  pipe_[WRITE] = 0;
  AcquireGlobalLock();
  Init();
}

StdCapture::~StdCapture() {
  if (capturing_) {
    EndCapture();
  }

  if (oldStdOut_ > 0) {
    secure_close(&oldStdOut_);
  }

  if (oldStdErr_ > 0) {
    secure_close(&oldStdErr_);
  }

  if (pipe_[READ] > 0) {
    secure_close(&pipe_[READ]);
  }

#if defined(_MSC_VER)
  if (pipe_[WRITE] > 0) {
    secure_close(&pipe_[WRITE]);
  }
#endif  // defined(_MSC_VER)

  ReleaseGlobalLock();
}

void StdCapture::Init() {
  // make stdout & stderr streams unbuffered
  // so that we don't need to flush the streams
  // before capture and after capture
  // (fflush can cause a deadlock if the stream is currently being
  std::lock_guard<::threading::Mutex> lock(mutex_);
  if (static_cast<int>(captureMode_) & static_cast<int>(StdCaptureMode::kStdout)) {
    setvbuf(stdout, NULL, _IONBF, 0);
  }
  if (static_cast<int>(captureMode_) & static_cast<int>(StdCaptureMode::kStderr)) {
    setvbuf(stderr, NULL, _IONBF, 0);
  }
}

void StdCapture::BeginCapture() {
  std::lock_guard<::threading::Mutex> lock(mutex_);
  if (capturing_) {
    return;
  }

  secure_pipe(pipe_);
  if (static_cast<int>(captureMode_) & static_cast<int>(StdCaptureMode::kStdout)) {
    oldStdOut_ = secure_dup(STD_OUT_FD);
    secure_dup2(pipe_[WRITE], STD_OUT_FD);
  }
  if (static_cast<int>(captureMode_) & static_cast<int>(StdCaptureMode::kStderr)) {
    oldStdErr_ = secure_dup(STD_ERR_FD);
    secure_dup2(pipe_[WRITE], STD_ERR_FD);
  }
  capturing_ = true;
#if !defined(_MSC_VER)
  secure_close(&pipe_[WRITE]);
#endif  // !defined(_MSC_VER)
}

bool StdCapture::IsCapturing() {
  std::lock_guard<::threading::Mutex> lock(mutex_);
  return capturing_;
}

bool StdCapture::EndCapture() {
  std::lock_guard<::threading::Mutex> lock(mutex_);
  if (!capturing_) {
    return capturing_;
  }

  captured_.clear();
  if (oldStdOut_ > 0) {
    secure_dup2(oldStdOut_, STD_OUT_FD);
  }
  if (oldStdErr_ > 0) {
    secure_dup2(oldStdErr_, STD_ERR_FD);
  }

  const int kBufferSize = 1025;
  char buf[kBufferSize];
  int bytesRead = 0;
  bool fdBlocked(false);
  do {
    bytesRead = 0;
    fdBlocked = false;
#if defined(_MSC_VER)
    if (!eof(pipe_[READ])) {
      bytesRead = _read(pipe_[READ], buf, kBufferSize - 1);
    }
#else   // defined(_MSC_VER)
    bytesRead = read(pipe_[READ], buf, kBufferSize - 1);
#endif  // defined(_MSC_VER)
    if (bytesRead > 0) {
      buf[bytesRead] = 0;
      captured_ += buf;
    } else if (bytesRead < 0) {
      fdBlocked = (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR);
      if (fdBlocked) {
        threading::Thread::SleepFor(std::chrono::milliseconds(10));
      }
    }
  } while (fdBlocked || bytesRead == (kBufferSize - 1));

  if (oldStdOut_ > 0) {
    secure_close(&oldStdOut_);
  }
  if (oldStdErr_ > 0) {
    secure_close(&oldStdErr_);
  }
  secure_close(&pipe_[READ]);
#if defined(_MSC_VER)
  secure_close(&pipe_[WRITE]);
#endif  // defined(_MSC_VER)
  capturing_ = false;
  return capturing_;
}

std::string StdCapture::GetCapture() {
  std::lock_guard<::threading::Mutex> lock(mutex_);
  return captured_;
}

int StdCapture::secure_dup(int src) {
  int returnValue = -1;
  bool fdBlocked = false;
  uint32_t iteration = 0;

  do {
    returnValue = dup(src);
    fdBlocked = (errno == EINTR || errno == EBUSY);
    if (fdBlocked) {
      threading::Thread::SleepFor(std::chrono::milliseconds(10));
    }
  } while (returnValue < 0 && iteration++ < kMaxIterations);
  return returnValue;
}

void StdCapture::secure_pipe(int* pipes) {
  int returnValue = -1;
  bool fdBlocked = false;
  uint32_t iteration = 0;

  do {
#if defined(_MSC_VER)
    returnValue = pipe(pipes, 65536, O_BINARY);
#else   // defined(_MSC_VER)
    returnValue = pipe(pipes) == -1;
#endif  // defined(_MSC_VER)
    fdBlocked = (errno == EINTR || errno == EBUSY);
    if (fdBlocked) {
      threading::Thread::SleepFor(std::chrono::milliseconds(10));
    }
  } while (returnValue < 0 && iteration++ < kMaxIterations);
}

void StdCapture::secure_dup2(int src, int dest) {
  int returnValue = -1;
  bool fdBlocked = false;
  uint32_t iteration = 0;

  do {
    returnValue = dup2(src, dest);
    fdBlocked = (errno == EINTR || errno == EBUSY);
    if (fdBlocked) {
      threading::Thread::SleepFor(std::chrono::milliseconds(10));
    }
  } while (returnValue < 0 && iteration++ < kMaxIterations);
}

void StdCapture::secure_close(int* fd) {
  int returnValue = -1;
  bool fdBlocked = false;
  uint32_t iteration = 0;

  do {
    returnValue = close(*fd);
    fdBlocked = (errno == EINTR);
    if (fdBlocked) {
      threading::Thread::SleepFor(std::chrono::milliseconds(10));
    }
  } while (returnValue < 0 && iteration++ < kMaxIterations);

  *fd = -1;
}

void StdCapture::AcquireGlobalLock() {
  bool alreadyExisted = anInstanceExists_.test_and_set();

  if (alreadyExisted) {
    _DEBUG_FAIL("Tried to construct instance of StdCapture but an instance currently exists.");
  }
}

void StdCapture::ReleaseGlobalLock() { anInstanceExists_.clear(); }

}  // namespace system

