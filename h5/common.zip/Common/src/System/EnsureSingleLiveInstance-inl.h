
#pragma once

#include "System/EnsureSingleLiveInstance.h"

#include <sstream>

#include <boost/type_index.hpp>

#include "Logging/Logger.h"
#include "System/Fail.h"


namespace system {

template <typename TSubclass>
std::atomic<int> EnsureSingleLiveInstance<TSubclass>::instanceCount_(0);

template <typename TSubclass>
EnsureSingleLiveInstance<TSubclass>::EnsureSingleLiveInstance(
    const boost::optional<std::shared_ptr<logging::Logger>>& logger) {
  const auto currentNumberOfInstances = instanceCount_++;
  if (currentNumberOfInstances == 0) {
    return;
  }

  std::ostringstream result;
  result << "Class of type [" << boost::typeindex::type_id<TSubclass>().pretty_name()
         << "] should only ever have a single live instance but found [" << currentNumberOfInstances
         << "] live instances.";
  const auto errorMessage = result.str();

  if (logger) {
    _LOG(*logger, logging::LogLevel::kWarn, errorMessage);
  } else {
    _FAIL(errorMessage);
  }
}

template <typename TSubclass>
EnsureSingleLiveInstance<TSubclass>::~EnsureSingleLiveInstance() {
  --instanceCount_;
}

}  // namespace system

