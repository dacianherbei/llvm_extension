
#include "System/ScopeExit.h"


namespace system {

ScopeExit::ScopeExit(FunctionOnExit&& functionOnExit) : functionOnExit_(std::move(functionOnExit)), dismissed_(false) {}

ScopeExit::ScopeExit(ScopeExit&& source)
    : functionOnExit_(std::move(source.functionOnExit_)), dismissed_(source.dismissed_) {
  source.dismissed_ = true;
}

ScopeExit::~ScopeExit() {
  if (!dismissed_) {
    functionOnExit_();
  }
}

void ScopeExit::Dismiss() { dismissed_ = true; }

}  // namespace system

