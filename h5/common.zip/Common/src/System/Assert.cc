
#include "System/Assert.h"

#include <iostream>
#include <sstream>

#include "System/CrashReport.h"

namespace boost {

void assertion_failed(char const* expr, char const* function, char const* file, long line) {  // NOLINT(runtime/int)
  std::stringstream message, signature, backtrace, message2;

  message << "***** Internal Program Error - assertion (" << expr << ") failed in " << function;
  signature << "Assertion Failed";
  backtrace << "0 " << function << std::endl << "@ " << file << ":" << line << std::endl;
  message2 << expr;

  ::system::SetCrashInfo(message.str(), signature.str(), backtrace.str(), message2.str());

#ifdef UNDER_CE
  // The Windows CE CRT library does not have abort() so use exit(-1) instead.
  std::exit(-1);
#else
  std::abort();
#endif
}

void assertion_failed_msg(
    char const* expr,
    char const* msg,
    char const* function,
    char const* file,
    long line) {  // NOLINT(runtime/int)
  std::stringstream message, signature, backtrace, message2;

  message << "***** Internal Program Error - assertion (" << expr << ") failed in " << function;
  signature << msg;
  backtrace << "0 " << function << std::endl << "@ " << file << ":" << line << std::endl;
  message2 << expr;

  ::system::SetCrashInfo(message.str(), signature.str(), backtrace.str(), message2.str());

#ifdef UNDER_CE
  // The Windows CE CRT library does not have abort() so use exit(-1) instead.
  std::exit(-1);
#else
  std::abort();
#endif
}

}  // namespace boost
