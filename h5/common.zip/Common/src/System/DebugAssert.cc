
#include "System/DebugAssert.h"
#include "Environment/EnvironmentVariable.h"


namespace system {

const char* const DebugAssert::kAssertDisableEnvironmentVariableName = "_DISABLE_DEBUG_ASSERT";
const char* const DebugAssert::kAssertThrottleLoggingDisableEnvironmentVariableName =
    "_DISABLE_THROTTLE_LOGGING_DEBUG_ASSERT";
std::atomic<bool> DebugAssert::enabled_(DebugAssert::GetInitialEnabledValue());
std::atomic<bool> DebugAssert::assertEnablementCurrentlyOverridden_(false);
std::atomic<bool> DebugAssert::throttleLogging_(DebugAssert::GetInitialThrottleLoggingValue());
std::atomic<bool> DebugAssert::throttleLoggingCurrentlyOverridden_(false);

bool DebugAssert::IsThrottleLoggingEnabled() { return throttleLogging_; }

ScopeExit DebugAssert::SetThrottleLoggingInScope(const bool value) {
  _ASSERT(!throttleLoggingCurrentlyOverridden_.exchange(true), "The value can only be overriden once at a time.");
  const bool oldValue = throttleLogging_.exchange(value);

  return ScopeExit{[oldValue] {
    throttleLogging_ = oldValue;
    throttleLoggingCurrentlyOverridden_ = false;
  }};
}

void DebugAssert::SetThrottleLoggingGlobally(const bool value) {
  _ASSERT(
      !throttleLoggingCurrentlyOverridden_.exchange(true),
      "Cannot change the value permanently while an override is in effect.");

  throttleLogging_ = value;

  throttleLoggingCurrentlyOverridden_ = false;
}

bool DebugAssert::IsEnabled() { return enabled_; }

ScopeExit DebugAssert::SetEnabledInScope(const bool value) {
  _ASSERT(
      !assertEnablementCurrentlyOverridden_.exchange(true), "The value can only be overriden once at a time.");
  const bool oldValue = enabled_.exchange(value);

  return ScopeExit{[oldValue] {
    enabled_ = oldValue;
    assertEnablementCurrentlyOverridden_ = false;
  }};
}

void DebugAssert::SetEnabledGlobally(const bool value) {
  _ASSERT(
      !assertEnablementCurrentlyOverridden_.exchange(true),
      "Cannot change the value permanently while an override is in effect.");

  enabled_ = value;

  assertEnablementCurrentlyOverridden_ = false;
}

bool DebugAssert::GetInitialEnabledValue() {
#if defined(NDEBUG)
  return false;
#else
  return !environment::EnvironmentVariable::WithName(kAssertDisableEnvironmentVariableName).Exists();
#endif  // defined(NDEBUG)
}

bool DebugAssert::GetInitialThrottleLoggingValue() {
  return !environment::EnvironmentVariable::WithName(kAssertThrottleLoggingDisableEnvironmentVariableName).Exists();
}

}  // namespace system

