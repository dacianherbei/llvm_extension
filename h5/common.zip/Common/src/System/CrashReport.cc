
#include "System/CrashReport.h"

#include <cstring>
#include <iostream>

#ifdef __APPLE__

const char* __crashreporter_info__ = 0;
asm(".desc __crashreporter_info__, 0x10");

#define CRASH_ANNOTATION __attribute__((section("__DATA,__crash_info")))
#define CRASH_VERSION 4

char messageBuffer[2048], signatureBuffer[2048], backtraceBuffer[4096], message2Buffer[2048];

crashInfoT gCRAnnotations CRASH_ANNOTATION = {CRASH_VERSION, 0, 0, 0, 0, 0, 0};

#endif


namespace system {

void SetCrashInfo(
    const std::string& message,
    const std::string& signature,
    const std::string& backtrace,
    const std::string& message2) {
  std::cerr << message << std::endl << signature << std::endl << message2 << std::endl << backtrace << std::endl;

#ifdef __APPLE__

  strncpy(messageBuffer, message.c_str(), sizeof(messageBuffer) - 1);
  strncpy(signatureBuffer, signature.c_str(), sizeof(signatureBuffer) - 1);
  strncpy(backtraceBuffer, backtrace.c_str(), sizeof(backtraceBuffer) - 1);
  strncpy(message2Buffer, message2.c_str(), sizeof(message2Buffer) - 1);

  messageBuffer[sizeof(messageBuffer) - 1] = '\0';
  signatureBuffer[sizeof(signatureBuffer) - 1] = '\0';
  backtraceBuffer[sizeof(backtraceBuffer) - 1] = '\0';
  message2Buffer[sizeof(message2Buffer) - 1] = '\0';

  __crashreporter_info__ = messageBuffer;

  gCRAnnotations.message = messageBuffer;
  gCRAnnotations.signature = signatureBuffer;
  gCRAnnotations.backtrace = backtraceBuffer;
  gCRAnnotations.message2 = message2Buffer;

#endif
}

}  // namespace system

