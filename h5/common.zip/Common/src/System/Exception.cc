
#include "System/Exception.h"

#include <sstream>
#include <stdexcept>


namespace system {

Exception::Exception(const std::string& message) : message_(message) {}

Exception::Exception(std::string&& message) : message_(std::move(message)) {}

Exception::Exception(const std::string& errorString, const char* file, int line) {
  _FORMAT_ERROR_MESSAGE(message_, file, line, errorString);
}

Exception::Exception(Exception&& that) : message_(std::move(that.message_)) {}

::system::Exception& Exception::operator=(Exception&& that) {
  message_ = std::move(that.message_);
  return *this;
}

const char* Exception::what() const throw() { return message_.c_str(); }

const std::string& Exception::GetMessageString() const { return message_; }

}  // namespace system

