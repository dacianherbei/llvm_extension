
#pragma once

#ifndef SYSTEM_INCLUDE_RELATIONALOPERATORSUTILITIES_H_
#error "This file should be included only from RelationalOperatorsUtilities.h"
#endif  // SYSTEM_INCLUDE_RELATIONALOPERATORSUTILITIES_H_

#include <cstring>
#include <type_traits>


namespace system {

template <class T>
bool RelationalOperatorsUtilities::IsBinaryEqual(const T& lhs, const T& rhs) {
  static_assert(std::is_class<T>::value, "T should be struct");

  // TODO(DP): Add the following when we'll update Debian (or gcc-4.9.2)
  // NOTE(DP): On Ubuntu 16.04.5 (gcc-5.4.0) it works perfectly
  // static_assert(std::is_trivially_copyable<T>::value, "T should be trivially-copyable");

  return std::memcmp(&lhs, &rhs, sizeof(T)) == 0;
}
}  // namespace system

