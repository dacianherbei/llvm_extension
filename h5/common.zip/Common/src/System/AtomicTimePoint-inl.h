
#pragma once


namespace system {

#if defined(_NEED_CUSTOM_ATOMIC_TIME_POINT)

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>::AtomicTimePoint() {}

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>::AtomicTimePoint(TimePointType timePoint)
    : atomicTimePointInTicks_(ToTicks(timePoint)) {}

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>& AtomicTimePoint<TClock, TDuration>::operator=(TimePointType timePoint) {
  atomicTimePointInTicks_ = ToTicks(timePoint);
  return *this;
}

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>& AtomicTimePoint<TClock, TDuration>::operator=(TimePointType timePoint) volatile {
  atomicTimePointInTicks_ = ToTicks(timePoint);
  return *this;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::is_lock_free() const {
  return atomicTimePointInTicks_.is_lock_free();
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::is_lock_free() const volatile {
  return atomicTimePointInTicks_.is_lock_free();
}

template <typename TClock, typename TDuration>
void AtomicTimePoint<TClock, TDuration>::store(TimePointType timePoint, std::memory_order order) {
  atomicTimePointInTicks_.store(ToTicks(timePoint), order);
}

template <typename TClock, typename TDuration>
void AtomicTimePoint<TClock, TDuration>::store(TimePointType timePoint, std::memory_order order) volatile {
  atomicTimePointInTicks_.store(ToTicks(timePoint), order);
}

template <typename TClock, typename TDuration>
typename AtomicTimePoint<TClock, TDuration>::TimePointType AtomicTimePoint<TClock, TDuration>::load(
    std::memory_order order) const {
  return ToTimePoint(atomicTimePointInTicks_.load(order));
}

template <typename TClock, typename TDuration>
typename AtomicTimePoint<TClock, TDuration>::TimePointType AtomicTimePoint<TClock, TDuration>::load(
    std::memory_order order) const volatile {
  return ToTimePoint(atomicTimePointInTicks_.load(order));
}

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>::operator TimePointType() const {
  return ToTimePoint(static_cast<TickType>(atomicTimePointInTicks_));
}

template <typename TClock, typename TDuration>
AtomicTimePoint<TClock, TDuration>::operator TimePointType() const volatile {
  return ToTimePoint(static_cast<TickType>(atomicTimePointInTicks_));
}

template <typename TClock, typename TDuration>
typename AtomicTimePoint<TClock, TDuration>::TimePointType AtomicTimePoint<TClock, TDuration>::exchange(
    TimePointType timePoint, std::memory_order order) {
  return ToTimePoint(atomicTimePointInTicks_.exchange(ToTicks(timePoint), order));
}

template <typename TClock, typename TDuration>
typename AtomicTimePoint<TClock, TDuration>::TimePointType AtomicTimePoint<TClock, TDuration>::exchange(
    TimePointType timePoint, std::memory_order order) volatile {
  return ToTimePoint(atomicTimePointInTicks_.exchange(ToTicks(timePoint), order));
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_weak(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order success,
    std::memory_order failure) {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_weak(expectedTick, ToTicks(desired), success, failure);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_weak(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order success,
    std::memory_order failure) volatile {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_weak(expectedTick, ToTicks(desired), success, failure);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_weak(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order order) {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_weak(expectedTick, ToTicks(desired), order);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_weak(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order order) volatile {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_weak(expectedTick, ToTicks(desired), order);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_strong(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order success,
    std::memory_order failure) {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_strong(expectedTick, ToTicks(desired), success, failure);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_strong(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order success,
    std::memory_order failure) volatile {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_strong(expectedTick, ToTicks(desired), success, failure);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_strong(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order order) {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_strong(expectedTick, ToTicks(desired), order);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

template <typename TClock, typename TDuration>
bool AtomicTimePoint<TClock, TDuration>::compare_exchange_strong(
    TimePointType& expected,  // NOLINT(runtime/references)
    TimePointType desired,
    std::memory_order order) volatile {
  TickType expectedTick = ToTicks(expected);
  const bool result = atomicTimePointInTicks_.compare_exchange_strong(expectedTick, ToTicks(desired), order);
  if (!result) {
    expected = ToTimePoint(expectedTick);
  }
  return result;
}

#endif  // _NEED_CUSTOM_ATOMIC_TIME_POINT

}  // namespace system

