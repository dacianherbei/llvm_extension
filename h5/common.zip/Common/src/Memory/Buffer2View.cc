
#include "Memory/Buffer2View.h"

#include "Memory/Buffer2.h"
#include "System/DebugAssert.h"
#include "System/DebugFail.h"


namespace memory {

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::Buffer2View(const Buffer2& buffer)
    : buffer_(&buffer), size_(buffer_->GetSize()), currentFragmentIndex_(0), currentFragmentOffset_(0) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(buffer.moveAsserter_);
  IncrementViewCount();
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::Buffer2View(const Buffer2& buffer, const size_t offset, const size_t size)
    : buffer_(&buffer), size_(buffer.GetSize()), currentFragmentIndex_(0), currentFragmentOffset_(0) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(buffer.moveAsserter_);
  IncrementViewCount();

  if (offset > buffer.GetSize()) {
    _DEBUG_ASSERT(
        offset <= buffer.GetSize(),
        "Offset [" << offset << "] cannot be greater than total buffer size [" << buffer.GetSize()
                   << "]. Will set slice size to zero.");
    size_ = 0;
    return;
  }

  AdvanceBy(offset, &currentFragmentIndex_, &currentFragmentOffset_);

  if (offset + size <= buffer.GetSize()) {
    size_ = size;
  } else {
    const size_t truncatedSize = buffer.GetSize() - offset;
    _DEBUG_FAIL(
        "Offset [" << offset << "] plus size [" << size << "] cannot be greater than total buffer size ["
                   << buffer.GetSize() << "]. Will truncate slice size to [" << truncatedSize << "]");
    size_ = truncatedSize;
  }
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::Buffer2View(Buffer2View&& other)
    : buffer_(other.buffer_),
      size_(std::move(other.size_)),
      currentFragmentIndex_(std::move(other.currentFragmentIndex_)),
      currentFragmentOffset_(std::move(other.currentFragmentOffset_)) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  IncrementViewCount();
  other.DecrementViewCount();
  other.buffer_ = nullptr;
  other.size_ = 0;
  other.currentFragmentIndex_ = Buffer2::kMaximumNumberOfCompositeFragments;
  other.currentFragmentOffset_ = 0;
  _MOVE_ASSERTER_MOVE(other.moveAsserter_);
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::~Buffer2View() {
  DecrementViewCount();
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>& Buffer2View<TMemoryPointer>::operator=(Buffer2View&& other) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  DecrementViewCount();

  buffer_ = other.buffer_;

  size_ = other.size_;
  currentFragmentIndex_ = other.currentFragmentIndex_;
  currentFragmentOffset_ = other.currentFragmentOffset_;

  _MOVE_ASSERTER_MOVE(other.moveAsserter_);
  other.buffer_ = nullptr;

  other.size_ = 0;
  other.currentFragmentIndex_ = Buffer2::kMaximumNumberOfCompositeFragments;
  other.currentFragmentOffset_ = 0;

  moveAsserter_.Initialize();
  return *this;
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>& Buffer2View<TMemoryPointer>::operator=(const Buffer2View& other) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  DecrementViewCount();

  buffer_ = other.buffer_;
  IncrementViewCount();

  size_ = other.size_;
  currentFragmentIndex_ = other.currentFragmentIndex_;
  currentFragmentOffset_ = other.currentFragmentOffset_;

  moveAsserter_.Initialize();
  return *this;
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::Buffer2View(
    const Buffer2* buffer, const size_t size, const size_t currentFragmentIndex, const size_t currentFragmentOffset)
    : buffer_(buffer),
      size_(size),
      currentFragmentIndex_(currentFragmentIndex),
      currentFragmentOffset_(currentFragmentOffset) {
  if (buffer_) {
    _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(buffer_->moveAsserter_);
  }
  IncrementViewCount();
}

template <typename TMemoryPointer>
bool Buffer2View<TMemoryPointer>::IsContiguous() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  if (currentFragmentIndex_ < Buffer2::kMaximumNumberOfCompositeFragments && buffer_) {
    return currentFragmentOffset_ + GetSize() <= buffer_->fragments_[currentFragmentIndex_].GetSize();
  } else {
    return true;
  }
}

template <typename TMemoryPointer>
bool Buffer2View<TMemoryPointer>::operator==(const Buffer2View<TMemoryPointer>& other) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  if (size_ != other.size_) {
    return false;
  }

  if (buffer_ == other.buffer_) {
    return currentFragmentIndex_ == other.currentFragmentIndex_ &&
           currentFragmentOffset_ == other.currentFragmentOffset_;
  }

  if (!buffer_ || !other.buffer_) {
    return false;
  }

  auto bytesToCheck = size_;
  auto thisFragmentIndex = currentFragmentIndex_;
  auto otherFragmentIndex = other.currentFragmentIndex_;

  auto thisFragmentOffset = currentFragmentOffset_;
  auto otherFragmentOffset = other.currentFragmentOffset_;

  while (bytesToCheck) {
    const auto& thisFragment = buffer_->fragments_[thisFragmentIndex];
    const auto& otherFragment = other.buffer_->fragments_[otherFragmentIndex];

    const auto thisFragmentSize = std::min(bytesToCheck, thisFragment.GetSize() - thisFragmentOffset);
    const auto otherFragmentSize = std::min(bytesToCheck, otherFragment.GetSize() - otherFragmentOffset);

    const auto thisFragmentPointer = thisFragment.GetRawPointer() + thisFragmentOffset;
    const auto otherFragmentPointer = otherFragment.GetRawPointer() + otherFragmentOffset;

    if (thisFragmentPointer != otherFragmentPointer || thisFragmentSize != otherFragmentSize) {
      return false;
    }

    bytesToCheck -= thisFragmentSize;

    thisFragmentOffset = 0;
    otherFragmentOffset = 0;

    ++thisFragmentIndex;
    ++otherFragmentIndex;
  }

  return true;
}

template <typename TMemoryPointer>
typename Buffer2View<TMemoryPointer>::BufferFragmentIterator Buffer2View<TMemoryPointer>::GetCurrentFragmentIterator()
    const {
  if (currentFragmentIndex_ < Buffer2::kMaximumNumberOfCompositeFragments && buffer_) {
    const auto& fragment = buffer_->fragments_[currentFragmentIndex_];
    if (fragment.IsValid()) {
      return BufferFragmentIterator(buffer_, currentFragmentIndex_, currentFragmentOffset_, GetSize());
    }
  }

  return BufferFragmentIterator(nullptr, Buffer2::kMaximumNumberOfCompositeFragments, 0, 0);
}

template <typename TMemoryPointer>
void Buffer2View<TMemoryPointer>::Clear() {
  auto buffer = GetBuffer();
  if (buffer) {
    buffer->EnsureValidFragmentsAreInFrontOfTheBuffer();
    buffer->size_ = 0;
  }

  DecrementViewCount();
  buffer_ = nullptr;
  size_ = 0;
  currentFragmentIndex_ = 0;
  currentFragmentOffset_ = 0;
}

template <typename TMemoryPointer>
void Buffer2View<TMemoryPointer>::IncrementViewCount() {
  if (buffer_) {
    buffer_->viewAsserter_.IncrementViewCount();
  }
}

template <typename TMemoryPointer>
void Buffer2View<TMemoryPointer>::DecrementViewCount() {
  if (buffer_) {
    buffer_->viewAsserter_.DecrementViewCount();
  }
}

template <typename TMemoryPointer>
void Buffer2View<TMemoryPointer>::AdvanceBy(
    const size_t numberOfBytes, size_t* outFragmentIndex, size_t* outFragmentOffset) const {
  _DEBUG_ASSERT(
      numberOfBytes <= GetSize(),
      "Cannot advance by [" << numberOfBytes << "] bytes when total size is [" << GetSize() << "]");

  const size_t numberOfBytesToAdvance = std::min(numberOfBytes, GetSize());
  size_t numberOfBytesLeftToAdvance = numberOfBytesToAdvance;

  *outFragmentIndex = currentFragmentIndex_;
  *outFragmentOffset = currentFragmentOffset_;

  while (numberOfBytesLeftToAdvance != 0 && *outFragmentIndex < Buffer2::kMaximumNumberOfCompositeFragments) {
    const auto& fragment = buffer_->fragments_[*outFragmentIndex];

    const size_t numberOfBytesLeftInCurrentFragment = fragment.GetSize() - *outFragmentOffset;

    if (numberOfBytesLeftToAdvance < numberOfBytesLeftInCurrentFragment) {
      *outFragmentOffset += numberOfBytesLeftToAdvance;
      numberOfBytesLeftToAdvance = 0;
    } else {
      numberOfBytesLeftToAdvance -= numberOfBytesLeftInCurrentFragment;
      ++(*outFragmentIndex);
      *outFragmentOffset = 0;
    }
  }
}

template <typename TMemoryPointer>
const typename Buffer2View<TMemoryPointer>::FragmentInfo
    Buffer2View<TMemoryPointer>::BufferFragmentIterator::kNullFragmentInfo(nullptr, 0);

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::BufferFragmentIterator::BufferFragmentIterator(
    const Buffer2* buffer,
    const size_t currentFragmentIndex,
    const size_t offsetIntoCurrentFragment,
    const size_t sizeLeft)
    : buffer_(buffer),
      currentFragmentIndex_(currentFragmentIndex),
      offsetIntoCurrentFragment_(offsetIntoCurrentFragment),
      sizeLeft_(sizeLeft) {}

template <typename TMemoryPointer>
inline typename Buffer2View<TMemoryPointer>::FragmentInfo
Buffer2View<TMemoryPointer>::BufferFragmentIterator::GetFragment() const {
  if (currentFragmentIndex_ >= Buffer2::kMaximumNumberOfCompositeFragments || sizeLeft_ == 0) {
    return kNullFragmentInfo;
  }

  const auto& fragment = buffer_->fragments_[currentFragmentIndex_];

  if (buffer_->fragments_[currentFragmentIndex_].IsValid() && offsetIntoCurrentFragment_ < fragment.GetSize()) {
    // Note: C cast here because otherwise things get out of hand using complex _cast etc expressions
    return FragmentInfo(
        (TMemoryPointer)(fragment.GetRawPointer() + offsetIntoCurrentFragment_),
        std::min(fragment.GetSize() - offsetIntoCurrentFragment_, sizeLeft_));
  } else {
    return kNullFragmentInfo;
  }
}

template <typename TMemoryPointer>
typename Buffer2View<TMemoryPointer>::BufferFragmentIterator
Buffer2View<TMemoryPointer>::BufferFragmentIterator::GetNext() const {
  if (HasNext()) {
    const auto& fragment = buffer_->fragments_[currentFragmentIndex_];

    return BufferFragmentIterator(
        buffer_, currentFragmentIndex_ + 1, 0, sizeLeft_ - (fragment.GetSize() - offsetIntoCurrentFragment_));
  } else {
    _DEBUG_FAIL("Attempting to advance buffer fragment iterator past the end");
    return BufferFragmentIterator(nullptr, Buffer2::kMaximumNumberOfCompositeFragments, 0, 0);
  }
}

template <typename TMemoryPointer>
bool Buffer2View<TMemoryPointer>::BufferFragmentIterator::HasNext() const {
  if (currentFragmentIndex_ < (Buffer2::kMaximumNumberOfCompositeFragments - 1)) {
    const auto& fragment = buffer_->fragments_[currentFragmentIndex_];
    return sizeLeft_ > (fragment.GetSize() - offsetIntoCurrentFragment_);
  }

  return false;
}

template <typename TMemoryPointer>
void Buffer2View<TMemoryPointer>::AssertOnAccessToMovedObject(const char* const caller) const {
  moveAsserter_.AssertOnAccessToMovedObject(caller);
  if (buffer_) {
    buffer_->AssertOnAccessToMovedObject(caller);
  }
}

// Explicit instantiations
template class Buffer2View<uint8_t*>;
template class Buffer2View<const uint8_t*>;

}  // namespace memory

