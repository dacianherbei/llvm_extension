
#include "Memory/BufferSegment.h"

#include <cstdint>


namespace memory {

template <typename TMemoryPointer>
inline BufferSegment<TMemoryPointer>::BufferSegment(const size_t sizeInBytes, TMemoryPointer pointer)
    : sizeInBytes_(sizeInBytes), pointer_(pointer) {}

template <typename TMemoryPointer>
inline size_t BufferSegment<TMemoryPointer>::GetSize() const {
  return sizeInBytes_;
}

template <typename TMemoryPointer>
inline TMemoryPointer BufferSegment<TMemoryPointer>::GetPointer() const {
  return pointer_;
}

template <typename TMemoryPointer>
inline bool BufferSegment<TMemoryPointer>::operator==(const BufferSegment<TMemoryPointer>& other) const {
  return sizeInBytes_ == other.sizeInBytes_ && pointer_ == other.pointer_;
}

template <typename TMemoryPointer>
inline bool BufferSegment<TMemoryPointer>::operator!=(const BufferSegment<TMemoryPointer>& other) const {
  return !(*this == other);
}

// Explicit instantiations
template class BufferSegment<void*>;
template class BufferSegment<const void*>;
template class BufferSegment<uint8_t*>;
template class BufferSegment<const uint8_t*>;

}  // namespace memory

