
#pragma once

#include "Memory/MoveAsserter.h"

#include "System/Assert.h"


namespace memory {

inline MoveAsserter::MoveAsserter() : moved_(false) {}

inline MoveAsserter::~MoveAsserter() {}

inline void MoveAsserter::Initialize() { moved_ = false; }

inline void MoveAsserter::AssertOnAccessToMovedObject(const char* const caller) const {
  _ASSERT(!moved_, "Unable to access a moved instance in [" << caller << "].");
}

inline void MoveAsserter::Move(const char* const caller) {
  _ASSERT(!moved_.exchange(true), "Trying to move a moved instance in [" << caller << "].");
}

}  // namespace memory

