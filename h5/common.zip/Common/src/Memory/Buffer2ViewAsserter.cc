
#include "Memory/Buffer2ViewAsserter.h"

#include "System/Assert.h"


namespace memory {

Buffer2ViewAsserter::Buffer2ViewAsserter() : viewCount_(0) {}
Buffer2ViewAsserter::~Buffer2ViewAsserter() {}

void Buffer2ViewAsserter::IncrementViewCount() { ++viewCount_; }
void Buffer2ViewAsserter::DecrementViewCount() {
  _ASSERT(viewCount_ > 0, "Trying to decrement view count that is equal to 0");
  --viewCount_;
}

bool Buffer2ViewAsserter::AssertNoViewsExist() const {
  _ASSERT(viewCount_ == 0, "Buffer2 is being destructed or modified while [" << viewCount_ << "] views exist.");
  return true;
}

}  // namespace memory

