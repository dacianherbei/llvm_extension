
#include "Memory/BufferUtilities.h"

#include <algorithm>
#include <cstring>

#include "Memory/Buffer2ViewAccessor.h"
#include "System/Assert.h"
#include "System/Fail.h"


namespace memory {

const size_t BufferUtilities::npos = -1;

BufferUtilities::BufferUtilities() {}

BufferUtilities::~BufferUtilities() {}

void BufferUtilities::GetUnsignedValue(
    const std::shared_ptr<const IBuffer>& buffer, size_t offset, size_t length, void* outputValue) {
  switch (length) {
    case sizeof(uint8_t):
      *reinterpret_cast<uint8_t*>(outputValue) = buffer->GetUInt8(offset);
      break;
    case sizeof(uint16_t):
      *reinterpret_cast<uint16_t*>(outputValue) = buffer->GetUInt16(offset);
      break;
    case sizeof(system::Uint24_t):
      *reinterpret_cast<system::Uint24_t*>(outputValue) = buffer->GetUInt24(offset);
      break;
    case sizeof(uint32_t):
      *reinterpret_cast<uint32_t*>(outputValue) = buffer->GetUInt32(offset);
      break;
    case sizeof(system::Uint48_t):
      *reinterpret_cast<system::Uint48_t*>(outputValue) = buffer->GetUInt48(offset);
      break;
    case sizeof(uint64_t):
      *reinterpret_cast<uint64_t*>(outputValue) = buffer->GetUInt64(offset);
      break;
    default:
      _FAIL("GetUnsignedValue cannot be called with length [" << length << "]");
      break;
  }
}

std::shared_ptr<Buffer> BufferUtilities::CreateBufferWithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const void* data, size_t size) {
  std::shared_ptr<Buffer> buffer = bufferFactory->CreateBuffer(size);

  memcpy(buffer->GetRawPointer(), data, size);
  buffer->SetSize(size);
  return buffer;
}

std::shared_ptr<Buffer> BufferUtilities::CreateBufferWithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const std::shared_ptr<const IBuffer>& iBuffer) {
  std::shared_ptr<Buffer> buffer = bufferFactory->CreateBuffer(iBuffer->GetSize());

  static const size_t kOffset = 0;
  memory::BufferUtilities::CopyIBuffer(buffer->GetRawPointer(), iBuffer, kOffset, iBuffer->GetSize());

  return buffer;
}

std::shared_ptr<Buffer> BufferUtilities::CreateBufferWithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const std::string& data) {
  std::shared_ptr<Buffer> buffer = bufferFactory->CreateBuffer(data.length());

  memcpy(buffer->GetRawPointer(), data.c_str(), data.length());

  buffer->SetSize(data.length());

  return buffer;
}

std::shared_ptr<Buffer> BufferUtilities::CreateBufferWithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const std::vector<uint8_t>& bytesVector) {
  return memory::BufferUtilities::CreateBufferWithData(bufferFactory, bytesVector.data(), bytesVector.size());
}

std::shared_ptr<const DirectPointer> BufferUtilities::GetDirectPointerOrAllocateCopy(
    const std::shared_ptr<const IBuffer>& iBuffer, std::allocator<uint8_t> allocator) {
  return GetDirectPointerOrAllocateCopy(iBuffer, allocator, 0, iBuffer->GetSize());
}

std::shared_ptr<const DirectPointer> BufferUtilities::GetDirectPointerOrAllocateCopy(
    const std::shared_ptr<const IBuffer>& iBuffer, std::allocator<uint8_t> allocator, size_t offset, size_t length) {
  std::shared_ptr<const DirectPointer> returnDirectPointer = iBuffer->GetDirectPointer(offset, length);

  if (!returnDirectPointer->IsValid() && length > 0) {
    uint8_t* data = allocator.allocate(length);
    std::shared_ptr<uint8_t> dataPointer(
        data, [&allocator, length](uint8_t* ptr) { allocator.deallocate(ptr, length); });

    CopyIBuffer(dataPointer.get(), iBuffer, offset, length);

    returnDirectPointer = std::make_shared<DirectPointer>(dataPointer, 0, length);
  }

  return returnDirectPointer;
}

void BufferUtilities::BufferToStream(std::ostream* stream, const std::shared_ptr<const memory::IBuffer>& buffer) {
  _ASSERT(buffer != nullptr, "Can not serialize a null buffer to a stream");
  buffer->Visit(
      [&stream](const uint8_t* data, size_t length) { stream->write(reinterpret_cast<const char*>(data), length); });
}

std::string BufferUtilities::BufferToString(const std::shared_ptr<const memory::IBuffer>& buffer) {
  std::string string;
  string.reserve(buffer->GetSize());
  buffer->Visit(
      [&string](const uint8_t* data, size_t length) { string.append(reinterpret_cast<const char*>(data), length); });
  return string;
}

void BufferUtilities::CopyIBuffer(
    const std::shared_ptr<Buffer>& dst,
    size_t dstOffset,
    const std::shared_ptr<const IBuffer>& src,
    size_t srcOffset,
    size_t length) {
  // TODO(Mykhailo): maybe size and not capacity should be used here,
  // but during refactoring I decided not to change behavior, as it breaks some unit tests.
  AssertBufferOffset(dst->GetCapacity(), dstOffset, length);
  CopyIBuffer(dst->GetRawPointer(), dstOffset, src, srcOffset, length);
}

void BufferUtilities::CopyIBuffer(
    uint8_t* dst, const std::shared_ptr<const IBuffer>& src, size_t srcOffset, size_t length) {
  CopyIBuffer(dst, 0, src, srcOffset, length);
}

void BufferUtilities::CopyIBuffer(
    uint8_t* dst, size_t dstOffset, const std::shared_ptr<const IBuffer>& src, size_t srcOffset, size_t length) {
  CopyIBufferContext context(dst + dstOffset, srcOffset, length);

  src->Visit([&context](const uint8_t* data, size_t dataLength) {
    if (context.srcOffsetLeft < dataLength) {
      const auto dataLengthFinal = std::min(dataLength - context.srcOffsetLeft, context.lengthLeft);
      memcpy(context.dst, data + context.srcOffsetLeft, dataLengthFinal);
      context.dst += dataLengthFinal;
      context.srcOffsetLeft = 0;
      context.lengthLeft -= dataLengthFinal;
    } else {
      context.srcOffsetLeft -= dataLength;
    }
  });

  _ASSERT(
      context.lengthLeft == 0,
      "Failed to copy requested amount of data. Expected length [" << length << "], copied length ["
                                                                   << length - context.lengthLeft << "]");
}

void BufferUtilities::CopyIBuffer(
    const std::shared_ptr<Buffer>& dst, size_t dstOffset, const void* src, size_t length) {
  AssertBufferOffset(dst->GetSize(), dstOffset, length);
  memcpy(dst->GetRawPointer() + dstOffset, src, length);
}

void BufferUtilities::AssertBufferOffset(const size_t bufferSize, const size_t offset, const size_t length) {
  _ASSERT(
      offset <= bufferSize, "The offset [" << offset << "] should be <= than bufferSize [" << bufferSize << "]");
  _ASSERT(
      length <= bufferSize - offset,
      "The length [" << length << "] should be <= than size after offset [" << bufferSize - offset << "]");
}

memory::Buffer2View<const uint8_t*> BufferUtilities::GetLine(
    const memory::Buffer2View<const uint8_t*>& bufferView, memory::Buffer2View<const uint8_t*>* remainingBufferView) {
  memory::Buffer2View<const uint8_t*> returnBufferView;
  size_t positionOfLineEnding = BufferUtilities::Find(bufferView, '\n', 0);

  if (positionOfLineEnding != BufferUtilities::npos) {
    returnBufferView = bufferView.Slice(0, positionOfLineEnding);
    if (positionOfLineEnding == bufferView.GetSize() - 1) {
      *remainingBufferView = bufferView.Slice(positionOfLineEnding, 0);
    } else {
      *remainingBufferView = bufferView.Slice(positionOfLineEnding + 1);
    }
  } else {
    returnBufferView = bufferView;
    *remainingBufferView = bufferView.Slice(bufferView.GetSize() - 1, 0);
  }

  size_t returnBufferSize = returnBufferView.GetSize();
  if (returnBufferSize > 1 && memory::Buffer2ViewAccessor::ReadInt8(returnBufferView, returnBufferSize - 1) == '\r') {
    returnBufferView = returnBufferView.Slice(0, returnBufferSize - 1);
  }

  return returnBufferView;
}

int BufferUtilities::CompareIBuffer(const std::shared_ptr<const IBuffer>& iBuffer, const std::string& data) {
  if (iBuffer->GetSize() < data.length()) {
    return -1;
  } else if (iBuffer->GetSize() > data.length()) {
    return 1;
  }

  return CompareIBuffer(iBuffer, data.c_str(), data.length());
}

int BufferUtilities::CompareIBuffer(const std::shared_ptr<const IBuffer>& iBuffer, const void* data, size_t length) {
  _ASSERT(
      length <= iBuffer->GetSize(),
      "Unable to compare length [" << length << "] of an IBuffer that only has a size of [" << iBuffer->GetSize()
                                   << "].");

  int returnValue = 0;
  size_t remainingLength = length;
  iBuffer->Visit([&data, &remainingLength, &returnValue](const uint8_t* iBufferData, size_t iBufferLength) {
    if (returnValue != 0) {
      return;
    }

    size_t actualLength = std::min(remainingLength, iBufferLength);
    returnValue = memcmp(iBufferData, data, actualLength);
    data = static_cast<const char*>(data) + actualLength;
    remainingLength -= actualLength;
  });

  return returnValue;
}

int BufferUtilities::CompareIBuffer(
    const std::shared_ptr<const IBuffer>& iBuffer1, const std::shared_ptr<const IBuffer>& iBuffer2) {
  if (iBuffer1->GetSize() < iBuffer2->GetSize()) {
    return -1;
  } else if (iBuffer1->GetSize() > iBuffer2->GetSize()) {
    return 1;
  }

  return CompareIBuffer(iBuffer1, iBuffer2, iBuffer1->GetSize());
}

int BufferUtilities::CompareIBuffer(
    const std::shared_ptr<const IBuffer>& iBuffer1, const std::shared_ptr<const IBuffer>& iBuffer2, size_t length) {
  _ASSERT(
      length <= iBuffer1->GetSize(),
      "Unable to compare length [" << length << "] of an IBuffer that only has a size of [" << iBuffer1->GetSize()
                                   << "].");
  _ASSERT(
      length <= iBuffer2->GetSize(),
      "Unable to compare length [" << length << "] of an IBuffer that only has a size of [" << iBuffer2->GetSize()
                                   << "].");

  int returnValue = 0;
  size_t remainingLength = length;
  std::shared_ptr<const IBuffer> remaingBuffer2 = iBuffer2;
  iBuffer1->Visit(
      [&remaingBuffer2, &remainingLength, &returnValue](const uint8_t* iBuffer1Data, size_t iBuffer1Length) {
        if (returnValue != 0 || remainingLength == 0) {
          return;
        }

        size_t buffer2ProcessedLength = 0;
        remaingBuffer2->Visit([&iBuffer1Data, iBuffer1Length, &remainingLength, &buffer2ProcessedLength, &returnValue](
                                  const uint8_t* iBuffer2Data, size_t iBuffer2Length) {
          if (returnValue != 0 || remainingLength == 0) {
            return;
          }

          size_t actualLength = std::min(remainingLength, iBuffer2Length);
          actualLength = std::min(actualLength, iBuffer1Length - buffer2ProcessedLength);
          returnValue = memcmp(iBuffer1Data + buffer2ProcessedLength, iBuffer2Data, actualLength);
          remainingLength -= actualLength;
          buffer2ProcessedLength += actualLength;
        });

        remaingBuffer2 = remaingBuffer2->Slice(buffer2ProcessedLength);
      });

  _ASSERT(
      returnValue != 0 || remainingLength == 0,
      "We shouldn't be exiting this method unless the return value ["
          << returnValue << "] is not 0 or the remaining length [" << remainingLength << "] is 0.");
  return returnValue;
}

size_t BufferUtilities::Find(const std::shared_ptr<const IBuffer>& iBuffer, uint8_t value, size_t index) {
  size_t returnValue = npos;
  size_t currentIndex = index;
  const auto& buffer = (index == 0) ? iBuffer : iBuffer->Slice(index);
  buffer->Visit([value, &currentIndex, &returnValue](const uint8_t* data, size_t length) {
    if (returnValue != npos) {
      return;
    }

    const void* foundLocation = memchr(data, value, length);
    if (foundLocation != nullptr) {
      returnValue = currentIndex + reinterpret_cast<size_t>(foundLocation) - reinterpret_cast<size_t>(data);
      return;
    }

    currentIndex += length;
  });

  return returnValue;
}

size_t BufferUtilities::Find(const memory::Buffer2View<const uint8_t*>& bufferView, uint8_t value, size_t index) {
  size_t returnValue = npos;
  size_t currentIndex = index;
  const auto& adjustedBufferView = (index == 0) ? bufferView : bufferView.Slice(index);
  memory::Buffer2ViewAccessor::Visit(
      adjustedBufferView, [value, &currentIndex, &returnValue](const uint8_t* data, size_t length) {
        if (returnValue != npos) {
          return;
        }

        const void* foundLocation = memchr(data, value, length);
        if (foundLocation != nullptr) {
          returnValue = currentIndex + reinterpret_cast<size_t>(foundLocation) - reinterpret_cast<size_t>(data);
          return;
        }

        currentIndex += length;
      });

  return returnValue;
}

size_t BufferUtilities::FindBuffer(
    const std::shared_ptr<const IBuffer>& haystack, const uint8_t* needle, size_t needleLength, size_t index) {
  const size_t haystackLength = haystack->GetSize();

  if (needleLength == 0) {
    return index;
  } else if (index + needleLength > haystackLength) {
    return npos;
  }

  size_t haystackOffset = Find(haystack, needle[0], index);

  while (haystackOffset != npos && haystackOffset + needleLength <= haystackLength) {
    bool match = true;
    for (size_t needleOffset = 1; needleOffset < needleLength && match; needleOffset++) {
      match &= needle[needleOffset] == haystack->GetUInt8(haystackOffset + needleOffset);
    }

    if (match) {
      return haystackOffset;
    } else if (haystackOffset + 1 < haystackLength) {
      haystackOffset = Find(haystack, needle[0], haystackOffset + 1);
    } else {
      return npos;
    }
  }

  return npos;
}

void BufferUtilities::GetUnsignedValue(
    const memory::Buffer2View<const uint8_t*>& bufferView, size_t offset, size_t length, void* outputValue) {
  switch (length) {
    case sizeof(uint8_t):
      *reinterpret_cast<uint8_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt8(bufferView, offset);
      break;
    case sizeof(uint16_t):
      *reinterpret_cast<uint16_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt16(bufferView, offset);
      break;
    case sizeof(system::Uint24_t):
      *reinterpret_cast<system::Uint24_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt24(bufferView, offset);
      break;
    case sizeof(uint32_t):
      *reinterpret_cast<uint32_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt32(bufferView, offset);
      break;
    case sizeof(system::Uint48_t):
      *reinterpret_cast<system::Uint48_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt48(bufferView, offset);
      break;
    case sizeof(uint64_t):
      *reinterpret_cast<uint64_t*>(outputValue) = Buffer2ViewAccessor::ReadUInt64(bufferView, offset);
      break;
    default:
      _FAIL("GetUnsignedValue cannot be called with length [" << length << "]");
      break;
  }
}

Buffer2 BufferUtilities::CreateBuffer2WithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const void* data, size_t size) {
  auto buffer = bufferFactory->CreateBuffer2(size);

  Buffer2ViewAccessor::WriteBytes(buffer, data, size);
  return buffer;
}

Buffer2 BufferUtilities::CreateBuffer2WithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const Buffer2View<const uint8_t*>& bufferView) {
  auto buffer = bufferFactory->CreateBuffer2(bufferView.GetSize());

  Buffer2ViewAccessor::WriteBytes(buffer, bufferView);
  return buffer;
}

Buffer2 BufferUtilities::CreateBuffer2WithData(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const std::string& data) {
  auto buffer = bufferFactory->CreateBuffer2(data.length());

  Buffer2ViewAccessor::WriteBytes(buffer, data.c_str(), data.length());
  return buffer;
}

void BufferUtilities::Buffer2ViewToStream(std::ostream* stream, const memory::Buffer2View<const uint8_t*>& bufferView) {
  Buffer2ViewAccessor::Visit(bufferView, [&stream](const void* data, const size_t numberOfBytes) {
    stream->write(reinterpret_cast<const char*>(data), numberOfBytes);
  });
}

std::string BufferUtilities::Buffer2ViewToString(const Buffer2View<const uint8_t*>& bufferView) {
  std::string resultString;
  resultString.reserve(bufferView.GetSize());

  Buffer2ViewAccessor::Visit(bufferView, [&resultString](const void* buffer, const size_t numberOfBytes) {
    resultString.append(reinterpret_cast<const char*>(buffer), numberOfBytes);
  });

  return resultString;
}

void BufferUtilities::ZeroFillBuffer2View(
    const Buffer2View<uint8_t*>& destination, const size_t destinationOffset, const size_t length) {
  Buffer2ViewAccessor::Visit(
      destination.Slice(destinationOffset, length),
      [](uint8_t* buffer, const size_t numberOfBytes) { std::memset(buffer, 0, numberOfBytes); });
}

void BufferUtilities::ZeroFillBuffer2View(const Buffer2View<uint8_t*>& destination, const size_t length) {
  Buffer2ViewAccessor::Visit(destination.Slice(0, length), [](uint8_t* buffer, const size_t numberOfBytes) {
    std::memset(buffer, 0, numberOfBytes);
  });
}

int BufferUtilities::CompareBuffer2View(
    const memory::Buffer2View<const uint8_t*>& bufferView, const std::string& data) {
  if (bufferView.GetSize() < data.length()) {
    return -1;
  } else if (bufferView.GetSize() > data.length()) {
    return 1;
  }

  return CompareBuffer2View(bufferView, data.c_str(), data.length());
}

int BufferUtilities::CompareBuffer2View(
    const memory::Buffer2View<const uint8_t*>& bufferView, const void* data, size_t length) {
  _ASSERT(
      length <= bufferView.GetSize(),
      "Unable to compare length [" << length << "] of a Buffer2View that only has a size of [" << bufferView.GetSize()
                                   << "].");

  int returnValue = 0;
  size_t remainingLength = length;
  Buffer2ViewAccessor::Visit(
      bufferView, [&data, &remainingLength, &returnValue](const uint8_t* bufferData, size_t bufferLength) {
        if (returnValue != 0) {
          return;
        }

        size_t actualLength = std::min(remainingLength, bufferLength);
        returnValue = memcmp(bufferData, data, actualLength);
        data = static_cast<const char*>(data) + actualLength;
        remainingLength -= actualLength;
      });

  return returnValue;
}

int BufferUtilities::CompareBuffer2View(
    const memory::Buffer2View<const uint8_t*>& bufferView1, const memory::Buffer2View<const uint8_t*>& bufferView2) {
  if (bufferView1.GetSize() < bufferView2.GetSize()) {
    return -1;
  } else if (bufferView1.GetSize() > bufferView2.GetSize()) {
    return 1;
  }

  return CompareBuffer2View(bufferView1, bufferView2, bufferView1.GetSize());
}

int BufferUtilities::CompareBuffer2View(
    const memory::Buffer2View<const uint8_t*>& bufferView1,
    const memory::Buffer2View<const uint8_t*>& bufferView2,
    size_t length) {
  _ASSERT(
      length <= bufferView1.GetSize(),
      "Unable to compare length [" << length << "] of a Buffer2View that only has a size of [" << bufferView1.GetSize()
                                   << "].");
  _ASSERT(
      length <= bufferView2.GetSize(),
      "Unable to compare length [" << length << "] of a Buffer2View that only has a size of [" << bufferView2.GetSize()
                                   << "].");

  int returnValue = 0;
  size_t remainingLength = length;
  auto remaingBufferView2 = bufferView2.Slice(0);

  Buffer2ViewAccessor::Visit(
      bufferView1,
      [&remaingBufferView2, &remainingLength, &returnValue](const uint8_t* buffer1Data, size_t buffer1Length) {
        if (returnValue != 0 || remainingLength == 0) {
          return;
        }

        size_t buffer2ProcessedLength = 0;
        Buffer2ViewAccessor::Visit(
            remaingBufferView2,
            [&buffer1Data, buffer1Length, &remainingLength, &buffer2ProcessedLength, &returnValue](
                const uint8_t* buffer2Data, size_t buffer2Length) {
              if (returnValue != 0 || remainingLength == 0) {
                return;
              }

              size_t actualLength = std::min(remainingLength, buffer2Length);
              actualLength = std::min(actualLength, buffer1Length - buffer2ProcessedLength);
              returnValue = memcmp(buffer1Data + buffer2ProcessedLength, buffer2Data, actualLength);
              remainingLength -= actualLength;
              buffer2ProcessedLength += actualLength;
            });

        remaingBufferView2 = remaingBufferView2.Slice(buffer2ProcessedLength);
      });

  _ASSERT(
      returnValue != 0 || remainingLength == 0,
      "We shouldn't be exiting this method unless the return value ["
          << returnValue << "] is not 0 or the remaining length [" << remainingLength << "] is 0.");
  return returnValue;
}

}  // namespace memory

