
#pragma once

#include "Memory/BufferFactory.h"

#include "Memory/Buffer2ViewAccessor.h"
#include "System/Fail.h"


namespace memory {

template <typename IteratorType, typename>
bool BufferFactory::CompositionRequiresFlattening(const IteratorType& begin, const IteratorType& end) {
  size_t validFragmentsCount = 0;
  for (auto it = begin; it != end; ++it) {
    validFragmentsCount += it->GetValidFragmentsCount();
    if (validFragmentsCount > Buffer2::kMaximumNumberOfCompositeFragments) {
      return true;
    }
  }

  return false;
}

template <typename... BufferType, typename>
Buffer2 BufferFactory::CreateBuffer2(const BufferType&... moreBuffers) const {
  const std::vector<std::reference_wrapper<const Buffer2>> buffers{moreBuffers...};
  return CreateBuffer2(buffers.begin(), buffers.end());
}

template <typename IteratorType, typename>
Buffer2 BufferFactory::CreateBuffer2(const IteratorType& begin, const IteratorType& end) const {
  if (CompositionRequiresFlattening(begin, end)) {
    AssertOnCompositionFailure();
    return FlattenRange(begin, end);
  } else {
    return CreateBuffer2ShallowCopyingFragmentsFromRange(begin, end);
  }
}

template <typename... BufferType, typename>
Buffer2 BufferFactory::CreateBuffer2(BufferType&&... moreBuffers) const {
  std::array<Buffer2, sizeof...(BufferType)> buffers{std::forward<Buffer2>(moreBuffers)...};
  return CreateBuffer2(std::make_move_iterator(buffers.begin()), std::make_move_iterator(buffers.end()));
}

template <typename IteratorType>
Buffer2 BufferFactory::CreateBuffer2(
    const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const {
  if (CompositionRequiresFlattening(begin, end)) {
    AssertOnCompositionFailure();
    return FlattenRangeAndMarkAsMoved(begin, end);
  } else {
    return CreateBuffer2MovingFragmentsFromRange(begin, end);
  }
}

template <typename... BufferType, typename>
Buffer2 BufferFactory::CreateBuffer2AllowAutoFlatten(const BufferType&... moreBuffers) const {
  const std::vector<std::reference_wrapper<const Buffer2>> buffers{moreBuffers...};
  return CreateBuffer2AllowAutoFlatten(buffers.begin(), buffers.end());
}

template <typename IteratorType, typename>
Buffer2 BufferFactory::CreateBuffer2AllowAutoFlatten(const IteratorType& begin, const IteratorType& end) const {
  return CompositionRequiresFlattening(begin, end) ? FlattenRange(begin, end)
                                                   : CreateBuffer2ShallowCopyingFragmentsFromRange(begin, end);
}

template <typename... BufferType, typename>
Buffer2 BufferFactory::CreateBuffer2AllowAutoFlatten(BufferType&&... moreBuffers) const {
  std::array<Buffer2, sizeof...(BufferType)> buffers{std::forward<Buffer2>(moreBuffers)...};
  return CreateBuffer2AllowAutoFlatten(
      std::make_move_iterator(buffers.begin()), std::make_move_iterator(buffers.end()));
}

template <typename IteratorType>
Buffer2 BufferFactory::CreateBuffer2AllowAutoFlatten(
    const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const {
  return CompositionRequiresFlattening(begin, end) ? FlattenRangeAndMarkAsMoved(begin, end)
                                                   : CreateBuffer2MovingFragmentsFromRange(begin, end);
}

template <typename IteratorType>
Buffer2 BufferFactory::CreateBuffer2MovingFragmentsFromRange(
    const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const {
  Buffer2 compositeBuffer;

  for (auto it = begin; it != end; ++it) {
    if (!compositeBuffer.TryAppendWithMove(std::move(*it))) {
      _FAIL(
          "Fail to append with move when total valid fragments count is less than maximum accepted by Buffer2!");
    }
  }

  return compositeBuffer;
}

template <typename IteratorType>
Buffer2 BufferFactory::CreateBuffer2ShallowCopyingFragmentsFromRange(
    const IteratorType& begin, const IteratorType& end) const {
  Buffer2 compositeBuffer;

  for (auto it = begin; it != end; ++it) {
    if (!compositeBuffer.TryAppendWithShallowCopy(*it)) {
      _FAIL(
          "Fail to append with shallow copy when total valid fragments count is less than maximum accepted by "
          "Buffer2!");
    }
  }

  return compositeBuffer;
}

template <typename IteratorType, typename>
Buffer2 BufferFactory::FlattenRange(const IteratorType& begin, const IteratorType& end) const {
  auto flattenBuffer = CreateBuffer2(GetCumulativeBufferSize(begin, end));

  auto offset = 0;
  for (auto it = begin; it != end; ++it) {
    Buffer2ViewAccessor::WriteBytes(flattenBuffer, offset, (*it));
    offset += it->GetSize();
  }

  return flattenBuffer;
}

template <typename IteratorType>
Buffer2 BufferFactory::FlattenRangeAndMarkAsMoved(
    const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const {
  auto flattenBuffer = CreateBuffer2(GetCumulativeBufferSize(begin, end));

  auto offset = 0;
  for (auto it = begin; it != end; ++it) {
    auto buffer = std::move(*it);
    Buffer2ViewAccessor::WriteBytes(flattenBuffer, offset, buffer);
    offset += buffer.GetSize();
  }

  return flattenBuffer;
}

template <typename IteratorType, typename>
size_t BufferFactory::GetCumulativeBufferSize(const IteratorType& begin, const IteratorType& end) {
  size_t totalSize = 0;
  for (auto it = begin; it != end; ++it) {
    totalSize += it->GetSize();
  }
  return totalSize;
}
}  // namespace memory

