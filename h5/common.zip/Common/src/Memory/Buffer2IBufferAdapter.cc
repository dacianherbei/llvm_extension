
#include "Memory/Buffer2IBufferAdapter.h"

#include "Memory/Buffer2ViewAccessor.h"


namespace memory {

Buffer2IBufferAdapter::Buffer2IBufferAdapter(const Buffer2& buffer2) : buffer2_(buffer2.GetView()) {}

Buffer2IBufferAdapter::Buffer2IBufferAdapter(Buffer2&& buffer2) : buffer2_(std::move(buffer2)) {}

size_t Buffer2IBufferAdapter::GetSize() const { return buffer2_.GetSize(); }

// Get - signed
int8_t Buffer2IBufferAdapter::GetInt8(size_t index) const { return Buffer2ViewAccessor::ReadInt8(buffer2_, index); }

int16_t Buffer2IBufferAdapter::GetInt16(size_t index) const { return Buffer2ViewAccessor::ReadInt16(buffer2_, index); }

int32_t Buffer2IBufferAdapter::GetInt32(size_t index) const { return Buffer2ViewAccessor::ReadInt32(buffer2_, index); }

int64_t Buffer2IBufferAdapter::GetInt64(size_t index) const { return Buffer2ViewAccessor::ReadInt64(buffer2_, index); }

// Get - unsigned
uint8_t Buffer2IBufferAdapter::GetUInt8(size_t index) const { return Buffer2ViewAccessor::ReadUInt8(buffer2_, index); }

uint16_t Buffer2IBufferAdapter::GetUInt16(size_t index) const {
  return Buffer2ViewAccessor::ReadUInt16(buffer2_, index);
}

system::Uint24_t Buffer2IBufferAdapter::GetUInt24(size_t index) const {
  return Buffer2ViewAccessor::ReadUInt24(buffer2_, index);
}

uint32_t Buffer2IBufferAdapter::GetUInt32(size_t index) const {
  return Buffer2ViewAccessor::ReadUInt32(buffer2_, index);
}

system::Uint48_t Buffer2IBufferAdapter::GetUInt48(size_t index) const {
  return Buffer2ViewAccessor::ReadUInt48(buffer2_, index);
}

uint64_t Buffer2IBufferAdapter::GetUInt64(size_t index) const {
  return Buffer2ViewAccessor::ReadUInt64(buffer2_, index);
}

std::shared_ptr<const IBuffer> Buffer2IBufferAdapter::Slice(size_t offset) const {
  return std::make_shared<Buffer2IBufferAdapter>(Buffer2(buffer2_.Slice(offset)));
}

std::shared_ptr<const IBuffer> Buffer2IBufferAdapter::Slice(size_t offset, size_t length) const {
  return std::make_shared<Buffer2IBufferAdapter>(Buffer2(buffer2_.Slice(offset, length)));
}

void Buffer2IBufferAdapter::Visit(const BufferVisitorType& visitor) const {
  Buffer2ViewAccessor::Visit(
      buffer2_, [&visitor](const uint8_t* buffer, const size_t length) { visitor(buffer, length); });
}

Buffer2 Buffer2IBufferAdapter::AsBuffer2(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const bool allowFlatten) const {
  return Buffer2(buffer2_.GetView());
}

std::shared_ptr<const DirectPointer> Buffer2IBufferAdapter::GetDirectPointer() const {
  return GetDirectPointer(buffer2_.GetView());
}

std::shared_ptr<const DirectPointer> Buffer2IBufferAdapter::GetDirectPointer(size_t offset, size_t length) const {
  return GetDirectPointer(buffer2_.Slice(offset, length));
}

std::vector<BufferSegment<const uint8_t*>> Buffer2IBufferAdapter::GetSegments() const {
  std::vector<BufferSegment<const uint8_t*>> segments;

  Buffer2ViewAccessor::Visit(
      buffer2_, [&segments](const uint8_t* buffer, const size_t length) { segments.emplace_back(length, buffer); });

  return segments;
}

std::shared_ptr<const DirectPointer> Buffer2IBufferAdapter::GetDirectPointer(const Buffer2View<const uint8_t*>& view) {
  if (view.IsContiguous()) {
    const auto& fragment = view.buffer_->fragments_[view.currentFragmentIndex_];

    return std::make_shared<DirectPointer>(fragment.data_, fragment.offset_ + view.currentFragmentOffset_, view.size_);
  } else {
    return DirectPointer::kNullDirectPointer;
  }
}

void Buffer2IBufferAdapter::Print(std::ostream* stream) const {
  *stream << "Buffer2IBufferAdapter[buffer2=" << buffer2_ << "]";
}

}  // namespace memory

