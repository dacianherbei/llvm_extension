
#include "Memory/BitReader.h"

#include "System/Assert.h"
#include "System/DebugAssert.h"


namespace memory {

BitReader::BitReader(
    const std::shared_ptr<logging::Logger>& logger, const std::shared_ptr<const IBitDecoder>& bitDecoder)
    : logger_(logger), bitDecoder_(bitDecoder) {}

boost::optional<uint32_t> BitReader::TryReadBits(
    const uint8_t* const data, size_t* const bitOffset, const size_t bitLength, const size_t readBitCount) const {
  _LOG_SCOPE("BitReader::TryReadBits");

  if (*bitOffset + readBitCount > bitLength) {
    return boost::none;
  }

  if (readBitCount == 0) {
    _LOG(logger_, logging::LogLevel::kWarn, "The value of count param must be greater than zero.");
  }

  uint32_t value = 0;
  for (size_t i = 0; i < readBitCount; ++i) {
    value <<= 1;
    value |= bitDecoder_->ReadBitOrReturnNegative1(data, bitOffset, bitLength);
  }

  return value;
}

boost::optional<bool> BitReader::TryReadBoolBit(
    const uint8_t* const data, size_t* const bitOffset, const size_t bitLength) const {
  _LOG_SCOPE("BitReader::TryReadBoolBit");

  if (*bitOffset >= bitLength) {
    return boost::none;
  }

  return bitDecoder_->ReadBitOrReturnNegative1(data, bitOffset, bitLength) != 0;
}

}  // namespace memory

