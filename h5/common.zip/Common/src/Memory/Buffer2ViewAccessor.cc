
#include "Memory/Buffer2ViewAccessor.h"
#include "System/Assert.h"
#include "System/Endian.h"
#include "System/ScopeExit.h"


namespace memory {

int8_t Buffer2ViewAccessor::ReadInt8(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<int8_t>(bufferView, index);
}

int16_t Buffer2ViewAccessor::ReadInt16(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<int16_t>(bufferView, index);
}

int32_t Buffer2ViewAccessor::ReadInt32(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<int32_t>(bufferView, index);
}

int64_t Buffer2ViewAccessor::ReadInt64(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<int64_t>(bufferView, index);
}

uint8_t Buffer2ViewAccessor::ReadUInt8(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<uint8_t>(bufferView, index);
}

uint16_t Buffer2ViewAccessor::ReadUInt16(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<uint16_t>(bufferView, index);
}

system::Uint24_t Buffer2ViewAccessor::ReadUInt24(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<system::Uint24_t>(bufferView, index);
}

uint32_t Buffer2ViewAccessor::ReadUInt32(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<uint32_t>(bufferView, index);
}

system::Uint48_t Buffer2ViewAccessor::ReadUInt48(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<system::Uint48_t>(bufferView, index);
}

uint64_t Buffer2ViewAccessor::ReadUInt64(const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  return GetBytesAsIntegralType<uint64_t>(bufferView, index);
}

void Buffer2ViewAccessor::SetInt8(const int8_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetInt16(const int16_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetInt32(const int32_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetInt64(const int64_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt8(const uint8_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt16(const uint16_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt24(
    const system::Uint24_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt32(const uint32_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt48(
    const system::Uint48_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

void Buffer2ViewAccessor::SetUInt64(const uint64_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index) {
  SetBytesAsIntegralType(bufferView, index, item);
}

uint8_t* Buffer2ViewAccessor::GetPointer(const Buffer2View<uint8_t*>& bufferView) {
  if (!bufferView.IsContiguous()) {
    _DEBUG_FAIL("Calling GetPointer on a non-contiguous buffer view");
    return nullptr;
  }

  if (bufferView.GetSize() > 0) {
    return bufferView.GetCurrentFragmentIterator().GetFragment().pointer;
  } else {
    return nullptr;
  }
}

const uint8_t* Buffer2ViewAccessor::GetConstPointer(const Buffer2View<const uint8_t*>& bufferView) {
  if (!bufferView.IsContiguous()) {
    _DEBUG_FAIL("Calling GetConstPointer on a non-contiguous buffer view");
    return nullptr;
  }

  if (bufferView.GetSize() > 0) {
    return bufferView.GetCurrentFragmentIterator().GetFragment().pointer;
  } else {
    return nullptr;
  }
}

Buffer2 Buffer2ViewAccessor::EnsureContiguous(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const Buffer2View<const uint8_t*>& bufferView) {
  if (bufferView.IsContiguous()) {
    return Buffer2(bufferView);
  }

  auto contiguousBuffer = bufferFactory->CreateBuffer2(bufferView.GetSize());
  WriteBytes(contiguousBuffer, bufferView);

  return contiguousBuffer;
}

template <typename IntegralType>
IntegralType Buffer2ViewAccessor::GetBytesAsIntegralType(
    const Buffer2View<const uint8_t*>& bufferView, const size_t index) {
  IntegralType value;

  ReadBytes(bufferView, &value, index, sizeof(IntegralType));

  return system::EndiannessConverter<IntegralType>::NetworkToHost(value);
}

template <typename IntegralType>
void Buffer2ViewAccessor::SetBytesAsIntegralType(
    const Buffer2View<uint8_t*>& bufferView, const size_t index, const IntegralType item) {
  IntegralType value = system::EndiannessConverter<IntegralType>::HostToNetwork(item);
  const uint8_t* valueBytes = reinterpret_cast<const uint8_t*>(&value);

  WriteBytes(bufferView, index, valueBytes, sizeof(IntegralType));
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView, const Buffer2View<const uint8_t*>& source, const size_t length) {
  WriteBytes(bufferView, source.Slice(0, length));
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView,
    const size_t destinationOffset,
    const Buffer2View<const uint8_t*>& source) {
  WriteBytes(bufferView.Slice(destinationOffset), source);
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView,
    const size_t destinationOffset,
    const Buffer2View<const uint8_t*>& source,
    const size_t sourceOffset) {
  WriteBytes(bufferView.Slice(destinationOffset), source.Slice(sourceOffset));
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView,
    const size_t destinationOffset,
    const Buffer2View<const uint8_t*>& source,
    const size_t sourceOffset,
    const size_t length) {
  WriteBytes(bufferView.Slice(destinationOffset), source.Slice(sourceOffset, length));
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView, const Buffer2View<const uint8_t*>& source) {
  if (source.GetSize() == 0) {
    return;
  }

  auto sourceFragmentIterator = source.GetCurrentFragmentIterator();

  size_t currentDestinationOffset = 0;

  while (true) {
    const auto sourceFragment = sourceFragmentIterator.GetFragment();

    WriteBytes(bufferView, currentDestinationOffset, sourceFragment.pointer, sourceFragment.numberOfBytes);

    currentDestinationOffset += sourceFragment.numberOfBytes;

    if (sourceFragmentIterator.HasNext()) {
      sourceFragmentIterator = sourceFragmentIterator.GetNext();
    } else {
      break;
    }
  }
}

void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView, const size_t offset, const void* source, const size_t length) {
  const uint8_t* bytes = reinterpret_cast<const uint8_t*>(source);
  auto fragmentIterator = bufferView.GetCurrentFragmentIterator();

  size_t bytesLeftToVisit = length;
  size_t bytesLeftToSkip = offset;
  bool iteratorIsValid = true;

  while (bytesLeftToVisit > 0 && iteratorIsValid) {
    const system::ScopeExit advanceIteratorIfPossible([&fragmentIterator, &iteratorIsValid] {
      if (fragmentIterator.HasNext()) {
        fragmentIterator = fragmentIterator.GetNext();
      } else {
        iteratorIsValid = false;
      }
    });

    const auto fragment = fragmentIterator.GetFragment();
    const auto currentFragmentSize = fragment.numberOfBytes;
    const auto offsetIntoCurrentFragment = std::min(currentFragmentSize, bytesLeftToSkip);

    bytesLeftToSkip -= offsetIntoCurrentFragment;

    if (offsetIntoCurrentFragment == currentFragmentSize) {
      continue;
    }

    const auto bytesToWriteToCurrentFragment =
        std::min(currentFragmentSize - offsetIntoCurrentFragment, bytesLeftToVisit);

    std::memcpy(
        fragment.pointer + offsetIntoCurrentFragment, &bytes[length - bytesLeftToVisit], bytesToWriteToCurrentFragment);

    bytesLeftToVisit -= bytesToWriteToCurrentFragment;
  }

  _ASSERT(bytesLeftToVisit == 0, "Unable to write [" << bytesLeftToVisit << "] of [" << length << "]");
}

void Buffer2ViewAccessor::ReadBytes(
    const Buffer2View<const uint8_t*>& bufferView, void* destination, const size_t offset, const size_t length) {
  uint8_t* bytes = reinterpret_cast<uint8_t*>(destination);
  auto fragmentIterator = bufferView.GetCurrentFragmentIterator();

  size_t bytesLeftToVisit = length;
  size_t bytesLeftToSkip = offset;
  bool iteratorIsValid = true;

  while (bytesLeftToVisit > 0 && iteratorIsValid) {
    const system::ScopeExit advanceIteratorIfPossible([&fragmentIterator, &iteratorIsValid] {
      if (fragmentIterator.HasNext()) {
        fragmentIterator = fragmentIterator.GetNext();
      } else {
        iteratorIsValid = false;
      }
    });

    const auto fragment = fragmentIterator.GetFragment();
    const auto currentFragmentSize = fragment.numberOfBytes;
    const auto offsetIntoCurrentFragment = std::min(currentFragmentSize, bytesLeftToSkip);

    bytesLeftToSkip -= offsetIntoCurrentFragment;

    if (offsetIntoCurrentFragment == currentFragmentSize) {
      continue;
    }

    const auto bytesToReadFromCurrentFragment =
        std::min(currentFragmentSize - offsetIntoCurrentFragment, bytesLeftToVisit);

    std::memcpy(
        &bytes[length - bytesLeftToVisit],
        fragment.pointer + offsetIntoCurrentFragment,
        bytesToReadFromCurrentFragment);

    bytesLeftToVisit -= bytesToReadFromCurrentFragment;
  }

  _ASSERT(bytesLeftToVisit == 0, "Unable to read [" << bytesLeftToVisit << "] of [" << length << "]");
}

}  // namespace memory

