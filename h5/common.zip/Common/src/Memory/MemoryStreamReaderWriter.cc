
#include "Memory/MemoryStreamReaderWriter.h"

#include "Memory/Buffer2ViewAccessor.h"
#include "Memory/BufferUtilities.h"
#include "System/DebugFail.h"


namespace memory {

MemoryStreamReaderWriter::MemoryStreamReaderWriter(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const boost::optional<std::string>& name)
    : bufferFactory_(bufferFactory),
      name_(name),
      data_(bufferFactory->CreateBuffer2(0, kInitialBufferSize)),
      currentIndex_(0) {}

MemoryStreamReaderWriter::~MemoryStreamReaderWriter() {}

size_t MemoryStreamReaderWriter::WriteByte(const uint8_t byte) {
  GrowBufferIfNeeded(sizeof(byte));

  if (data_.GetCapacity() <= data_.GetSize()) {
    return 0;
  }

  if (data_.GetSize() < 1 + currentIndex_) {
    data_.SetSize(1 + currentIndex_);
  }

  Buffer2ViewAccessor::SetUInt8(byte, data_, currentIndex_);

  UpdateIndex(sizeof(byte));

  return sizeof(byte);
}

size_t MemoryStreamReaderWriter::Write(const std::shared_ptr<const IBuffer>& buffer) {
  size_t bufferSize = buffer->GetSize();
  GrowBufferIfNeeded(bufferSize);

  auto bytesToCopy = std::min(data_.GetCapacity() - currentIndex_, bufferSize);
  data_.SetSize(std::max(currentIndex_ + bytesToCopy, data_.GetSize()));

  auto bytesLeft = bytesToCopy;
  auto tempIndex = this->currentIndex_;
  buffer->Visit([this, &bytesLeft, &tempIndex](const uint8_t* iBufferData, size_t iBufferLength) {
    auto bytesLeftToCopy = std::min(bytesLeft, iBufferLength);
    memory::Buffer2ViewAccessor::WriteBytes(data_, tempIndex, iBufferData, bytesLeftToCopy);
    bytesLeft -= bytesLeftToCopy;
    tempIndex += bytesLeftToCopy;
  });

  UpdateIndex(bytesToCopy);

  return bytesToCopy;
}

size_t MemoryStreamReaderWriter::Write(const Buffer2View<const uint8_t*>& buffer) {
  size_t bufferSize = buffer.GetSize();
  GrowBufferIfNeeded(bufferSize);

  auto bytesToCopy = std::min(data_.GetCapacity() - currentIndex_, bufferSize);
  data_.SetSize(std::max(currentIndex_ + bytesToCopy, data_.GetSize()));

  auto bytesLeft = bytesToCopy;
  auto tempIndex = this->currentIndex_;
  memory::Buffer2ViewAccessor::Visit(buffer, [this, &bytesLeft, &tempIndex](const uint8_t* data, size_t length) {
    auto bytesLeftToCopy = std::min(bytesLeft, length);
    memory::Buffer2ViewAccessor::WriteBytes(data_, tempIndex, data, bytesLeftToCopy);
    bytesLeft -= bytesLeftToCopy;
    tempIndex += bytesLeftToCopy;
  });

  UpdateIndex(bytesToCopy);

  return bytesToCopy;
}

void MemoryStreamReaderWriter::Flush() {}

void MemoryStreamReaderWriter::Print(std::ostream* stream) const {
  *stream << "MemoryStreamReaderWriter[currentIndex_=" << currentIndex_ << ", name_=" << name_ << "]";
}

bool MemoryStreamReaderWriter::TrySeek(const uint64_t offset) {
  if (offset > std::numeric_limits<size_t>::max()) {
    _DEBUG_FAIL("Trying to seek past max size of current system's implementation of size_t.");
    return false;
  }

  size_t convertedOffset = static_cast<size_t>(offset);

  if (convertedOffset > data_.GetSize()) {
    _DEBUG_FAIL(
        "Trying to seek to [" << convertedOffset << "] past total size written out [" << data_.GetSize()
                              << "] for memory stream.");
    return false;
  }

  currentIndex_ = convertedOffset;

  return true;
}

uint64_t MemoryStreamReaderWriter::GetCurrentPosition() const { return currentIndex_; }

boost::optional<uint64_t> MemoryStreamReaderWriter::TryGetTotalSize() const { return GetTotalSize(); }

void MemoryStreamReaderWriter::Close() {}

bool MemoryStreamReaderWriter::TryReadByte(const size_t offset, uint8_t* byte) const {
  if (offset > data_.GetSize()) {
    _DEBUG_FAIL(
        "Trying to get byte at [" << offset << "] past total size written out [" << data_.GetSize()
                                  << "] for memory stream.");
    return false;
  }

  *byte = Buffer2ViewAccessor::ReadUInt8(data_, offset);
  return true;
}

int64_t MemoryStreamReaderWriter::TryReadDefaultLengthBlock(
    const size_t offset, std::shared_ptr<const IBuffer>* outBuffer) const {
  return TryReadVariableLengthBlock(offset, data_.GetSize(), outBuffer);
}

int64_t MemoryStreamReaderWriter::TryReadVariableLengthBlock(
    const size_t offset, const size_t length, std::shared_ptr<const IBuffer>* outBuffer) const {
  if (offset > data_.GetSize()) {
    return -1;
  }

  auto readLength = offset + length >= data_.GetSize() ? data_.GetSize() - offset : length;

  *outBuffer = memory::Buffer2(data_.Slice(offset, readLength)).MoveAsIBuffer(bufferFactory_);

  return readLength;
}

uint64_t MemoryStreamReaderWriter::GetTotalSize() const { return data_.GetSize(); }

bool MemoryStreamReaderWriter::TryGetName(std::string* name) const {
  if (name_) {
    *name = *name_;

    return true;
  }

  return false;
}

void MemoryStreamReaderWriter::Clear() {
  currentIndex_ = 0;
  data_.SetSize(0);
}

void MemoryStreamReaderWriter::GrowBufferIfNeeded(const size_t incomingSize) {
  size_t currentCapacity = std::max(static_cast<size_t>(1), data_.GetCapacity());

  while (currentIndex_ + incomingSize >= currentCapacity) {
    currentCapacity = currentCapacity << 1;
  }

  currentCapacity = std::min(bufferFactory_->kMaxBufferSize, currentCapacity);
  if (currentCapacity > data_.GetCapacity()) {
    auto newData = bufferFactory_->CreateBuffer2(data_.GetSize(), currentCapacity);
    size_t tempIndex = 0;
    memory::Buffer2ViewAccessor::Visit(
        data_.GetConstView(), [&newData, &tempIndex](const uint8_t* dataPtr, size_t length) {
          memory::Buffer2ViewAccessor::WriteBytes(newData, tempIndex, dataPtr, length);
          tempIndex += length;
        });
    data_ = std::move(newData);
  }
}

void MemoryStreamReaderWriter::UpdateIndex(const size_t newDataSize) {
  currentIndex_ += newDataSize;

  if (currentIndex_ > data_.GetSize()) {
    data_.SetSize(currentIndex_);
  }
}

int64_t MemoryStreamReaderWriter::TryReadDefaultLengthBlock(const size_t offset, Buffer2* outBuffer) const {
  return TryReadVariableLengthBlock(offset, data_.GetSize(), outBuffer);
}

int64_t MemoryStreamReaderWriter::TryReadVariableLengthBlock(
    const size_t offset, const size_t length, Buffer2* outBuffer) const {
  if (offset > data_.GetSize()) {
    return -1;
  }

  auto readLength = offset + length >= data_.GetSize() ? data_.GetSize() - offset : length;

  *outBuffer = data_.Slice(offset, readLength);

  return readLength;
}

}  // namespace memory

