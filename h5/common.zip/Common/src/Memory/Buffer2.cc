
#include "Memory/Buffer2.h"

#include <numeric>

#include "Memory/Buffer2IBufferAdapter.h"
#include "Memory/Buffer2ViewAccessor.h"
#include "Memory/BufferFactory.h"
#include "System/Assert.h"
#include "System/DebugAssert.h"
#include "System/DebugFail.h"
#include "System/Endian.h"


namespace memory {

BufferFragment& BufferFragment::operator=(BufferFragment&& other) {
  data_ = std::move(other.data_);
  capacity_ = std::move(other.capacity_);
  size_ = std::move(other.size_);
  offset_ = std::move(other.offset_);

  other.capacity_ = 0;
  other.size_ = 0;
  other.offset_ = 0;

  return *this;
}

void BufferFragment::SetSize(const size_t newSize) {
  _DEBUG_ASSERT_OR_RETURN(
      newSize <= GetAvailableBytesAfterOffset(),
      "Cannot resize fragment with capacity [" << GetCapacity() << "] and offset [" << GetOffset() << "] to ["
                                               << newSize << "]");

  size_ = newSize;
}

BufferFragment BufferFragment::Slice(const size_t offset, const size_t length) const {
  if (offset > size_) {
    _DEBUG_FAIL(
        "The sliced offset [" << offset
                              << "] of a sliced buffer fragment cannot be greater than the buffer fragment size ["
                              << size_ << "]");
    return BufferFragment();
  }

  const auto availableSliceLength = std::min(size_ - offset, length);
  _DEBUG_ASSERT(
      availableSliceLength == length,
      "The sliced offset [" << offset << "] plus sliced length [" << length
                            << "] of a sliced buffer fragment cannot be greater than the buffer fragment size ["
                            << size_ << "]");

  return BufferFragment(data_, availableSliceLength, capacity_, offset_ + offset);
}

void BufferFragment::Clear() {
  data_.reset();
  capacity_ = 0;
  size_ = 0;
  offset_ = 0;
}

void BufferFragment::ValidateConstructorParameters() {
  if (!data_) {
    _ASSERT(
        size_ == 0, "Cannot create a buffer fragment with data as nullptr with size [" << size_ << "] greater than 0");
    _ASSERT(
        capacity_ == 0,
        "Cannot create a buffer fragment with data as nullptr with capacity [" << capacity_ << "] greater than 0");
    _ASSERT(
        offset_ == 0,
        "Cannot create a buffer fragment with data as nullptr with offset [" << offset_ << "] greater than 0");
  } else {
    _ASSERT(
        offset_ + size_ <= capacity_,
        "Cannot create a buffer fragment where sum of offset [" << offset_ << "] and size [" << size_
                                                                << "] is greater than capacity [" << capacity_ << "]");
    if (capacity_ == 0) {
      data_.reset();
    }
  }
}

Buffer2::Buffer2(const std::shared_ptr<uint8_t>& data, const size_t size, const size_t capacity)
    : fragments_{{data, size, capacity}},
      size_{size},
      validFragmentsCount_{static_cast<size_t>(fragments_[0].IsValid() ? 1 : 0)} {}

Buffer2::Buffer2(std::shared_ptr<uint8_t>&& data, const size_t size, const size_t capacity)
    : fragments_{{std::move(data), size, capacity}},
      size_{size},
      validFragmentsCount_{static_cast<size_t>(fragments_[0].IsValid() ? 1 : 0)} {}

Buffer2& Buffer2::operator=(Buffer2&& other) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other.moveAsserter_);
  viewAsserter_.AssertNoViewsExist();
  Clear();
  for (size_t fragmentIndex = 0;
       fragmentIndex < kMaximumNumberOfCompositeFragments && other.fragments_[fragmentIndex].IsValid();
       ++fragmentIndex) {
    fragments_[fragmentIndex] = std::move(other.fragments_[fragmentIndex]);
  }

  size_ = std::move(other.size_);
  other.size_ = 0;
  validFragmentsCount_ = std::move(other.validFragmentsCount_);
  other.validFragmentsCount_ = 0;
  moveAsserter_.Initialize();
  _MOVE_ASSERTER_MOVE(other.moveAsserter_);
  return *this;
}

Buffer2& Buffer2::operator=(Buffer2View<uint8_t*>&& view) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(view.moveAsserter_);
  viewAsserter_.AssertNoViewsExist();
  Clear();
  size_ = view.GetSize();
  InsertFragmentsFromView(std::move(view));
  view.Clear();
  moveAsserter_.Initialize();
  _MOVE_ASSERTER_MOVE(view.moveAsserter_);
  return *this;
}

Buffer2& Buffer2::operator=(const Buffer2View<const uint8_t*>& view) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(view.moveAsserter_);
  viewAsserter_.AssertNoViewsExist();
  Clear();
  size_ = view.GetSize();
  InsertFragmentsFromView(view);
  moveAsserter_.Initialize();
  return *this;
}

void Buffer2::SetSize(const size_t newSize) {
  viewAsserter_.AssertNoViewsExist();
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  if (newSize > GetSize()) {
    _DEBUG_ASSERT_OR_RETURN(
        newSize <= GetCapacity(),
        "Attempting to resize buffer with capacity [" << GetCapacity() << "] to [" << newSize << "]");

    size_t sizeToAdd = newSize - GetSize();

    for (size_t fragmentIndex = 0;
         sizeToAdd > 0 && fragmentIndex < kMaximumNumberOfCompositeFragments && fragments_[fragmentIndex].data_;
         ++fragmentIndex) {
      auto& fragment = fragments_[fragmentIndex];
      const auto sizeToAddToFragment =
          std::min(sizeToAdd, fragment.GetAvailableBytesAfterOffset() - fragment.GetSize());

      fragment.SetSize(fragment.GetSize() + sizeToAddToFragment);

      sizeToAdd -= sizeToAddToFragment;
    }
  } else {
    size_t sizeToReduce = GetSize() - newSize;

    size_t fragmentIndex = kMaximumNumberOfCompositeFragments - 1;
    while (sizeToReduce > 0) {
      auto& fragment = fragments_[fragmentIndex];
      --fragmentIndex;

      if (!fragment.IsValid()) {
        continue;
      }

      const auto sizeToReduceFragment = std::min(sizeToReduce, fragment.GetSize());

      fragment.SetSize(fragment.GetSize() - sizeToReduceFragment);

      sizeToReduce -= sizeToReduceFragment;
    }
  }

  size_ = newSize;
}

size_t Buffer2::GetCapacity() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  size_t capacity = 0;
  for (size_t fragmentIndex = 0; fragmentIndex < kMaximumNumberOfCompositeFragments && fragments_[fragmentIndex].data_;
       ++fragmentIndex) {
    capacity += fragments_[fragmentIndex].GetAvailableBytesAfterOffset();
  }

  return capacity;
}

size_t Buffer2::GetValidFragmentsCount() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return validFragmentsCount_;
}

Buffer2::operator Buffer2View<const uint8_t*>() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return GetView();
}

Buffer2::operator Buffer2View<uint8_t*>() {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return GetView();
}

Buffer2View<const uint8_t*> Buffer2::GetView() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Buffer2View<const uint8_t*>(*this);
}

Buffer2View<uint8_t*> Buffer2::GetView() {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Buffer2View<uint8_t*>(*this);
}

Buffer2View<const uint8_t*> Buffer2::Slice(const size_t offset, const size_t length) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Buffer2View<const uint8_t*>(*this, offset, length);
}

Buffer2View<uint8_t*> Buffer2::Slice(const size_t offset, const size_t length) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Buffer2View<uint8_t*>(*this, offset, length);
}

std::shared_ptr<const IBuffer> Buffer2::AsIBuffer(const std::shared_ptr<const BufferFactory>& bufferFactory) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return std::make_shared<Buffer2IBufferAdapter>(*this);
}

std::shared_ptr<const IBuffer> Buffer2::MoveAsIBuffer(const std::shared_ptr<const BufferFactory>& bufferFactory) {
  viewAsserter_.AssertNoViewsExist();
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return std::make_shared<Buffer2IBufferAdapter>(std::move(*this));
}

template <typename TBufferView>
void Buffer2::InsertFragmentsFromView(TBufferView&& bufferView) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(bufferView.moveAsserter_);
  size_t bytesProcessed = 0;
  size_t thisFragmentIndex = 0;
  size_t fragmentOffset = bufferView.currentFragmentOffset_;

  bool fragmentMoved = false;
  for (size_t fragmentIndex = bufferView.currentFragmentIndex_;
       fragmentIndex < kMaximumNumberOfCompositeFragments && bytesProcessed < size_;
       ++fragmentIndex) {
    auto& currentFragment = bufferView.GetBuffer()->fragments_[fragmentIndex];
    if (!currentFragment.IsValid()) {
      break;
    }

    const auto numberOfFragmentBytes = std::min(currentFragment.GetSize() - fragmentOffset, size_ - bytesProcessed);

    // Placement new operator:
    new (&fragments_[thisFragmentIndex]) BufferFragment(
        std::move(currentFragment.data_),
        numberOfFragmentBytes,
        std::move(currentFragment.capacity_),
        currentFragment.offset_ + fragmentOffset);

    fragmentMoved = true;

    ++thisFragmentIndex;
    bytesProcessed += numberOfFragmentBytes;
    fragmentOffset = 0;
  }

  validFragmentsCount_ = thisFragmentIndex;

  if (!bufferView.kIsReadOnly && fragmentMoved) {
    _MOVE_ASSERTER_MOVE(bufferView.GetBuffer()->moveAsserter_);
  }
}

bool Buffer2::TryAppendWithShallowCopy(const Buffer2& buffer) {
  const auto flatteningIsNotRequired =
      validFragmentsCount_ + buffer.GetValidFragmentsCount() <= Buffer2::kMaximumNumberOfCompositeFragments;
  if (flatteningIsNotRequired) {
    ForcedAppendWithShallowCopy(buffer);
  }

  return flatteningIsNotRequired;
}

void Buffer2::ForcedAppendWithShallowCopy(const Buffer2& buffer) {
  for (size_t fragmentIndex = 0;
       fragmentIndex < Buffer2::kMaximumNumberOfCompositeFragments && buffer.fragments_[fragmentIndex].IsValid();
       ++fragmentIndex) {
    const auto& currentFragment = buffer.fragments_[fragmentIndex];

    fragments_[validFragmentsCount_++] = currentFragment.CreateShallowCopy();
    size_ += currentFragment.GetSize();
  }
}

bool Buffer2::TryAppendWithMove(Buffer2&& buffer) {
  const auto flatteningIsNotRequired =
      validFragmentsCount_ + buffer.GetValidFragmentsCount() <= Buffer2::kMaximumNumberOfCompositeFragments;
  if (flatteningIsNotRequired) {
    ForcedAppendWithMove(std::move(buffer));
  }

  return flatteningIsNotRequired;
}

void Buffer2::ForcedAppendWithMove(Buffer2&& buffer) {
  for (size_t fragmentIndex = 0;
       fragmentIndex < Buffer2::kMaximumNumberOfCompositeFragments && buffer.fragments_[fragmentIndex].IsValid();
       ++fragmentIndex) {
    auto& currentFragment = buffer.fragments_[fragmentIndex];

    size_ += currentFragment.GetSize();
    fragments_[validFragmentsCount_++] = std::move(currentFragment);
  }

  buffer.size_ = 0;
  buffer.validFragmentsCount_ = 0;
  _MOVE_ASSERTER_MOVE(buffer.moveAsserter_);
}

void Buffer2::Clear() {
  for (auto& fragment : fragments_) {
    fragment.Clear();
  }

  size_ = 0;
  validFragmentsCount_ = 0;
}

void Buffer2::EnsureValidFragmentsAreInFrontOfTheBuffer() {
  validFragmentsCount_ = 0;
  for (size_t fragmentIndex = 0; fragmentIndex < kMaximumNumberOfCompositeFragments; ++fragmentIndex) {
    if (fragments_[fragmentIndex].data_) {
      if (!fragments_[validFragmentsCount_].data_) {
        fragments_[validFragmentsCount_++] = std::move(fragments_[fragmentIndex]);
      } else {
        validFragmentsCount_++;
      }
    }
  }
}

std::ostream& operator<<(std::ostream& stream, const Buffer2& buffer2) {
  stream << "Buffer2[fragmentsSizes={";

  Buffer2ViewAccessor::Visit(
      buffer2, [&stream, firstFragment = true](const uint8_t*, const size_t fragmentSize) mutable {
        if (!firstFragment) {
          stream << ", ";
        }

        stream << fragmentSize;
        firstFragment = false;
      });

  stream << "}, capacity=" << buffer2.GetCapacity() << "]";

  return stream;
}

// explicit template instantiations
template void Buffer2::InsertFragmentsFromView<Buffer2View<uint8_t*>>(Buffer2View<uint8_t*>&&);
template void Buffer2::InsertFragmentsFromView<const Buffer2View<const uint8_t*>&>(const Buffer2View<const uint8_t*>&);

}  // namespace memory

