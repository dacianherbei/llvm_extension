
#include "Memory/StringBufferWriterAdapter.h"

#include "Memory/BufferUtilities.h"


namespace memory {

StringBufferWriterAdapter::StringBufferWriterAdapter(
    const std::shared_ptr<const BufferFactory>& bufferFactory, const std::shared_ptr<IBufferWriter>& bufferWriter)
    : bufferFactory_(bufferFactory), bufferWriter_(bufferWriter) {}

StringBufferWriterAdapter::~StringBufferWriterAdapter() {}

size_t StringBufferWriterAdapter::Write() {
  auto finalString = stringStream_.str();
  auto buffer = memory::BufferUtilities::CreateBufferWithData(bufferFactory_, finalString);
  stringStream_.flush();
  return bufferWriter_->Write(buffer);
}

size_t StringBufferWriterAdapter::Write(const std::string& stringToWrite) {
  auto buffer = memory::BufferUtilities::CreateBufferWithData(bufferFactory_, stringToWrite);
  return bufferWriter_->Write(buffer);
}

}  // namespace memory

