
#pragma once

#include "Memory/Buffer2.h"


namespace memory {

inline BufferFragment::BufferFragment() : data_(), capacity_(0), size_(0), offset_(0) {}

inline BufferFragment::BufferFragment(
    const std::shared_ptr<uint8_t>& data, const size_t size, const size_t capacity, const size_t offset)
    : data_(data), capacity_(capacity), size_(size), offset_(offset) {
  ValidateConstructorParameters();
}

inline BufferFragment::BufferFragment(
    std::shared_ptr<uint8_t>&& data, const size_t size, const size_t capacity, const size_t offset)
    : data_(std::move(data)), capacity_(capacity), size_(size), offset_(offset) {
  ValidateConstructorParameters();
}

inline BufferFragment::BufferFragment(BufferFragment&& other)
    : data_(std::move(other.data_)),
      capacity_(std::move(other.capacity_)),
      size_(std::move(other.size_)),
      offset_(std::move(other.offset_)) {
  other.capacity_ = 0;
  other.size_ = 0;
  other.offset_ = 0;
}

inline BufferFragment::~BufferFragment() {}

inline uint8_t* BufferFragment::GetRawPointer() { return data_.get() + offset_; }

inline BufferFragment BufferFragment::CreateShallowCopy() const {
  return BufferFragment(data_, size_, capacity_, offset_);
}

inline const uint8_t* BufferFragment::GetRawPointer() const { return data_.get() + offset_; }

inline size_t BufferFragment::GetSize() const { return size_; }

inline size_t BufferFragment::GetAvailableBytesAfterOffset() const { return capacity_ - offset_; }

inline size_t BufferFragment::GetCapacity() const { return capacity_; }

inline size_t BufferFragment::GetOffset() const { return offset_; }

inline bool BufferFragment::IsValid() const { return capacity_ > 0; }

inline Buffer2::Buffer2() : fragments_{}, size_{0}, validFragmentsCount_{0}, moveAsserter_{} {}

inline Buffer2::Buffer2(const Buffer2View<const uint8_t*>& bufferView)
    : fragments_{}, size_{bufferView.GetSize()}, validFragmentsCount_{0}, moveAsserter_{} {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(bufferView.moveAsserter_);
  InsertFragmentsFromView(bufferView);
}

inline Buffer2::Buffer2(Buffer2View<uint8_t*>&& bufferView)
    : fragments_{}, size_{bufferView.GetSize()}, validFragmentsCount_{0}, moveAsserter_{} {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(bufferView.moveAsserter_);
  InsertFragmentsFromView(std::move(bufferView));
  bufferView.Clear();
  _MOVE_ASSERTER_MOVE(bufferView.moveAsserter_);
}

inline Buffer2::Buffer2(Buffer2&& other)
    : fragments_{},
      size_{std::move(other.size_)},
      validFragmentsCount_{std::move(other.validFragmentsCount_)},
      moveAsserter_{} {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other.moveAsserter_);
  for (size_t fragmentIndex = 0;
       fragmentIndex < kMaximumNumberOfCompositeFragments && other.fragments_[fragmentIndex].IsValid();
       ++fragmentIndex) {
    fragments_[fragmentIndex] = std::move(other.fragments_[fragmentIndex]);
  }

  other.size_ = 0;
  other.validFragmentsCount_ = 0;
  _MOVE_ASSERTER_MOVE(other.moveAsserter_);
}

// move assertion is detected when accessing GetView()
inline Buffer2 Buffer2::CreateShallowCopy() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  Buffer2 shallowCopy;

  for (size_t fragmentIndex = 0;
       fragmentIndex < kMaximumNumberOfCompositeFragments && fragments_[fragmentIndex].IsValid();
       ++fragmentIndex) {
    shallowCopy.fragments_[fragmentIndex] = fragments_[fragmentIndex].CreateShallowCopy();
  }

  shallowCopy.size_ = size_;
  shallowCopy.validFragmentsCount_ = validFragmentsCount_;

  return shallowCopy;
}

inline Buffer2::~Buffer2() { viewAsserter_.AssertNoViewsExist(); }

inline size_t Buffer2::GetSize() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return size_;
}

// move asserted throough the call to GetView
inline Buffer2View<const uint8_t*> Buffer2::GetConstView() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return GetView();
}

// move asserted throough the call to Slice
inline Buffer2View<const uint8_t*> Buffer2::Slice(const size_t offset) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Slice(offset, size_ - offset);
}

// move asserted throough the call to Slice
inline Buffer2View<uint8_t*> Buffer2::Slice(const size_t offset) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  return Slice(offset, size_ - offset);
}

// move asserted throough the call to GetView
inline bool Buffer2::operator==(const Buffer2View<const uint8_t*>& other) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other.moveAsserter_);
  return GetView() == other;
}

// move asserted throough the call to == operator
inline bool Buffer2::operator!=(const Buffer2View<const uint8_t*>& other) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(moveAsserter_);
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other.moveAsserter_);
  return !(*this == other);
}

inline void Buffer2::AssertOnAccessToMovedObject(const char* const caller) const {
  moveAsserter_.AssertOnAccessToMovedObject(caller);
}

}  // namespace memory

