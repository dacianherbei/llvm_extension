
#pragma once

#include "Memory/Buffer2ViewAccessor.h"

#include <type_traits>

#include "Memory/BufferFactory.h"


namespace memory {

inline void Buffer2ViewAccessor::WriteBytes(
    const Buffer2View<uint8_t*>& bufferView, const void* source, const size_t length) {
  WriteBytes(bufferView, 0, source, length);
}

inline void Buffer2ViewAccessor::ReadBytes(
    const Buffer2View<const uint8_t*>& bufferView, void* destination, const size_t length) {
  ReadBytes(bufferView, destination, 0, length);
}

template <typename TCallable>
inline void Buffer2ViewAccessor::VisitContiguous(
    const std::shared_ptr<const BufferFactory>& bufferFactory,
    const Buffer2View<const uint8_t*>& bufferView,
    TCallable&& accessor) {
  if (bufferView.GetSize() == 0) {
    return;
  }

  if (bufferView.IsContiguous()) {
    const auto fragmentInfo = bufferView.GetCurrentFragmentIterator().GetFragment();
    accessor(fragmentInfo.pointer, fragmentInfo.numberOfBytes);
  } else {
    auto temporaryBuffer = bufferFactory->CreateBuffer2(bufferView.GetSize());
    auto temporaryBufferView = temporaryBuffer.GetView();
    WriteBytes(temporaryBufferView, bufferView);
    VisitContiguous(bufferFactory, temporaryBufferView, std::move(accessor));
  }
}

template <typename TCallable>
inline void Buffer2ViewAccessor::Visit(const Buffer2& buffer, TCallable&& accessor) {
  Buffer2ViewAccessor::Visit(buffer.GetView(), std::move(accessor));
}

template <typename DataType, typename TCallable>
inline void Buffer2ViewAccessor::Visit(const Buffer2View<DataType*>& bufferView, TCallable&& accessor) {
  static_assert(
      std::is_same<const uint8_t, DataType>::value || std::is_same<uint8_t, DataType>::value,
      "Buffer2View supported type is uint8_t");
  if (bufferView.GetSize() == 0) {
    return;
  }

  auto fragmentIterator = bufferView.GetCurrentFragmentIterator();

  bool hasNext = false;
  do {
    const auto fragmentInfo = fragmentIterator.GetFragment();
    using accessorReturnedType = decltype(accessor(fragmentInfo.pointer, fragmentInfo.numberOfBytes));
    accessorReturnedType* ptr = nullptr;

    if (!Execute(ptr, accessor, fragmentInfo.pointer, fragmentInfo.numberOfBytes)) {
      break;
    }

    hasNext = fragmentIterator.HasNext();
    if (hasNext) {
      fragmentIterator = fragmentIterator.GetNext();
    }
  } while (hasNext);
}

template <typename TCallable, typename... ArgTypes>
inline bool Buffer2ViewAccessor::Execute(void* ptr, TCallable&& accessor, ArgTypes&&... args) {
  accessor(std::forward<ArgTypes>(args)...);
  return true;
}

template <typename TCallable, typename... ArgTypes>
inline bool Buffer2ViewAccessor::Execute(bool* ptr, TCallable&& accessor, ArgTypes&&... args) {
  return accessor(std::forward<ArgTypes>(args)...);
}

}  // namespace memory

