
#pragma once

#include "Memory/Buffer2View.h"

#include "System/Assert.h"
#include "System/DebugAssert.h"
#include "System/DebugFail.h"


namespace memory {

template <typename TMemoryPointer>
inline Buffer2View<TMemoryPointer>::Buffer2View()
    : buffer_(nullptr), size_(0), currentFragmentIndex_(0), currentFragmentOffset_(0) {}

template <typename TMemoryPointer>
inline Buffer2View<TMemoryPointer>::Buffer2View(const Buffer2View& other)
    : buffer_(other.buffer_),
      size_(other.size_),
      currentFragmentIndex_(other.currentFragmentIndex_),
      currentFragmentOffset_(other.currentFragmentOffset_) {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  IncrementViewCount();
}

template <typename TMemoryPointer>
template <typename TOtherMemoryPointer>
Buffer2View<TMemoryPointer>::Buffer2View(Buffer2View<TOtherMemoryPointer>&& other)
    : Buffer2View(std::move(*reinterpret_cast<Buffer2View<const uint8_t*>*>(&other))) {
  static_assert(std::is_same<const uint8_t*, TMemoryPointer>(), "Only allowed conversion is to const uint8_t*");
}

template <typename TMemoryPointer>
inline size_t Buffer2View<TMemoryPointer>::GetSize() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  return size_;
}

template <typename TMemoryPointer>
Buffer2View<TMemoryPointer>::operator const Buffer2View<const uint8_t*>&() const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  return *reinterpret_cast<const Buffer2View<const uint8_t*>*>(this);
}

template <typename TMemoryPointer>
inline Buffer2View<TMemoryPointer> Buffer2View<TMemoryPointer>::Slice(const size_t offset) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  return Slice(offset, GetSize() - offset);
}

template <typename TMemoryPointer>
inline Buffer2View<TMemoryPointer> Buffer2View<TMemoryPointer>::Slice(const size_t offset, const size_t length) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  if (offset > GetSize()) {
    _DEBUG_FAIL("Offset [" << offset << "] cannot be greater than total view size [" << GetSize() << "]");
    return Buffer2View(nullptr, 0, 0, 0);
  }

  const size_t availableLength = std::min(length, GetSize() - offset);

  _DEBUG_ASSERT(
      availableLength == length,
      "Attempting to slice [" << length << "] bytes at offset [" << offset << "] but only have [" << GetSize() - offset
                              << "] available");

  size_t fragmentIndex;
  size_t fragmentOffset;
  AdvanceBy(offset, &fragmentIndex, &fragmentOffset);

  return Buffer2View(buffer_, availableLength, fragmentIndex, fragmentOffset);
}

template <typename TMemoryPointer>
inline bool Buffer2View<TMemoryPointer>::operator!=(const Buffer2View<TMemoryPointer>& other) const {
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT((*this));
  _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(other);
  return !(*this == other);
}

}  // namespace memory

