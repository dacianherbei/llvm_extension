
#include "Memory/StringBufferUtilities.h"

#include <algorithm>
#include <cstring>

#include "Memory/Buffer2ViewAccessor.h"
#include "System/Assert.h"


namespace memory {

StringBufferUtilities::StringBufferUtilities() {}

StringBufferUtilities::~StringBufferUtilities() {}

std::string StringBufferUtilities::ToAsciiString(const std::shared_ptr<const memory::IBuffer>& buffer) {
  std::stringstream stream;

  if (buffer == nullptr) {
    stream << "<null>";
  } else {
    buffer->Visit([&stream](const uint8_t* data, size_t length) {
      for (size_t i = 0; i < length; ++i) {
        stream << data[i];
      }
    });
  }

  return stream.str();
}

std::string StringBufferUtilities::ToAsciiString(
    const std::shared_ptr<const IBuffer>& buffer, size_t numberOfCharactersToRead) {
  _ASSERT(
      numberOfCharactersToRead <= buffer->GetSize(),
      "Cannot read beyond end of buffer.  Tried to read ["
          << numberOfCharactersToRead << "] characters from buffer of size [" << buffer->GetSize() << "]");

  std::stringstream stream;

  if (buffer == nullptr) {
    stream << "<null>";
  } else {
    size_t numberAlreadyRead = 0;
    buffer->Visit([&stream, &numberOfCharactersToRead, &numberAlreadyRead](const uint8_t* data, size_t length) {
      uint32_t i;
      for (i = 0; i < (numberOfCharactersToRead - numberAlreadyRead) && (i < length); i++) {
        stream << data[i];
      }
      numberAlreadyRead += i;
    });
  }

  return stream.str();
}

std::string StringBufferUtilities::ToAsciiString(const memory::Buffer2View<const uint8_t*>& view) {
  std::stringstream stream;

  memory::Buffer2ViewAccessor::Visit(view, [&stream](const uint8_t* data, size_t length) {
    for (size_t i = 0; i < length; ++i) {
      stream << data[i];
    }
  });

  return stream.str();
}

std::string StringBufferUtilities::ToAsciiString(
    const memory::Buffer2View<const uint8_t*>& view, size_t numberOfCharactersToRead) {
  _ASSERT(
      numberOfCharactersToRead <= view.GetSize(),
      "Cannot read beyond end of buffer.  Tried to read ["
          << numberOfCharactersToRead << "] characters from buffer of size [" << view.GetSize() << "]");

  std::stringstream stream;

  size_t numberAlreadyRead = 0;
  memory::Buffer2ViewAccessor::Visit(
      view, [&stream, &numberAlreadyRead, numberOfCharactersToRead](const uint8_t* data, size_t length) {
        size_t i;
        for (i = 0; i < (numberOfCharactersToRead - numberAlreadyRead) && (i < length); i++) {
          stream << data[i];
        }
        numberAlreadyRead += i;
      });

  return stream.str();
}

}  // namespace memory

