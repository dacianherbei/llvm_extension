
#include "Memory/BufferFactory.h"

#include <cmath>

#include "Exceptions/IStackTraceProvider.h"
#include "Math/MathUtilities.h"
#include "Memory/Pool.h"
#include "Memory/SlicedBuffer.h"
#include "System/Assert.h"
#include "System/Fail.h"


namespace memory {

constexpr size_t BufferFactory::kPageSize;
constexpr size_t BufferFactory::kMaxBufferSize;

struct BufferFactory::Impl {
  std::allocator<uint8_t> dataSharedPtrAllocator;
  std::allocator<Buffer> bufferAllocator;
  std::allocator<CompositeBuffer> compositeBufferAllocator;
  std::allocator<uint8_t> allocator;
};

BufferFactory::BufferFactory(
    const std::allocator<uint8_t>& allocator,
    const boost::optional<std::shared_ptr<exceptions::IStackTraceProvider>> stackTraceProvider)
    : impl_{std::make_unique<Impl>()}, stackTraceProvider_{stackTraceProvider} {}

BufferFactory::~BufferFactory() {}

Buffer2 BufferFactory::CreateBuffer2(const size_t size) const {
  const uint32_t capacity = CalculateBufferCapacity(size);
  return CreateBuffer2(size, capacity);
}

Buffer2 BufferFactory::CreateAlignedBuffer2(const size_t size, const size_t alignment) const {
  auto localAlignment = alignment;
  if (localAlignment == 0) {
    _DEBUG_FAIL("Alignment must be greater than 0");
    localAlignment++;
  }

  _DEBUG_ASSERT(
      !(localAlignment & (localAlignment - 1)), "Alignment [" << localAlignment << "] is not power of 2");

  const size_t allocateBufferSize = size + (localAlignment - 1);
  const uint32_t capacity = CalculateBufferCapacity(allocateBufferSize);

  _ASSERT(
      capacity >= size, "Capacity [" << capacity << "] should be greater or equal than size [" << size << "]");

  try {
    uint8_t* data = capacity == 0 ? nullptr : impl_->allocator.allocate(capacity);
    std::shared_ptr<uint8_t> dataPtr(
        data,
        [capacity, allocator = impl_->allocator](uint8_t* ptr) mutable {
          if (capacity > 0) {
            allocator.deallocate(ptr, capacity);
          }
        },
        impl_->dataSharedPtrAllocator);

    const auto memoryAddress = dataPtr.get();
    const uintptr_t unalignedAddress = reinterpret_cast<uintptr_t>(memoryAddress);
    const size_t alignedAddress = math::MathUtilities::RoundUpToNearestMultiple(unalignedAddress, localAlignment);
    const size_t alignmentOffset = alignedAddress - unalignedAddress;
    auto alignedDataPtr = std::shared_ptr<uint8_t>(std::move(dataPtr), memoryAddress + alignmentOffset);

    return Buffer2{std::move(alignedDataPtr), size, size};
  } catch (const std::bad_alloc& exception) {
    _FAIL(
        "Failed to allocate buffer with size [" << size << "] bytes. Exception message: [" << exception.what() << "]");
  }
}

Buffer2 BufferFactory::CreateBuffer2(const size_t size, const size_t capacity) const {
  _ASSERT(
      capacity >= size, "Capacity [" << capacity << "] should be greater or equal than size [" << size << "]");

  try {
    uint8_t* data = capacity == 0 ? nullptr : impl_->allocator.allocate(capacity);
    std::shared_ptr<uint8_t> dataPtr(
        data,
        [capacity, allocator = impl_->allocator](uint8_t* ptr) mutable {
          if (capacity > 0) {
            allocator.deallocate(ptr, capacity);
          }
        },
        impl_->dataSharedPtrAllocator);

    return Buffer2(std::move(dataPtr), size, capacity);
  } catch (const std::bad_alloc& exception) {
    _FAIL(
        "Failed to allocate buffer with size [" << size << "] bytes. Exception message: [" << exception.what() << "]");
  }
}

std::shared_ptr<Buffer> BufferFactory::CreateBuffer(const size_t size) const {
  const uint32_t capacity = CalculateBufferCapacity(size);
  return CreateBuffer(size, capacity);
}

std::shared_ptr<Buffer> BufferFactory::CreateBuffer(const size_t size, const size_t capacity) const {
  _ASSERT(
      capacity >= size, "Capacity [" << capacity << "] should be greater or equal than size [" << size << "]");
  try {
    uint8_t* data = capacity == 0 ? nullptr : impl_->allocator.allocate(capacity);
    std::shared_ptr<uint8_t> dataPtr(
        data,
        [capacity, allocator = impl_->allocator](uint8_t* ptr) mutable {
          if (capacity > 0) {
            allocator.deallocate(ptr, capacity);
          }
        },
        impl_->dataSharedPtrAllocator);

    return std::allocate_shared<Buffer>(impl_->bufferAllocator, dataPtr, size, capacity);
  } catch (const std::bad_alloc& exception) {
    _FAIL(
        "Failed to allocate buffer with size [" << size << "] bytes. Exception message: [" << exception.what() << "]");
  }
}

std::shared_ptr<CompositeBuffer> BufferFactory::CreateBuffer(
    const std::vector<std::shared_ptr<const IBuffer>>& buffers) const {
  return std::allocate_shared<CompositeBuffer>(impl_->compositeBufferAllocator, buffers);
}

std::shared_ptr<CompositeBuffer> BufferFactory::CreateBuffer(
    std::vector<std::shared_ptr<const IBuffer>>&& buffers) const {
  return std::allocate_shared<CompositeBuffer>(impl_->compositeBufferAllocator, std::move(buffers));
}

const std::allocator<uint8_t>& BufferFactory::GetAllocator() const { return impl_->allocator; }

bool BufferFactory::CompositionRequiresFlattening(
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end) {
  size_t validFragmentsCount = 0;
  for (auto it = begin; it != end; ++it) {
    validFragmentsCount += it->get().GetValidFragmentsCount();
    if (validFragmentsCount > Buffer2::kMaximumNumberOfCompositeFragments) {
      return true;
    }
  }

  return false;
}

Buffer2 BufferFactory::FlattenRange(
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end) const {
  auto flattenBuffer = CreateBuffer2(GetCumulativeBufferSize(begin, end));

  auto offset = 0;
  for (auto it = begin; it != end; ++it) {
    Buffer2ViewAccessor::WriteBytes(flattenBuffer, offset, it->get());
    offset += it->get().GetSize();
  }

  return flattenBuffer;
}

size_t BufferFactory::GetCumulativeBufferSize(
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
    const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end) {
  size_t totalSize = 0;
  for (auto it = begin; it != end; ++it) {
    totalSize += it->get().GetSize();
  }
  return totalSize;
}

uint32_t BufferFactory::CalculateBufferCapacity(const size_t inputSize) const {
  _ASSERT(
      inputSize <= kMaxBufferSize,
      "Buffer size [" << inputSize << "] should be less than or equal to [" << kMaxBufferSize << "]");

  //  round up to next largest power of 2
  const uint32_t nextLargestPowerOf2 = math::MathUtilities::GetNextPowerOfTwo(static_cast<uint32_t>(inputSize));

  const uint32_t multipleOfPageSize =
      static_cast<uint32_t>(math::MathUtilities::RoundUpToNearestMultiple(inputSize, kPageSize));

  return std::min(nextLargestPowerOf2, multipleOfPageSize);
}

void BufferFactory::AssertOnCompositionFailure() const {
  _DEBUG_FAIL(
      "Attempting to composite buffers with more than ["
      << Buffer2::kMaximumNumberOfCompositeFragments << "] fragments. Will flatten buffers into a single fragment. "
      << "Optimize composition or silence by using CreateBuffer2AllowAutoFlatten instead of CreateBuffer2."
      << " Stack trace: "
      << ((!stackTraceProvider_) ? "provider is not initialized." : stackTraceProvider_->get()->GetStackTrace()));
}

}  // namespace memory

