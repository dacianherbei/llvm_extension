
#include <cstdint>

#include "Memory/BufferByteUtilities.h"


namespace memory {

template <>
int8_t BufferByteUtilities::GetBytes<int8_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetInt8(index);
}
template <>
int16_t BufferByteUtilities::GetBytes<int16_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetInt16(index);
}
template <>
int32_t BufferByteUtilities::GetBytes<int32_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetInt32(index);
}
template <>
int64_t BufferByteUtilities::GetBytes<int64_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetInt64(index);
}

template <>
uint8_t BufferByteUtilities::GetBytes<uint8_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt8(index);
}
template <>
uint16_t BufferByteUtilities::GetBytes<uint16_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt16(index);
}
template <>
system::Uint24_t BufferByteUtilities::GetBytes<system::Uint24_t>(
    size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt24(index);
}
template <>
uint32_t BufferByteUtilities::GetBytes<uint32_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt32(index);
}
template <>
system::Uint48_t BufferByteUtilities::GetBytes<system::Uint48_t>(
    size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt48(index);
}
template <>
uint64_t BufferByteUtilities::GetBytes<uint64_t>(size_t index, const std::shared_ptr<const IBuffer>& buffer) {
  return buffer->GetUInt64(index);
}

BufferVisitorType BufferByteUtilities::CreateRangeBufferVisitor(
    size_t start, size_t end, const BufferVisitorType& visitor) {
  return [ start, remaining = size_t(end - start), &visitor ](const uint8_t* data, size_t length) mutable {
    size_t offset = std::min(start, length);
    int64_t bytesToVisit = std::min(length - offset, remaining);

    if (bytesToVisit > 0) {
      visitor(data + start, static_cast<size_t>(bytesToVisit));
      remaining -= static_cast<size_t>(bytesToVisit);
    }
    start -= offset;
  };
}

}  // namespace memory

