
#include "Exceptions/Glibc/GlibcStackTraceProvider.h"

#include <execinfo.h>

#include <cstring>
#include <sstream>

#include <cxxabi.h>

#include "System/ScopeExit.h"


namespace exceptions {

GlibcStackTraceProvider::GlibcStackTraceProvider() {}
GlibcStackTraceProvider::~GlibcStackTraceProvider() {}

std::string GlibcStackTraceProvider::GetStackTrace() const {
  static const uint32_t kNumberOfStackTraceEntries = 256;
  void* stackTraceArray[kNumberOfStackTraceEntries];
  size_t numberEntriesInStackTrace;

  // get void*'s for all entries on the stack
  numberEntriesInStackTrace = backtrace(stackTraceArray, kNumberOfStackTraceEntries);
  if (numberEntriesInStackTrace == 0) {
    return "ERROR -- Unable to get stack trace: backtrace returned 0 entries";
  }

  char** functionNames = backtrace_symbols(stackTraceArray, numberEntriesInStackTrace);
  if (functionNames == nullptr) {
    return "ERROR -- Unable to get stack trace: backtrace_symbols returned null";
  }

  system::ScopeExit scopeExit([functionNames]() { free(functionNames); });

  std::stringstream stackTraceStream;
  for (size_t i = 1; i < numberEntriesInStackTrace; ++i) {
    DemangleFunction(functionNames[i], &stackTraceStream);
  }

  auto returnString = stackTraceStream.str();
  if (returnString.size() == 0) {
    return "ERROR -- Unable to get stack trace: DemangleFunction returned completely empty string";
  }

  return returnString;
}

std::string GlibcStackTraceProvider::GetStackTraceAfterSignal(const Signal& signalInfo) const {
  return GetStackTrace();
}

void GlibcStackTraceProvider::DemangleFunction(char* functionName, std::stringstream* stackTraceStream) const {
  char *beginName = 0, *beginOffset = 0, *endOffset = 0;

  // allocate string which will be filled with the demangled function name
  size_t functionNameSize = 256;
  char* demangledFunctionName = reinterpret_cast<char*>(malloc(functionNameSize));
  system::ScopeExit scopeExit([&demangledFunctionName]() { free(demangledFunctionName); });

  // find parentheses and +address offset surrounding the mangled name:
  // ./module(function+0x15c) [0x8048a6d]
  for (char* functionNamePointer = functionName; *functionNamePointer; ++functionNamePointer) {
    if (*functionNamePointer == '(') {
      beginName = functionNamePointer;
    } else if (*functionNamePointer == '+') {
      beginOffset = functionNamePointer;
    } else if (*functionNamePointer == ')' && beginOffset) {
      endOffset = functionNamePointer;
      break;
    }
  }

  if (beginName && beginOffset && endOffset && beginName < beginOffset) {
    *beginName++ = '\0';
    *beginOffset++ = '\0';
    *endOffset = '\0';

    // mangled name is now in [beginName, beginOffset) and caller
    // offset in [beginOffset, endOffset). now apply
    // __cxa_demangle():

    int status;
    char* demangledName = abi::__cxa_demangle(beginName, demangledFunctionName, &functionNameSize, &status);
    if (status == 0) {
      demangledFunctionName = demangledName;  // use possibly realloc()-ed string
      *stackTraceStream << functionName << " : " << demangledFunctionName << "+" << beginOffset << std::endl;
    } else {
      // demangling failed. Output function name as a C function with
      // no arguments.
      *stackTraceStream << functionName << " : " << beginName << "()+" << beginOffset << std::endl;
    }
  } else {
    // couldn't parse the line? print the whole line.
    *stackTraceStream << functionName << std::endl;
  }
}

}  // namespace exceptions

