
#include "Exceptions/Apple/AppleStackTraceProvider.h"

#include <execinfo.h>

#include <array>
#include <cstring>
#include <sstream>

#include <cxxabi.h>

#include "System/ScopeExit.h"


namespace exceptions {

const size_t AppleStackTraceProvider::kMaxStackDepth;

AppleStackTraceProvider::AppleStackTraceProvider() {}
AppleStackTraceProvider::~AppleStackTraceProvider() {}

std::string AppleStackTraceProvider::GetStackTrace() const {
  std::array<void*, kMaxStackDepth> stackTraceArray;
  size_t numberEntriesInStackTrace;

  // get void*'s for all entries on the stack
  numberEntriesInStackTrace = backtrace(stackTraceArray.begin(), stackTraceArray.size());
  char** functionNames = backtrace_symbols(stackTraceArray.begin(), numberEntriesInStackTrace);
  system::ScopeExit scopeExit([functionNames]() { free(functionNames); });

  std::stringstream stackTraceStream;
  for (int i = 1; i < std::min(numberEntriesInStackTrace, kMaxStackDepth); ++i) {
    DemangleFunction(functionNames[i], &stackTraceStream);
  }

  return stackTraceStream.str();
}

std::string AppleStackTraceProvider::GetStackTraceAfterSignal(const Signal& signalInfo) const {
  return GetStackTrace();
}

void AppleStackTraceProvider::DemangleFunction(char* functionName, std::stringstream* stackTraceStream) const {
  size_t demangledFunctionNameSize = 1024;
  char* demangledFunctionName = reinterpret_cast<char*>(malloc(demangledFunctionNameSize));
  system::ScopeExit scopeExit([&demangledFunctionName]() { free(demangledFunctionName); });
  char* beginName = NULL;
  char* beginOffset = NULL;

  // find parentheses and +address offset surrounding the mangled name
  // OSX style stack trace
  for (char* functionNamePointer = functionName; *functionNamePointer; ++functionNamePointer) {
    if ((*functionNamePointer == '_') && (*(functionNamePointer - 1) == ' ')) {
      beginName = functionNamePointer - 1;
    } else if (*functionNamePointer == '+') {
      beginOffset = functionNamePointer - 1;
    }
  }

  if (beginName && beginOffset && (beginName < beginOffset)) {
    *beginName++ = '\0';
    *beginOffset++ = '\0';

    // mangled name is now in [beginName, beginOffset) and caller
    // offset in [beginOffset, endOffset). now apply
    // __cxa_demangle():
    int status;
    char* demangledName =
        abi::__cxa_demangle(beginName, &demangledFunctionName[0], &demangledFunctionNameSize, &status);
    if (status == 0) {
      demangledFunctionName = demangledName;  // use possibly realloc()-ed string
      *stackTraceStream << functionName << " : " << demangledFunctionName << beginOffset << std::endl;
    } else {
      // demangling failed. Output function name as a C function with
      // no arguments.
      *stackTraceStream << functionName << " : " << beginName << "()+" << beginOffset << std::endl;
    }
  } else {
    // couldn't parse the line? print the whole line.
    *stackTraceStream << functionName << std::endl;
  }
}

}  // namespace exceptions

