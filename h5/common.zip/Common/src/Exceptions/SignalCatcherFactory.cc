
#include "Exceptions/SignalCatcherFactory.h"

#if defined(_MSC_VER)
#include "Exceptions/MSVC/VisualStudioSignalCatcher.h"
#else
#include "Exceptions/Posix/PosixSignalCatcher.h"
#endif  // defined(_MSC_VER)


namespace exceptions {

SignalCatcherFactory::SignalCatcherFactory() {}

SignalCatcherFactory::~SignalCatcherFactory() {}

std::shared_ptr<ISignalCatcher> SignalCatcherFactory::CreateSignalCatcher() const {
#if defined(_MSC_VER)
  return VisualStudioSignalCatcher::GetInstance();
#else
  return PosixSignalCatcher::GetInstance();
#endif  // defined(_MSC_VER)
}

}  // namespace exceptions

