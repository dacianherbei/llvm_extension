
#include "Exceptions/Android/AndroidStackTraceProvider.h"

#if !defined(__BIONIC_HAVE_UCONTEXT_T) && defined(__arm__) && !defined(__BIONIC_HAVE_STRUCT_SIGCONTEXT)
#include <asm/sigcontext.h>
#endif

// These enables us to quickly turn on or off support for the 3 methods used
// to try to obtain an Android stack trace
#define USE_UNWIND
#define USE_CORKSCREW
#define USE_LIBUNWIND

#if (defined(USE_UNWIND) && !defined(USE_CORKSCREW))
#include <unwind.h>
#endif  // (defined(USE_UNWIND) && !defined(USE_CORKSCREW))

#include <dlfcn.h>

#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <sstream>

#include <cxxabi.h>

#include "System/ScopeExit.h"


namespace exceptions {

#ifdef USE_UNWIND
struct BacktraceState {
  void** current;
  void** end;
};
#endif  // USE_UNWIND

#ifdef USE_LIBUNWIND
typedef int (*BacktraceFunction)(void** buffer, int size);
#endif  // USE_LIBUNWIND

#ifdef USE_CORKSCREW
// Extracted from Android's include/corkscrew/backtrace.h
typedef struct {
  uintptr_t absolute_pc;
  uintptr_t stack_top;
  size_t stack_size;
} BacktraceFrame;
typedef struct {
  uintptr_t relative_pc;
  uintptr_t relative_symbol_addr;
  char* map_name;
  char* symbol_name;
  char* demangled_name;
} BacktraceSymbol;

typedef struct map_info_t map_info_t;

typedef ssize_t (*UnwindBacktraceSignalArch)(
    siginfo_t* si, void* sc, const map_info_t* lst, BacktraceFrame* bt, size_t ignore_depth, size_t max_depth);
typedef map_info_t* (*AcquireMyMapInfoList)();
typedef void (*ReleaseMyMapInfoList)(map_info_t* milist);
typedef void (*GetBacktraceSymbols)(const BacktraceFrame* backtrace, size_t frames, BacktraceSymbol* symbols);
typedef void (*FreeBacktraceSymbols)(BacktraceSymbol* symbols, size_t frames);
#endif  // USE_CORKSCREW

AndroidStackTraceProvider::AndroidStackTraceProvider() {}
AndroidStackTraceProvider::~AndroidStackTraceProvider() {}

std::string AndroidStackTraceProvider::GetStackTrace() const {
  return GetStackTraceAfterSignalUnwind(Signal{nullptr, nullptr});
}

std::string AndroidStackTraceProvider::GetStackTraceAfterSignal(const Signal& signalInfo) const {
  std::string trace = GetStackTraceAfterSignalCorkscrew(signalInfo);
  if (trace.empty()) {
    trace = GetStackTraceAfterSignalLibunwind(signalInfo);
  }
  if (trace.empty()) {
    trace = GetStackTraceAfterSignalUnwind(signalInfo);
  }
  return trace;
}

std::string AndroidStackTraceProvider::GetStackTraceAfterSignalCorkscrew(const Signal& signalInfo) const {
#if defined(USE_CORKSCREW)
  // libcorkscrew.so works for Android 4.0 and up but not 5.0 and higher
  // Extracted from: https://github.com/xroche/coffeecatch
  void* const libcorkscrew = dlopen("libcorkscrew.so", RTLD_LAZY | RTLD_LOCAL);
  if (!libcorkscrew) {
    return "";
  }
  system::ScopeExit closeLib([libcorkscrew] { dlclose(libcorkscrew); });

  static const int kNumberOfStackTraceEntries = 32;
  BacktraceFrame frames[kNumberOfStackTraceEntries];
  BacktraceSymbol symbols[kNumberOfStackTraceEntries];
  std::memset(frames, 0, sizeof(frames));
  std::memset(symbols, 0, sizeof(symbols));

  UnwindBacktraceSignalArch unwind_backtrace_signal_arch =
      (UnwindBacktraceSignalArch)dlsym(libcorkscrew, "unwind_backtrace_signal_arch");
  AcquireMyMapInfoList acquire_my_map_info_list = (AcquireMyMapInfoList)dlsym(libcorkscrew, "acquire_my_map_info_list");
  ReleaseMyMapInfoList release_my_map_info_list = (ReleaseMyMapInfoList)dlsym(libcorkscrew, "release_my_map_info_list");
  GetBacktraceSymbols get_backtrace_symbols = (GetBacktraceSymbols)dlsym(libcorkscrew, "get_backtrace_symbols");
  FreeBacktraceSymbols free_backtrace_symbols = (FreeBacktraceSymbols)dlsym(libcorkscrew, "free_backtrace_symbols");

  if (unwind_backtrace_signal_arch == nullptr || acquire_my_map_info_list == nullptr ||
      release_my_map_info_list == nullptr || get_backtrace_symbols == nullptr || free_backtrace_symbols == nullptr) {
    return "";
  }

  map_info_t* const info = acquire_my_map_info_list();
  system::ScopeExit releaseMapInfo([release_my_map_info_list, info] { release_my_map_info_list(info); });

  const ssize_t numFrames =
      unwind_backtrace_signal_arch(signalInfo.info, signalInfo.context, info, frames, 0, kNumberOfStackTraceEntries);
  if (numFrames <= 0) {
    return "";
  }

  get_backtrace_symbols(frames, numFrames, symbols);
  system::ScopeExit releasSymbols(
      [free_backtrace_symbols, &symbols, numFrames] { free_backtrace_symbols(symbols, numFrames); });

  std::ostringstream stream;

  for (ssize_t idx = 0; idx < numFrames; ++idx) {
    stream << "  #" << std::setw(2) << idx << ": " << std::hex << symbols[idx].relative_symbol_addr << "  "
           << (symbols[idx].demangled_name != nullptr ? symbols[idx].demangled_name : symbols[idx].symbol_name)
           << std::endl;
  }

  return stream.str();
#else
  return "";
#endif
}

std::string AndroidStackTraceProvider::GetStackTraceAfterSignalLibunwind(const Signal& signalInfo) const {
#if defined(USE_LIBUNWIND)
  // Keeping this for now: Does result in a crash when we invoke 'backtrace'
  void* libunwind = dlopen("libunwind.so", RTLD_LAZY | RTLD_LOCAL);
  if (!libunwind) {
    return "";
  }
  system::ScopeExit closeLibunwind([libunwind] { dlclose(libunwind); });

  // find 'backtrace' function:
  BacktraceFunction backtrace = (BacktraceFunction)dlsym(libunwind, "unw_backtrace");
  if (!backtrace) {
    return "";
  }
  static const int kNumberOfStackTraceEntries = 32;
  void* frames[kNumberOfStackTraceEntries];

  int numFrames = backtrace(frames, kNumberOfStackTraceEntries);
  if (numFrames < 0) {
    return "";
  }
  std::ostringstream stream;

  for (int idx = 0; idx < numFrames; ++idx) {
    const void* addr = frames[idx];
    const char* symbol = "";

    Dl_info info;
    if (dladdr(addr, &info) && info.dli_sname) {
      symbol = info.dli_sname;
    }

    stream << "  #" << std::setw(2) << idx << ": " << addr << "  ";
    DemangleFunction(symbol, &stream);
  }

  return stream.str();
#else
  return "";
#endif
}

std::string AndroidStackTraceProvider::GetStackTraceAfterSignalUnwind(const Signal& signalInfo) const {
#if defined(USE_UNWIND)
  static const size_t kNumberOfStackTraceEntries = 32;
  void* frames[kNumberOfStackTraceEntries];
  std::ostringstream stream;

  size_t numFrames = CaptureUnwindBacktrace(frames, kNumberOfStackTraceEntries);

  for (size_t idx = 0; idx < numFrames; ++idx) {
    const void* addr = frames[idx];
    const char* symbol = "";

    Dl_info info;
    if (dladdr(addr, &info) && info.dli_sname) {
      symbol = info.dli_sname;
    }

    stream << "  #" << std::setw(2) << idx << ": " << addr << "  ";
    DemangleFunction(symbol, &stream);
  }

  return stream.str();
#else
  return "";
#endif
}

_Unwind_Reason_Code AndroidStackTraceProvider::UnwindCallback(struct _Unwind_Context* context, void* arg) {
  BacktraceState* state = static_cast<BacktraceState*>(arg);
  uintptr_t pc = _Unwind_GetIP(context);
  if (pc) {
    if (state->current == state->end) {
      return _URC_END_OF_STACK;
    } else {
      *state->current++ = reinterpret_cast<void*>(pc);
    }
  }
  return _URC_NO_REASON;
}

size_t AndroidStackTraceProvider::CaptureUnwindBacktrace(void** buffer, size_t max) const {
  BacktraceState state = {buffer, buffer + max};
  _Unwind_Backtrace(UnwindCallback, &state);

  return state.current - buffer;
}

void AndroidStackTraceProvider::DemangleFunction(
    const char* functionNameIn, std::ostringstream* stackTraceStream) const {
  char *beginName = 0, *beginOffset = 0, *endOffset = 0;

  // Since we are writing to the input function name we have to make
  // a local copy:
  const size_t functionNameInSize = std::strlen(functionNameIn) + 1;
  char* functionName = reinterpret_cast<char*>(malloc(functionNameInSize));
  std::strncpy(functionName, functionNameIn, functionNameInSize - 1);
  system::ScopeExit cleanupInputNameCopy([&functionName]() { free(functionName); });

  // allocate string which will be filled with the demangled function name
  size_t functionNameSize = 256;
  char* demangledFunctionName = reinterpret_cast<char*>(malloc(functionNameSize));
  system::ScopeExit cleanupDemangledCopy([&demangledFunctionName]() { free(demangledFunctionName); });

  // find parentheses and +address offset surrounding the mangled name:
  // ./module(function+0x15c) [0x8048a6d]
  for (char* functionNamePointer = functionName; *functionNamePointer; ++functionNamePointer) {
    if (*functionNamePointer == '(') {
      beginName = functionNamePointer;
    } else if (*functionNamePointer == '+') {
      beginOffset = functionNamePointer;
    } else if (*functionNamePointer == ')' && beginOffset) {
      endOffset = functionNamePointer;
      break;
    }
  }

  const char* probablyMangledFunctionName = nullptr;

  if (beginName && beginOffset && endOffset && beginName < beginOffset) {
    *beginName++ = '\0';
    *beginOffset++ = '\0';
    *endOffset = '\0';
    probablyMangledFunctionName = beginName;
    // mangled name is now in [beginName, beginOffset) and caller
    // offset in [beginOffset, endOffset).
  } else {
    probablyMangledFunctionName = functionNameIn;
  }

  int status;
  char* demangledName =
      abi::__cxa_demangle(probablyMangledFunctionName, demangledFunctionName, &functionNameSize, &status);
  if (status == 0) {
    demangledFunctionName = demangledName;  // use possibly realloc()-ed string
    *stackTraceStream << functionName << " : " << demangledFunctionName << "+" << beginOffset << std::endl;
  } else {
    // demangling failed. Output function name as a C function with
    // no arguments.
    *stackTraceStream << functionName << " : " << probablyMangledFunctionName << "()+" << beginOffset << std::endl;
  }
}

}  // namespace exceptions

