
#include "Exceptions/Posix/PosixExceptionPrinter.h"

#include <sstream>

#include <boost/type_index.hpp>


namespace exceptions {

PosixExceptionPrinter::PosixExceptionPrinter() {}

PosixExceptionPrinter::~PosixExceptionPrinter() {}

std::string PosixExceptionPrinter::GetExceptionAsString(const std::exception& exceptionRecord) {
  std::ostringstream stream;

  stream << boost::typeindex::type_id_runtime(exceptionRecord).pretty_name() << " : ";

  try {
    stream << exceptionRecord.what();
  } catch (...) {
    stream << "Failed to get exception description";
  }

  return stream.str();
}

std::string PosixExceptionPrinter::GetSignalAsString(const char* signalName) {
  std::stringstream stream;
  stream << "Signal [" << signalName << "]";

  return stream.str();
}

std::string PosixExceptionPrinter::GetSignalAsString(
    const char* signalName, int signalNumber, siginfo_t* info, void* sigcontext) {
  std::stringstream stream;

  stream << "Signal [" << signalName << "] with signal number [" << signalNumber;

  if (signalNumber != SIGUSR1) {
    stream << "] and siginfo [" << GetSiginfoAsString(info) << "]";
  }

  stream << "]";

  return stream.str();
}

std::string PosixExceptionPrinter::GetSiginfoAsString(siginfo_t* info) {
  std::stringstream stream;
  stream << strsignal(info->si_signo);
  stream << " (";
  switch (info->si_signo) {
    case SIGILL: {
      stream << GetSigillCodeAsString(info);
      stream << " [0x" << std::hex << info->si_addr << "]";
      break;
    }
    case SIGFPE: {
      stream << GetSigfpeCodeAsString(info);
      stream << " [0x" << std::hex << info->si_addr << "]";
      break;
    }
    case SIGSEGV: {
      stream << GetSigsegvCodeAsString(info);
      stream << " [0x" << std::hex << info->si_addr << "]";
      break;
    }
    case SIGBUS: {
      stream << GetSigbusCodeAsString(info);
      stream << " [0x" << std::hex << info->si_addr << "]";
      break;
    }
    case SIGTRAP: {
      stream << GetSigtrapCodeAsString(info);
      break;
    }
    case SIGCHLD: {
      stream << GetSigchldCodeAsString(info);
      stream << " [child process=" << info->si_pid << ", status=" << info->si_status << ", user id=" << info->si_uid
             << "]";
      break;
    }

#ifdef SIGPOLL
    case SIGPOLL: {
      stream << GetSigpollCodeAsString(info);
      stream << " [band=" << info->si_band << "]";
      break;
    }
#endif
  }

  stream << ")";
  return stream.str();
}

std::string PosixExceptionPrinter::GetSigillCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case ILL_ILLOPC:
      return "illegal opcode";
    case ILL_ILLOPN:
      return "illegal operand";
    case ILL_ILLADR:
      return "illegal addressing mode";
    case ILL_ILLTRP:
      return "illegal trap";
    case ILL_PRVOPC:
      return "illegal privileged opcode";
    case ILL_PRVREG:
      return "illegal privileged register";
    case ILL_COPROC:
      return "coprocessor error";
    case ILL_BADSTK:
      return "internal stack error";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigfpeCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case FPE_INTDIV:
      return "integer divide by zero";
    case FPE_INTOVF:
      return "integer overflow";
    case FPE_FLTDIV:
      return "floating-point divide by zero";
    case FPE_FLTOVF:
      return "floating-point overflow";
    case FPE_FLTUND:
      return "floating-point underflow";
    case FPE_FLTRES:
      return "floating-point inexact result";
    case FPE_FLTINV:
      return "invalid floating-point operation";
    case FPE_FLTSUB:
      return "subscript out of range";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigsegvCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case SEGV_MAPERR:
      return "address not mapped to object";
    case SEGV_ACCERR:
      return "invalid permissions for mapped object";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigbusCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case BUS_ADRALN:
      return "invalid address alignment";
    case BUS_ADRERR:
      return "nonexistent physical address";
    case BUS_OBJERR:
      return "object-specific hardware error";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigtrapCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case TRAP_BRKPT:
      return "process breakpoint";
    case TRAP_TRACE:
      return "process trace trap";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigchldCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case CLD_EXITED:
      return "child has exited";
    case CLD_KILLED:
      return "child has terminated abnormally and did not create a core file";
    case CLD_DUMPED:
      return "child has terminated abnormally and created a core file";
    case CLD_TRAPPED:
      return "traced child has trapped";
    case CLD_STOPPED:
      return "child has stopped";
    case CLD_CONTINUED:
      return "stopped child has continued";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetSigpollCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case POLL_IN:
      return "data input available";
    case POLL_OUT:
      return "output buffers available";
    case POLL_MSG:
      return "input message available";
    case POLL_ERR:
      return "I/O error";
    case POLL_PRI:
      return "high priority input available";
    case POLL_HUP:
      return "device disconnected";
  }

  return GetAnyCodeAsString(info);
}

std::string PosixExceptionPrinter::GetAnyCodeAsString(siginfo_t* info) {
  switch (info->si_code) {
    case SI_USER:
      return "signal sent by kill()";
    case SI_QUEUE:
      return "signal sent by sigqueue()";
    case SI_TIMER:
      return "signal generated by expiration of a timer set by timer_settime";
    case SI_ASYNCIO:
      return "signal generated by completion of an asynchronous I/O request";
    case SI_MESGQ:
      return "signal generated by arrival of a message on an empty message queue";
#ifdef SI_TKILL
    case SI_TKILL:
      return "signal sent by tkill()";
#endif
#ifdef SI_ASYNCNL
    case SI_ASYNCNL:
      return "signal generated by the completion of an asynchronous name lookup request";
#endif
#ifdef SI_SIGIO
    case SI_SIGIO:
      return "signal generated by the completion of an I/O request";
#endif
#ifdef SI_KERNEL
    case SI_KERNEL:
      return "signal sent by the kernel";
#endif
  }

  std::stringstream stream;
  stream << "unknown code info [" << info->si_code << "]";
  return stream.str();
}

}  // namespace exceptions

