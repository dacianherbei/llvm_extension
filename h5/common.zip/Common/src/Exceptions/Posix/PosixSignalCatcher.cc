
#include "Exceptions/Posix/PosixSignalCatcher.h"

#include <signal.h>
#include <stdio.h>
#include <cstring>

#include <boost/lexical_cast.hpp>

#include "System/Assert.h"
#include "System/DebugAssert.h"
#include "Threading/Thread.h"


namespace exceptions {

const std::shared_ptr<PosixSignalCatcher> PosixSignalCatcher::instance_(new PosixSignalCatcher());

std::shared_ptr<PosixSignalCatcher> PosixSignalCatcher::GetInstance() { return instance_; }

void PosixSignalCatcher::Initialize(
    const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
    const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
    const std::shared_ptr<logging::Logger>& logger) {
  safeStartStop_.StartIfStopped([this, &stackTraceProvider, &exceptionPrinter, &logger]() {
    stackTraceProvider_ = stackTraceProvider;
    exceptionPrinter_ = std::dynamic_pointer_cast<PosixExceptionPrinter>(exceptionPrinter);
    _ASSERT(exceptionPrinter_, "Did not provide a valid stack trace provider of type PosixExceptionPrinter");

    logger_ = logger;
    signalCalled_ = false;
    functionToBeCalledAfterSignalIsHandled_ = nullptr;

    SetProcessSignalHandlers();
  });
}

void PosixSignalCatcher::Destroy() {
  safeStartStop_.StopIfStarted([this]() {
    struct sigaction sa;
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGILL, &sa, nullptr);
    sigaction(SIGFPE, &sa, nullptr);
    sigaction(SIGTERM, &sa, nullptr);
    sigaction(SIGINT, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGUSR1, &sa, nullptr);

    functionToBeCalledAfterSignalIsHandled_ = nullptr;
  });
}

PosixSignalCatcher::PosixSignalCatcher()
    : stackTraceProvider_(),
      exceptionPrinter_(),
      logger_(),
      functionToBeCalledAfterSignalIsHandled_(),
      signalCalled_(false),
      signalCode_(0),
      safeStartStop_() {}

void PosixSignalCatcher::SetFunctionToBeCalledAfterSignalIsHandled(const AfterSignalHandler& function) {
  functionToBeCalledAfterSignalIsHandled_ = function;
}

void PosixSignalCatcher::TriggerStackDumpOnThread(const threading::Thread& thread) const {
  const int killResult = ::pthread_kill(thread.GetThreadNativeHandle().get(), SIGUSR1);
  _DEBUG_ASSERT(
      killResult == 0,
      "Unable to send signal [" << SIGUSR1 << "] to thread [" << thread << "]. Result [" << killResult << "]");
}

void PosixSignalCatcher::SetProcessSignalHandlers() {
  // Catch an abnormal program termination
  AttachSignal(SIGABRT, SigabrtHandler);

  // Catch illegal instruction handler
  AttachSignal(SIGINT, SigintHandler);

  // Catch a termination request
  AttachSignal(SIGTERM, SigtermHandler);

  // Catch a floating point error
  AttachSignal(SIGFPE, SigfpeHandler);

  // Catch an illegal instruction
  AttachSignal(SIGILL, SigillHandler);

  // Catch illegal storage access errors
  AttachSignal(SIGSEGV, SigsegvHandler);

  // Dump stack trace on user signal
  AttachSignal(SIGUSR1, Sigusr1Handler);
}

bool PosixSignalCatcher::TestSignalCalledFlag(int64_t* signalCode) const {
  *signalCode = signalCode_;
  return signalCalled_;
}

void PosixSignalCatcher::RunAndEnableThreadSpecificSignals(const Main& function) {
  sigset_t signalsToUnblockOnThisThread;

  sigemptyset(&signalsToUnblockOnThisThread);
  sigaddset(&signalsToUnblockOnThisThread, SIGUSR1);

  const int sigmaskResult = ::pthread_sigmask(SIG_UNBLOCK, &signalsToUnblockOnThisThread, nullptr);
  _ASSERT(
      sigmaskResult == 0,
      "Unable to update signal mask on thread [" << threading::Thread::GetCurrentThreadId()
                                                 << "]. Failed with error code [" << sigmaskResult << "]");

  function();
}

void PosixSignalCatcher::AttachSignal(int signalNumber, void (*signalHandler)(int, siginfo_t*, void*)) {
  struct sigaction action;

  memset(&action, '\0', sizeof(action));

  /* Use the sa_sigaction field because the handles has two additional parameters */
  action.sa_sigaction = signalHandler;
  sigemptyset(&action.sa_mask);
  action.sa_flags = SA_RESTART | SA_SIGINFO;

  if (sigaction(signalNumber, &action, nullptr) < 0) {
    perror("sigaction");
  }
}

void PosixSignalCatcher::SigabrtHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigabrtHandler", signalNumber, info, sigcontext, SignalType::kAbortProgram);
}

void PosixSignalCatcher::SigintHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigintHandler", signalNumber, info, sigcontext, SignalType::kExitProgram);
}

void PosixSignalCatcher::SigtermHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigtermHandler", signalNumber, info, sigcontext, SignalType::kExitProgram);
}

void PosixSignalCatcher::SigfpeHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigfpeHandler", signalNumber, info, sigcontext, SignalType::kAbortProgram);
}

void PosixSignalCatcher::SigillHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigillHandler", signalNumber, info, sigcontext, SignalType::kAbortProgram);
}

void PosixSignalCatcher::SigsegvHandler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("SigsegvHandler", signalNumber, info, sigcontext, SignalType::kAbortProgram);
}

void PosixSignalCatcher::Sigusr1Handler(int signalNumber, siginfo_t* info, void* sigcontext) {
  GetInstance()->HandleSignal("Sigusr1Handler", signalNumber, info, sigcontext, SignalType::kDumpStackTrace);
}

void PosixSignalCatcher::HandleSignal(
    const char* signalName, int signalNumber, siginfo_t* info, void* sigcontext, const SignalType& signalType) {
  signalCode_ = signalNumber;
  HandleSignal(
      exceptionPrinter_->GetSignalAsString(signalName, signalNumber, info, sigcontext).c_str(),
      signalType,
      info,
      sigcontext);
}

void PosixSignalCatcher::HandleSignal(
    const char* errorToPrint, const SignalType& signalType, siginfo_t* info, void* sigcontext) {
  signalCalled_ = true;
  Signal signalInfo{info, sigcontext};
  _LOG(
      logger_,
      logging::LogLevel::kError,
      "[" << errorToPrint << "] occurred with the following callstack:" << std::endl
          << stackTraceProvider_->GetStackTraceAfterSignal(signalInfo));

  if (functionToBeCalledAfterSignalIsHandled_) {
    functionToBeCalledAfterSignalIsHandled_(signalType, errorToPrint);
  }
}

}  // namespace exceptions

