
#include "Exceptions/Posix/PosixExceptionCatcher.h"

#include <stdio.h>
#include <cstring>

#include "System/Assert.h"
#include "System/Exception.h"


namespace exceptions {

const std::shared_ptr<PosixExceptionCatcher> PosixExceptionCatcher::instance_(new PosixExceptionCatcher());

std::shared_ptr<PosixExceptionCatcher> PosixExceptionCatcher::GetInstance() { return instance_; }

void PosixExceptionCatcher::Initialize(
    const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
    const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
    const std::shared_ptr<logging::Logger>& logger) {
  safeStartStop_.StartIfStopped([this, &stackTraceProvider, &exceptionPrinter, &logger]() {
    stackTraceProvider_ = stackTraceProvider;
    exceptionPrinter_ = std::dynamic_pointer_cast<PosixExceptionPrinter>(exceptionPrinter);
    _ASSERT(exceptionPrinter_, "Did not provide a valid stack trace provider of type PosixExceptionPrinter");

    logger_ = logger;
    functionToBeCalledAfterExceptionIsHandled_ = nullptr;
    originalTerminateHandler_ = std::set_terminate(TerminateHandler);
  });
}

void PosixExceptionCatcher::Destroy() {
  safeStartStop_.StopIfStarted([this]() {
    std::set_terminate(originalTerminateHandler_);
    functionToBeCalledAfterExceptionIsHandled_ = nullptr;
  });
}

void PosixExceptionCatcher::RunAndLogExceptionAndStackTraceOnException(Main&& function) { function(); }

void PosixExceptionCatcher::SetFunctionToBeCalledAfterExceptionIsHandled(const AfterExceptionHandler& function) {
  functionToBeCalledAfterExceptionIsHandled_ = function;
}

void PosixExceptionCatcher::TerminateHandler() { GetInstance()->HandleTerminate(); }

PosixExceptionCatcher::PosixExceptionCatcher()
    : stackTraceProvider_(),
      exceptionPrinter_(),
      logger_(),
      functionToBeCalledAfterExceptionIsHandled_(),
      originalTerminateHandler_(),
      safeStartStop_() {}

void PosixExceptionCatcher::HandleException(const std::string& exceptionName) {
  _LOG(
      logger_,
      logging::LogLevel::kError,
      "Exception [" << exceptionName << "] occurred with the following callstack:" << std::endl
                    << stackTraceProvider_->GetStackTrace());

  if (functionToBeCalledAfterExceptionIsHandled_) {
    functionToBeCalledAfterExceptionIsHandled_(exceptionName);
  }
  // Terminate handlers should never return:
  std::exit(-1);
}

void PosixExceptionCatcher::HandleNestedException(const std::exception& exception) {
  _LOG(
      logger_,
      logging::LogLevel::kError,
      "Nested exception [" << exceptionPrinter_->GetExceptionAsString(exception) << "]");

  try {
    std::rethrow_if_nested(exception);
  } catch (const std::exception& e) {
    HandleNestedException(e);
  } catch (...) {
  }
}

void PosixExceptionCatcher::HandleTerminate() {
  // http://stackoverflow.com/questions/3774316/c-unhandled-exceptions
  // http://www.tiwoc.de/blog/2013/12/globally-handling-uncaught-exceptions-and-signals-in-c/
  std::exception_ptr exptr = std::current_exception();
  if (exptr) {
    try {
      std::rethrow_exception(exptr);
    } catch (const std::exception& exception) {
      try {
        std::rethrow_if_nested(exception);
      } catch (const std::exception& e) {
        HandleNestedException(e);
      } catch (...) {
      }

      HandleException(exceptionPrinter_->GetExceptionAsString(exception));
      return;
    } catch (...) {
    }
    HandleException("Unknown C++ Exception");
  } else {
    HandleException("Terminate called without exception");
  }
}

}  // namespace exceptions

