
#include "Exceptions/MSVC/VisualStudioExceptionCatcher.h"

#include <signal.h>

#include <exception>

#include <new.h>
#include <windows.h>

#include "Exceptions/MSVC/VisualStudioExceptionTypes.h"
#include "System/Assert.h"
#include "System/DebugAssert.h"


namespace exceptions {

std::shared_ptr<VisualStudioExceptionCatcher> VisualStudioExceptionCatcher::GetInstance() {
  static std::shared_ptr<VisualStudioExceptionCatcher> instance(new VisualStudioExceptionCatcher());
  return instance;
}

VisualStudioExceptionCatcher::VisualStudioExceptionCatcher()
    : stackTraceProvider_(),
      exceptionPrinter_(),
      logger_(),
      functionToBeCalledAfterExceptionIsHandled_(),
      safeStartStop_() {}

void VisualStudioExceptionCatcher::Initialize(
    const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
    const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
    const std::shared_ptr<logging::Logger>& logger) {
  safeStartStop_.StartIfStopped([this, &stackTraceProvider, &exceptionPrinter, &logger]() {
    stackTraceProvider_ = std::dynamic_pointer_cast<VisualStudioStackTraceProvider>(stackTraceProvider);
    exceptionPrinter_ = std::dynamic_pointer_cast<VisualStudioExceptionPrinter>(exceptionPrinter);
    _ASSERT(
        stackTraceProvider_, "Did not provide a valid stack trace provider of type VisualStudioStackTraceProvider");
    _ASSERT(exceptionPrinter_, "Did not provide a valid exception printer of type VisualStudioExceptionPrinter");

    logger_ = logger;
  });
}

void VisualStudioExceptionCatcher::Destroy() {
  safeStartStop_.StopIfStarted([this] { functionToBeCalledAfterExceptionIsHandled_ = nullptr; });
}

void VisualStudioExceptionCatcher::RunAndLogExceptionAndStackTraceOnException(Main&& function) {
  __try {
    function();
  } __except (ExceptionFilter(GetExceptionInformation(), GetExceptionCode())) {  // NOLINT(whitespace/parens)
  }
}

DWORD VisualStudioExceptionCatcher::ExceptionFilter(EXCEPTION_POINTERS* exceptionPointers, DWORD exceptionCode) {
  HandleException(exceptionPointers);
  return EXCEPTION_EXECUTE_HANDLER;
}

void VisualStudioExceptionCatcher::SetFunctionToBeCalledAfterExceptionIsHandled(const AfterExceptionHandler& function) {
  functionToBeCalledAfterExceptionIsHandled_ = function;
}

void VisualStudioExceptionCatcher::HandleException(EXCEPTION_POINTERS* exceptionPointers) {
  std::string exception = exceptionPrinter_->GetExceptionAsString(*exceptionPointers->ExceptionRecord);

  _LOG(
      logger_,
      logging::LogLevel::kError,
      "Exception [" << exception << "] occurred with the following callstack:" << std::endl
                    << stackTraceProvider_->GetStackTrace(exceptionPointers->ContextRecord));

  if (functionToBeCalledAfterExceptionIsHandled_) {
    functionToBeCalledAfterExceptionIsHandled_(exception);
  }
}

}  // namespace exceptions

