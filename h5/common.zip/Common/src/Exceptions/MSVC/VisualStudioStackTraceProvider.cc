
#include "Exceptions/MSVC/VisualStudioStackTraceProvider.h"


namespace exceptions {

threading::RecursiveMutex VisualStudioStackTraceProvider::mutex_;

container::ThreadsafeLookupTable<
    threading::ThreadType::ThreadIdType,
    std::shared_ptr<VisualStudioStackTraceProvider::StackTraceCollector>>
    VisualStudioStackTraceProvider::stackTraceCollectors_;

VisualStudioStackTraceProvider::VisualStudioStackTraceProvider() {}
VisualStudioStackTraceProvider::~VisualStudioStackTraceProvider() {}

std::string VisualStudioStackTraceProvider::GetStackTrace() const {
  std::lock_guard<threading::RecursiveMutex> lock(mutex_);
  auto collector = GetStackTraceCollector();
  collector->ShowCallstack();
  return collector->GetStackTrace();
}

std::string VisualStudioStackTraceProvider::GetStackTrace(PCONTEXT pExp) const {
  std::lock_guard<threading::RecursiveMutex> lock(mutex_);
  auto collector = GetStackTraceCollector();
  collector->ShowCallstack(GetCurrentThread(), pExp);
  return collector->GetStackTrace();
}

std::string VisualStudioStackTraceProvider::GetStackTraceAfterSignal(const Signal& signalInfo) const {
  return GetStackTrace();
}

std::shared_ptr<VisualStudioStackTraceProvider::StackTraceCollector>
VisualStudioStackTraceProvider::GetStackTraceCollector() const {
  auto returnPair = stackTraceCollectors_.Insert(
      threading::ThreadType::GetCurrentThreadId(), [this]() { return std::make_shared<StackTraceCollector>(); });

  return returnPair.first;
}

VisualStudioStackTraceProvider::StackTraceCollector::StackTraceCollector() {}
VisualStudioStackTraceProvider::StackTraceCollector::~StackTraceCollector() {}

std::string VisualStudioStackTraceProvider::StackTraceCollector::GetStackTrace() const {
  return stackTraceStream_.str();
}

void VisualStudioStackTraceProvider::StackTraceCollector::OnOutput(LPCSTR szText) { stackTraceStream_ << szText; }

}  // namespace exceptions

