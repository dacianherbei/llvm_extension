
#include "Exceptions/MSVC/VisualStudioSignalCatcher.h"

#include <signal.h>

#include <exception>

#include <new.h>
#include <windows.h>

#include "Exceptions/MSVC/VisualStudioExceptionTypes.h"
#include "System/Assert.h"


namespace exceptions {

std::shared_ptr<VisualStudioSignalCatcher> VisualStudioSignalCatcher::GetInstance() {
  static std::shared_ptr<VisualStudioSignalCatcher> instance(new VisualStudioSignalCatcher());
  return instance;
}

void VisualStudioSignalCatcher::Initialize(
    const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
    const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
    const std::shared_ptr<logging::Logger>& logger) {
  safeStartStop_.StartIfStopped([this, &stackTraceProvider, &exceptionPrinter, &logger]() {
    stackTraceProvider_ = std::dynamic_pointer_cast<VisualStudioStackTraceProvider>(stackTraceProvider);
    exceptionPrinter_ = std::dynamic_pointer_cast<VisualStudioExceptionPrinter>(exceptionPrinter);
    _ASSERT(
        stackTraceProvider_, "Did not provide a valid stack trace provider of type VisualStudioStackTraceProvider");
    _ASSERT(exceptionPrinter_, "Did not provide a valid exception printer of type VisualStudioExceptionPrinter");

    logger_ = logger;
    signalCalled_ = false;
    functionToBeCalledAfterSignalIsHandled_ = nullptr;

    SetProcessSignalHandlers();
    SetThreadSignalHandlers();
  });
}

void VisualStudioSignalCatcher::Destroy() {
  safeStartStop_.StopIfStarted([this]() {
    _set_purecall_handler(0);
    _set_new_handler(0);
    _set_invalid_parameter_handler(0);

    signal(SIGABRT, SIG_DFL);
    signal(SIGINT, SIG_DFL);
    signal(SIGTERM, SIG_DFL);

    set_terminate(0);
    set_unexpected(0);

    signal(SIGFPE, SIG_DFL);
    signal(SIGILL, SIG_DFL);
    signal(SIGSEGV, SIG_DFL);

    functionToBeCalledAfterSignalIsHandled_ = nullptr;
  });
}

VisualStudioSignalCatcher::VisualStudioSignalCatcher() : signalCalled_(false) {}

void VisualStudioSignalCatcher::SetFunctionToBeCalledAfterSignalIsHandled(const AfterSignalHandler& function) {
  functionToBeCalledAfterSignalIsHandled_ = function;
}

void VisualStudioSignalCatcher::RunAndEnableThreadSpecificSignals(const Main& function) {
  SetThreadSignalHandlers();
  function();
}

void VisualStudioSignalCatcher::TriggerStackDumpOnThread(const threading::Thread& thread) const {
  // TODO(AS): Need to implement this functionality
}

void VisualStudioSignalCatcher::SetProcessSignalHandlers() {
  // Catch pure virtual function calls.
  // Because there is one _purecall_handler for the whole process,
  // calling this function immediately impacts all threads. The last
  // caller on any thread sets the handler.
  // http://msdn.microsoft.com/en-us/library/t296ys27.aspx
  _set_purecall_handler(PureCallHandler);

  // Catch new operator memory allocation exceptions
  _set_new_handler(NewHandler);

  // Catch invalid parameter exceptions.
  _set_invalid_parameter_handler(InvalidParameterHandler);

  // Catch an abnormal program termination
  signal(SIGABRT, SigabrtHandler);

  // Catch illegal instruction handler
  signal(SIGINT, SigintHandler);

  // Catch a termination request
  signal(SIGTERM, SigtermHandler);
}

void VisualStudioSignalCatcher::SetThreadSignalHandlers() {
  // Catch terminate() calls.
  // In a multithreaded environment, terminate functions are maintained
  // separately for each thread. Each new thread needs to install its own
  // terminate function. Thus, each thread is in charge of its own termination handling.
  // http://msdn.microsoft.com/en-us/library/t6fk7h29.aspx
  set_terminate(TerminateHandler);

  // Catch unexpected() calls.
  // In a multithreaded environment, unexpected functions are maintained
  // separately for each thread. Each new thread needs to install its own
  // unexpected function. Thus, each thread is in charge of its own unexpected handling.
  // http://msdn.microsoft.com/en-us/library/h46t5b69.aspx
  set_unexpected(UnexpectedHandler);

  // Catch a floating point error
  typedef void (*sigh)(int);
  signal(SIGFPE, (sigh)SigfpeHandler);

  // Catch an illegal instruction
  signal(SIGILL, SigillHandler);

  // Catch illegal storage access errors
  signal(SIGSEGV, SigsegvHandler);
}

bool VisualStudioSignalCatcher::TestSignalCalledFlag(int64_t* signalCode) const {
  *signalCode = signalCode_;
  return signalCalled_;
}

void VisualStudioSignalCatcher::SigabrtHandler(int errorCode) {
  GetInstance()->HandleSignal("SigabrtHandler", errorCode, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::SigintHandler(int errorCode) {
  GetInstance()->HandleSignal("SigintHandler", errorCode, SignalType::kExitProgram);
}

void VisualStudioSignalCatcher::SigtermHandler(int errorCode) {
  GetInstance()->HandleSignal("SigtermHandler", errorCode, SignalType::kExitProgram);
}

void VisualStudioSignalCatcher::SigfpeHandler(int errorCode, int subcode) {
  GetInstance()->HandleSignal("SigfpeHandler", errorCode, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::SigillHandler(int errorCode) {
  GetInstance()->HandleSignal("SigillHandler", errorCode, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::SigsegvHandler(int errorCode) {
  GetInstance()->HandleSignal("SigsegvHandler", errorCode, SignalType::kAbortProgram);
}

int VisualStudioSignalCatcher::NewHandler(size_t errorCode) {
  GetInstance()->HandleSignal("NewHandler", errorCode, SignalType::kAbortProgram);

  return 0;
}

void VisualStudioSignalCatcher::TerminateHandler() {
  GetInstance()->HandleSignal("TerminateHandler", -1, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::UnexpectedHandler() {
  GetInstance()->HandleSignal("UnexpectedHandler", -1, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::PureCallHandler() {
  GetInstance()->HandleSignal("PureCallHandler", -1, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::InvalidParameterHandler(
    const wchar_t* expression, const wchar_t* function, const wchar_t* file, unsigned int line, uintptr_t pReserved) {
  pReserved;

  GetInstance()->HandleSignal("InvalidParameterHandler", -1, SignalType::kAbortProgram);
}

void VisualStudioSignalCatcher::HandleSignal(
    const std::string& exceptionName, int errorCode, const SignalType& signalType) {
  signalCalled_ = true;
  signalCode_ = errorCode;
  EXCEPTION_POINTERS* exceptionPointers = NULL;
  GetExceptionPointers(errorCode, &exceptionPointers);

  HandleException(exceptionPointers, signalType);
}

void VisualStudioSignalCatcher::HandleException(EXCEPTION_POINTERS* exceptionPointers, const SignalType& signalType) {
  std::string exception = exceptionPrinter_->GetExceptionAsString(*exceptionPointers->ExceptionRecord);

  _LOG(
      logger_,
      logging::LogLevel::kError,
      "Signal [" << exception << "] occurred with the following callstack:" << std::endl
                 << stackTraceProvider_->GetStackTrace(exceptionPointers->ContextRecord));

  if (functionToBeCalledAfterSignalIsHandled_) {
    functionToBeCalledAfterSignalIsHandled_(signalType, exception);
  }
}

// The following code gets exception pointers using a workaround found in CRT code.
void VisualStudioSignalCatcher::GetExceptionPointers(DWORD dwExceptionCode, EXCEPTION_POINTERS** ppExceptionPointers) {
  // The following code was taken from VC++ 8.0 CRT (invarg.c: line 104)

  EXCEPTION_RECORD ExceptionRecord;
  CONTEXT ContextRecord;
  memset(&ContextRecord, 0, sizeof(CONTEXT));

#ifdef _X86_

  __asm {
    mov dword ptr[ContextRecord.Eax], eax
      mov dword ptr[ContextRecord.Ecx], ecx
      mov dword ptr[ContextRecord.Edx], edx
      mov dword ptr[ContextRecord.Ebx], ebx
      mov dword ptr[ContextRecord.Esi], esi
      mov dword ptr[ContextRecord.Edi], edi
      mov word ptr[ContextRecord.SegSs], ss
      mov word ptr[ContextRecord.SegCs], cs
      mov word ptr[ContextRecord.SegDs], ds
      mov word ptr[ContextRecord.SegEs], es
      mov word ptr[ContextRecord.SegFs], fs
      mov word ptr[ContextRecord.SegGs], gs
      pushfd
      pop[ContextRecord.EFlags]
  }

  ContextRecord.ContextFlags = CONTEXT_CONTROL;
#pragma warning(push)
#pragma warning(disable : 4311)
  ContextRecord.Eip = (ULONG)_ReturnAddress();
  ContextRecord.Esp = (ULONG)_AddressOfReturnAddress();
#pragma warning(pop)
  ContextRecord.Ebp = *(reinterpret_cast<ULONG*>(_AddressOfReturnAddress()) - 1);

#elif defined(_IA64_) || defined(_AMD64_)

  /* Need to fill up the Context in IA64 and AMD64. */
  RtlCaptureContext(&ContextRecord);

#else /* defined(_IA64_) || defined(_AMD64_) */

  ZeroMemory(&ContextRecord, sizeof(ContextRecord));

#endif /* defined(_IA64_) || defined(_AMD64_) */

  ZeroMemory(&ExceptionRecord, sizeof(EXCEPTION_RECORD));

  ExceptionRecord.ExceptionCode = dwExceptionCode;
  ExceptionRecord.ExceptionAddress = _ReturnAddress();

  ///

  EXCEPTION_RECORD* pExceptionRecord = new EXCEPTION_RECORD;
  memcpy(pExceptionRecord, &ExceptionRecord, sizeof(EXCEPTION_RECORD));
  CONTEXT* pContextRecord = new CONTEXT;
  memcpy(pContextRecord, &ContextRecord, sizeof(CONTEXT));

  *ppExceptionPointers = new EXCEPTION_POINTERS;
  (*ppExceptionPointers)->ExceptionRecord = pExceptionRecord;
  (*ppExceptionPointers)->ContextRecord = pContextRecord;
}

}  // namespace exceptions

