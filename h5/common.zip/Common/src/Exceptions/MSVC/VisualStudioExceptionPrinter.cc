
#include "Exceptions/MSVC/VisualStudioExceptionPrinter.h"

#include <sstream>


namespace exceptions {

void* ExceptionCastWorker(const UntypedException& exception, const type_info& typeInfo) {
  if (!exception.type_array) {
    return nullptr;
  }

  for (int i = 0; i < exception.type_array->nCatchableTypes; ++i) {
    _CatchableType& typeI = *exception.type_array->arrayOfCatchableTypes[i];
    const std::type_info& typeInfoI = *reinterpret_cast<std::type_info*>(typeI.pType);
    if (typeInfoI == typeInfo) {
      char* baseAddress = reinterpret_cast<char*>(exception.exception_object);
      baseAddress += typeI.thisDisplacement.mdisp;
      return baseAddress;
    }
  }
  return nullptr;
}

template <typename T>
T* ExceptionCast(const UntypedException& exception) {
  const std::type_info& typeInfo = typeid(T);
  return reinterpret_cast<T*>(ExceptionCastWorker(exception, typeInfo));
}

VisualStudioExceptionPrinter::VisualStudioExceptionPrinter() {}

VisualStudioExceptionPrinter::~VisualStudioExceptionPrinter() {}

std::string VisualStudioExceptionPrinter::GetExceptionAsString(const EXCEPTION_RECORD& exceptionRecord) const {
  std::stringstream sstr;

  switch (exceptionRecord.ExceptionCode) {
    case 0xE06D7363: {  // C++ exception
      UntypedException untypedException(exceptionRecord);
      if (std::exception* exception = ExceptionCast<std::exception>(untypedException)) {
        const std::type_info& typeInfo = typeid(*exception);

        sstr << typeInfo.name() << " : ";

        try {
          sstr << exception->what();
        } catch (...) {
          sstr << "Failed to get exception description";
        }
      } else {
        sstr << "Unknown C++ exception thrown.";
      }
      break;
    }

    case EXCEPTION_ACCESS_VIOLATION: {
      sstr << "Access violation. Illegal " << (exceptionRecord.ExceptionInformation[0] ? "write" : "read") << " by "
           << exceptionRecord.ExceptionAddress << " at "
           << reinterpret_cast<void*>(exceptionRecord.ExceptionInformation[1]);
      break;
    }

    default: {
      sstr << "SEH exception thrown. Exception code: 0x" << std::hex << std::uppercase << exceptionRecord.ExceptionCode
           << " at " << exceptionRecord.ExceptionAddress;
    }
  }

  return sstr.str();
}

}  // namespace exceptions

