
#include "Exceptions/ExceptionCatcherFactory.h"

#if defined(__APPLE__)
#include "Exceptions/Apple/AppleStackTraceProvider.h"
#include "Exceptions/Posix/PosixExceptionCatcher.h"
#include "Exceptions/Posix/PosixExceptionPrinter.h"
#elif defined(_MSC_VER)
#include "Exceptions/MSVC/VisualStudioExceptionCatcher.h"
#include "Exceptions/MSVC/VisualStudioExceptionPrinter.h"
#include "Exceptions/MSVC/VisualStudioStackTraceProvider.h"
#elif defined(__ANDROID__)
#include "Exceptions/Android/AndroidStackTraceProvider.h"
#include "Exceptions/Posix/PosixExceptionCatcher.h"
#include "Exceptions/Posix/PosixExceptionPrinter.h"
#else
#include "Exceptions/Glibc/GlibcStackTraceProvider.h"
#include "Exceptions/Posix/PosixExceptionCatcher.h"
#include "Exceptions/Posix/PosixExceptionPrinter.h"
#endif


namespace exceptions {

ExceptionCatcherFactory::ExceptionCatcherFactory(const std::shared_ptr<logging::Logger>& logger)
    : logger_(logger),
#if defined(__APPLE__)
      stackTraceProvider_(std::make_shared<AppleStackTraceProvider>()),
      exceptionPrinter_(std::make_shared<PosixExceptionPrinter>())
#elif defined(_MSC_VER)
      stackTraceProvider_(std::make_shared<VisualStudioStackTraceProvider>()),
      exceptionPrinter_(std::make_shared<VisualStudioExceptionPrinter>())
#elif defined(__ANDROID__)
      stackTraceProvider_(std::make_shared<AndroidStackTraceProvider>()),
      exceptionPrinter_(std::make_shared<PosixExceptionPrinter>())
#else
      stackTraceProvider_(std::make_shared<GlibcStackTraceProvider>()),
      exceptionPrinter_(std::make_shared<PosixExceptionPrinter>())
#endif
{
}

ExceptionCatcherFactory::~ExceptionCatcherFactory() {}

std::shared_ptr<IExceptionCatcher> ExceptionCatcherFactory::CreateExceptionCatcher() const {
#if defined(__APPLE__)
  return PosixExceptionCatcher::GetInstance();
#elif defined(_MSC_VER)
  return VisualStudioExceptionCatcher::GetInstance();
#elif defined(__ANDROID__)
  return PosixExceptionCatcher::GetInstance();
#else
  return PosixExceptionCatcher::GetInstance();
#endif
}

std::shared_ptr<IStackTraceProvider> ExceptionCatcherFactory::CreateStackTraceProvider() const {
  return stackTraceProvider_;
}

std::shared_ptr<IExceptionPrinter> ExceptionCatcherFactory::CreateExceptionPrinter() const { return exceptionPrinter_; }

}  // namespace exceptions

