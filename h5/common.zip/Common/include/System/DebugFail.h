
#pragma once

#include "System/DebugAssert.h"

#define _DEBUG_FAIL_FMT(format, ...) \
  do { _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(false, format, ##__VA_ARGS__); } while (false)

#define _DEBUG_FAIL(message) \
  do { _INTERNAL__DEBUG_ASSERT_WITH_BOOL(false, message); } while (false)
