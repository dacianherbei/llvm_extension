
#pragma once

#include <cstdint>
#include <cstring>
#include <sstream>

#include <boost/functional/hash.hpp>


namespace system {

#pragma pack(push, 1)
struct Uint24_t final {
  uint8_t data[3];

  Uint24_t() {}

  explicit Uint24_t(int32_t val) { *this = val; }

  explicit Uint24_t(uint32_t val) { *this = val; }

  explicit Uint24_t(uint64_t val) { *this = static_cast<uint32_t>(val); }

#ifdef __APPLE__
  explicit Uint24_t(size_t val) { *this = static_cast<uint32_t>(val); }
#endif

  uint32_t AsUint32() const {
    return (static_cast<uint32_t>(data[0]) << 0) | (static_cast<uint32_t>(data[1]) << 8) |
           (static_cast<uint32_t>(data[2]) << 16);
  }

  uint32_t AsNtohlUint32() const { return AsHtonlUint32(); }

  uint32_t AsHtonlUint32() const {
    return (static_cast<uint32_t>(data[0]) << 16) | (static_cast<uint32_t>(data[1]) << 8) |
           (static_cast<uint32_t>(data[2]) << 0);
  }

  operator uint32_t() const { return AsUint32(); }

  Uint24_t& operator=(const uint32_t input) {
    memcpy(data, &input, sizeof(data));
    return *this;
  }

  bool operator==(const Uint24_t& val) const { return static_cast<uint32_t>(*this) == static_cast<uint32_t>(val); }

  bool operator!=(const Uint24_t& val) const { return !(*this == val); }

  /***********************************************/

  Uint24_t operator^(const Uint24_t& val) const {
    return Uint24_t(static_cast<uint32_t>(*this) ^ static_cast<uint32_t>(val));
  }

  /***********************************************/

  Uint24_t operator^(const uint32_t val) const { return Uint24_t(static_cast<uint32_t>(*this) ^ val); }

  /***********************************************/

  Uint24_t& operator^=(const Uint24_t& val) {
    *this = *this ^ val;
    return *this;
  }

  /***********************************************/

  Uint24_t& operator^=(const uint32_t val) {
    *this = *this ^ val;
    return *this;
  }

  /**********************************************/

  Uint24_t operator>>(const uint32_t val) const { return Uint24_t(static_cast<uint32_t>(*this) >> val); }

  Uint24_t operator<<(const uint32_t val) const { return Uint24_t(static_cast<uint32_t>(*this) << val); }

  /***********************************************/

  Uint24_t& operator>>=(const uint32_t val) {
    *this = *this >> val;
    return *this;
  }

  Uint24_t& operator<<=(const uint32_t val) {
    *this = *this << val;
    return *this;
  }

  Uint24_t& operator+=(const int val) {
    *this = *this + val;
    return *this;
  }

  Uint24_t& operator++() { return *this += 1; }
  Uint24_t operator++(int) {
    auto oldThis = *this;
    *this += 1;
    return oldThis;
  }

  Uint24_t& operator-=(const int val) {
    *this = *this - val;
    return *this;
  }

  Uint24_t& operator--() { return *this -= 1; }
  Uint24_t operator--(int) {
    auto oldThis = *this;
    *this -= 1;
    return oldThis;
  }
};
#pragma pack(pop)

inline std::ostream& operator<<(std::ostream& stream, const Uint24_t& a) { return stream << a.AsUint32(); }

inline std::size_t hash_value(Uint24_t const& x) {
  std::size_t seed = 0;
  boost::hash_combine(seed, x.AsUint32());
  return seed;
}

}  // namespace system


namespace std {
template <>
struct hash<::system::Uint24_t> final {
  std::size_t operator()(const ::system::Uint24_t& value) const { return ::system::hash_value(value); }
};
}  // namespace std
