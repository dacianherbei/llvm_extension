
#pragma once

#if defined(_MSC_VER)
#define SNPRINTF _snprintf
#define SIZE_T_FORMAT "%Iu"
#else  // defined(_MSC_VER)
#define SNPRINTF snprintf
#define SIZE_T_FORMAT "%zu"
#endif  // defined(_MSC_VER)
