
#pragma once

#include <cstdint>
#include <cstring>
#include <sstream>

#include <boost/functional/hash.hpp>


namespace system {

#pragma pack(push, 1)
struct Uint48_t final {
  uint8_t data[6];

  Uint48_t() {}

  explicit Uint48_t(int64_t val) { *this = val; }

  explicit Uint48_t(uint64_t val) { *this = val; }

  explicit Uint48_t(uint32_t val) {
    uint32_t* dataUint32 = reinterpret_cast<uint32_t*>(data);
    *dataUint32 = val;

    data[4] = 0;
    data[5] = 0;
  }

  explicit Uint48_t(int32_t val) {
    int32_t* dataInt32 = reinterpret_cast<int32_t*>(data);
    *dataInt32 = val;

    // Sign-extend to 16 higher-order bits
    data[4] = (val & 0x80000000) ? 0xFF : 0x00;
    data[5] = data[4];
  }

#ifdef __APPLE__
  explicit Uint48_t(size_t val) {
    size_t* dataSizeT = reinterpret_cast<size_t*>(data);
    *dataSizeT = val;

    data[4] = 0;
    data[5] = 0;
  }
#endif

  uint64_t AsUint64() const {
    return (static_cast<uint64_t>(data[0]) << 0) | (static_cast<uint64_t>(data[1]) << 8) |
           (static_cast<uint64_t>(data[2]) << 16) | (static_cast<uint64_t>(data[3]) << 24) |
           (static_cast<uint64_t>(data[4]) << 32) | (static_cast<uint64_t>(data[5]) << 40);
  }

  uint64_t AsNtohlUint64() const { return AsHtonlUint64(); }

  uint64_t AsHtonlUint64() const {
    return (static_cast<uint64_t>(data[0]) << 40) | (static_cast<uint64_t>(data[1]) << 32) |
           (static_cast<uint64_t>(data[2]) << 24) | (static_cast<uint64_t>(data[3]) << 16) |
           (static_cast<uint64_t>(data[4]) << 8) | (static_cast<uint64_t>(data[5]) << 0);
  }

  operator int64_t() const { return AsUint64(); }

  Uint48_t& operator=(const int64_t input) {
    memcpy(data, &input, sizeof(data));
    return *this;
  }

  bool operator==(const Uint48_t& val) const { return static_cast<int>(*this) == static_cast<int>(val); }

  bool operator!=(const Uint48_t& val) const { return !(*this == val); }

  /***********************************************/

  Uint48_t operator^(const Uint48_t& val) const {
    return Uint48_t(static_cast<uint64_t>(*this) ^ static_cast<uint64_t>(val));
  }

  /***********************************************/

  Uint48_t operator^(const uint64_t val) const { return Uint48_t(static_cast<uint64_t>(*this) ^ val); }

  /***********************************************/

  Uint48_t& operator^=(const Uint48_t& val) {
    *this = *this ^ val;
    return *this;
  }

  /***********************************************/

  Uint48_t& operator^=(const uint64_t val) {
    *this = *this ^ val;
    return *this;
  }

  /**********************************************/

  Uint48_t operator>>(const uint64_t val) const { return Uint48_t(static_cast<uint64_t>(*this) >> val); }

  Uint48_t operator<<(const uint64_t val) const { return Uint48_t(static_cast<uint64_t>(*this) << val); }

  /***********************************************/

  Uint48_t& operator>>=(const uint64_t val) {
    *this = *this >> val;
    return *this;
  }

  Uint48_t& operator<<=(const uint64_t val) {
    *this = *this << val;
    return *this;
  }

  Uint48_t& operator+=(const int val) {
    *this = *this + val;
    return *this;
  }

  Uint48_t& operator++() { return *this += 1; }
  Uint48_t operator++(int) {
    auto oldThis = *this;
    *this += 1;
    return oldThis;
  }

  Uint48_t& operator-=(const int val) {
    *this = *this - val;
    return *this;
  }

  Uint48_t& operator--() { return *this -= 1; }
  Uint48_t operator--(int) {
    auto oldThis = *this;
    *this -= 1;
    return oldThis;
  }
};
#pragma pack(pop)

inline std::ostream& operator<<(std::ostream& stream, const Uint48_t& a) { return stream << a.AsUint64(); }

inline std::size_t hash_value(Uint48_t const& x) {
  std::size_t seed = 0;
  boost::hash_combine(seed, x.AsUint64());
  return seed;
}

}  // namespace system


namespace std {
template <>
struct hash<::system::Uint48_t> final {
  std::size_t operator()(const ::system::Uint48_t& value) const { return ::system::hash_value(value); }
};
}  // namespace std
