
#pragma once

// A macro to disallow the copy constructor and operator= functions
// This must be the last statement in a class definition.
#define DISALLOW_COPY_AND_ASSIGN(TypeName) \
 public:                                   \
  TypeName(const TypeName&) = delete;      \
  void operator=(const TypeName&) = delete
