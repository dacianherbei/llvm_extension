
#pragma once

#include <sstream>

#include "System/Noncopyable.h"


namespace system {

template <typename T>
class IKeyLessThan {
 public:
  virtual ~IKeyLessThan() {}

  virtual bool KeyLess(const T& other) const = 0;

 protected:
  IKeyLessThan() {}
};

template <typename T>
struct KeyLess final {
  bool operator()(const IKeyLessThan<T>& v1, const IKeyLessThan<T>& v2) const { return v1.KeyLess(v2); }
};

}  //  namespace system

