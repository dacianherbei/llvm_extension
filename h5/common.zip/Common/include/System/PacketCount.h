
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"


namespace system {

struct PacketCountBaseDimension final : boost::units::base_dimension<PacketCountBaseDimension, __COUNTER__> {};

#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()

BOOST_TYPEOF_REGISTER_TYPE(PacketCountBaseDimension)

using PacketCountDimension = PacketCountBaseDimension::dimension_type;

struct PacketCountBaseUnit final : boost::units::base_unit<PacketCountBaseUnit, PacketCountDimension, __COUNTER__> {
  static std::string name() { return ("packet count"); }
  static std::string symbol() { return ("P"); }
};

using PacketCountSystem = boost::units::make_system<PacketCountBaseUnit>::type;

using PacketCountUnit = boost::units::unit<PacketCountDimension, PacketCountSystem>;
using PacketCount = boost::units::quantity<PacketCountUnit, size_t>;
BOOST_UNITS_STATIC_CONSTANT(Packets, PacketCountUnit);

}  // namespace system

