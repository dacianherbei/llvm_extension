
#pragma once

#include <sstream>

#include "System/Noncopyable.h"


namespace system {

class IPrintable {
 public:
  virtual ~IPrintable() {}

  virtual void Print(std::ostream* stream) const = 0;

 protected:
  IPrintable() {}
};

inline std::ostream& operator<<(std::ostream& stream, const IPrintable& a) {
  a.Print(&stream);
  return stream;
}

}  //  namespace system

