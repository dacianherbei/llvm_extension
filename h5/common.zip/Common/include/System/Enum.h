
#pragma once

#include <string>

#include "System/BasicEnum.h"
#include "System/Fail.h"

// Internal helper to help declare else if statements in the from string statement
#define X__ENUM_CASE_FROMSTRING(r, data, elemTuple)                                         \
  else if (/* NOLINT(readability/braces) */                                                       \
           0 == strcmp(BOOST_PP_TUPLE_ELEM(1, data), X__ENUM_TUPLE_TO_STRING(elemTuple))) { \
    return BOOST_PP_TUPLE_ELEM(0, data)::X__ENUM_NAME(elemTuple);                           \
  }

// Internal helper to help declare else if statements in the from string case insensitive statement
#define X__ENUM_CASE_FROMSTRING_CASE_INSENSITIVE(r, data, elemTuple)                         \
  else if (/* NOLINT(readability/braces) */                                                        \
           0 == STRICMP(BOOST_PP_TUPLE_ELEM(1, data), X__ENUM_TUPLE_TO_STRING(elemTuple))) { \
    return BOOST_PP_TUPLE_ELEM(0, data)::X__ENUM_NAME(elemTuple);                            \
  }

// Macro to define an enum with a checked cast function.  name is the name of
// the enumeration to be defined and enumerators is the preprocessing sequence
// of enumerators to be defined.  See the usage example below.
#define DEFINE__ENUM(namespaces, name, type, enumerators)                                                   \
  DEFINE__BASIC_ENUM(namespaces, name, type, enumerators)                                                   \
  BEGIN_JUST_FIRST_NAMESPACE(namespaces)                                                                          \
                                                                                                                  \
  template <class T>                                                                                              \
  T FromString(const char* a);                                                                                    \
                                                                                                                  \
  template <>                                                                                                     \
  inline APPEND_NAMESPACE_TO(namespaces, name) FromString<APPEND_NAMESPACE_TO(namespaces, name)>(const char* a) { \
    if (0) {                                                                                                      \
    }                                                                                                             \
    BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE_FROMSTRING, (APPEND_NAMESPACE_TO(namespaces, name), a), enumerators) \
    else { /* NOLINT(readability/braces) */                                                                       \
      _FAIL(                                                                                                \
          "FromString called with input [" << a << "] that can't be converted for enum "                          \
          "[" << BOOST_PP_STRINGIZE(APPEND_NAMESPACE_TO(namespaces, name)) << "]");                               \
    }                                                                                                             \
  }                                                                                                               \
                                                                                                                  \
  template <class T>                                                                                              \
  T FromString(const std::string& a);                                                                             \
                                                                                                                  \
  template <>                                                                                                     \
  inline APPEND_NAMESPACE_TO(namespaces, name)                                                                    \
      FromString<APPEND_NAMESPACE_TO(namespaces, name)>(const std::string& a) {                                   \
    return FromString<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str());                                          \
  }                                                                                                               \
                                                                                                                  \
  template <class T>                                                                                              \
  T FromStringCaseInsensitive(const char* a);                                                                     \
                                                                                                                  \
  template <>                                                                                                     \
  inline APPEND_NAMESPACE_TO(namespaces, name)                                                                    \
      FromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(const char* a) {                           \
    if (0) {                                                                                                      \
    }                                                                                                             \
    BOOST_PP_SEQ_FOR_EACH(                                                                                        \
        X__ENUM_CASE_FROMSTRING_CASE_INSENSITIVE, (APPEND_NAMESPACE_TO(namespaces, name), a), enumerators)  \
    else { /* NOLINT(readability/braces) */                                                                       \
      _FAIL(                                                                                                \
          "FromString called with input [" << a << "] that can't be converted "                                   \
          "for enum [" << BOOST_PP_STRINGIZE(APPEND_NAMESPACE_TO(namespaces, name)) << "]");                      \
    }                                                                                                             \
  }                                                                                                               \
                                                                                                                  \
  template <class T>                                                                                              \
  T FromStringCaseInsensitive(const std::string& a);                                                              \
                                                                                                                  \
  template <>                                                                                                     \
  inline APPEND_NAMESPACE_TO(namespaces, name)                                                                    \
      FromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(const std::string& a) {                    \
    return FromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str());                           \
  }                                                                                                               \
                                                                                                                  \
  CLOSE_JUST_FIRST_NAMESPACE(namespaces)
