
#pragma once

#include <cstdint>
#include <cstring>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <boost/functional/hash.hpp>
#include <boost/preprocessor.hpp>

#include "System/NamespacePreprocessorHelper.h"

#if defined(_MSC_VER)
#define STRICMP _stricmp
#else  // defined(_MSC_VER)
#define STRICMP strcasecmp
#endif  // defined(_MSC_VER)


namespace system {

// Internal helper to provide partial specialization for CheckedEnumCast
template <typename Target, typename Source>
struct CheckedEnumCastImpl;

// Internal helper to provide partial specialization for CheckedEnumTryCast
template <typename Target, typename Source>
struct CheckedEnumTryCastImpl;

// Exception thrown by CheckedEnumCast on cast failure
struct InvalidEnumCast : std::out_of_range {
 public:
  explicit InvalidEnumCast(const char* s) : std::out_of_range(s), message_(InitializeMessage()) {}

  virtual const char* what() const throw() { return message_.c_str(); }

 private:
  const std::string message_;

 private:
  std::string InitializeMessage() {
    std::stringstream whatStream;
    whatStream << "InvalidEnumCast[" << std::out_of_range::what() << "]";
    return whatStream.str();
  }
};

// Checked cast function
template <typename Target, typename Source>
Target CheckedEnumCast(Source s) {
  return CheckedEnumCastImpl<Target, Source>::DoCast(s);
}

// Checked try cast function
template <typename Target, typename Source>
bool CheckedEnumTryCast(Source s, Target* outEnum) {
  return CheckedEnumTryCastImpl<Target, Source>::TryCast(s, outEnum);
}

// Checked cast-or function
template <typename Target, typename Source>
Target CheckedEnumCastOr(Source s, Target castDefault) {
  Target returnEnum;
  if (CheckedEnumTryCastImpl<Target, Source>::TryCast(s, &returnEnum)) {
    return returnEnum;
  } else {
    return castDefault;
  }
}

}  // namespace system


#define X__ENUM_NAME(elemTuple) BOOST_PP_TUPLE_ELEM(0, elemTuple)
#define X__ENUM_VALUE(elemTuple) BOOST_PP_TUPLE_ELEM(1, elemTuple)
#define X__ENUM_OPTIONAL_STRINGVALUE(elemTuple) BOOST_PP_TUPLE_ELEM(2, elemTuple)

// Internal helper to help declare case labels in the checked cast function
#define X__ENUM_CASE(r, data, elemTuple) case data::X__ENUM_NAME(elemTuple):

// Internal helper to help create a comma separated list for ToVector statement
#define X__ENUM_CSV_TOVECTOR(r, data, elemTuple) data::X__ENUM_NAME(elemTuple) BOOST_PP_COMMA()

// Internal helper to help create a comma separated list for ToVector statement
#define X__ENUM_CSV_TOUNDERLYINGVECTOR(r, data, elemTuple) \
  ToUnderlyingType(data::X__ENUM_NAME(elemTuple)) BOOST_PP_COMMA()

// Internal helper to convert an enum to a string
#define X__ENUM_TUPLE_TO_STRING(elemTuple)           \
  BOOST_PP_IIF(                                            \
      BOOST_PP_GREATER(BOOST_PP_TUPLE_SIZE(elemTuple), 2), \
      X__ENUM_OPTIONAL_STRINGVALUE(elemTuple),       \
      BOOST_PP_STRINGIZE(X__ENUM_NAME(elemTuple)))

// Internal helper to help declare case labels in the to string statement
#define X__ENUM_CASE_TOSTRING(r, data, elemTuple) \
  case data::X__ENUM_NAME(elemTuple):             \
    return X__ENUM_TUPLE_TO_STRING(elemTuple);

// Internal helper to help declare case labels in the print statement
#define X__ENUM_CASE_TOSTREAM(r, data, elemTuple) \
  case data::X__ENUM_NAME(elemTuple):             \
    return stream << X__ENUM_TUPLE_TO_STRING(elemTuple);

// Internal helper to help declare else if statements in the try from string statement
#define X__ENUM_CASE_TRYFROMSTRING(r, data, elemTuple)                                      \
  else if (/* NOLINT(readability/braces) */                                                       \
           0 == strcmp(BOOST_PP_TUPLE_ELEM(1, data), X__ENUM_TUPLE_TO_STRING(elemTuple))) { \
    *BOOST_PP_TUPLE_ELEM(2, data) = BOOST_PP_TUPLE_ELEM(0, data)::X__ENUM_NAME(elemTuple);  \
    return true;                                                                                  \
  }

// Internal helper to help declare else if statements in the try from string case insensitive statement
#define X__ENUM_CASE_TRYFROMSTRING_CASE_INSENSITIVE(r, data, elemTuple)                      \
  else if (/* NOLINT(readability/braces) */                                                        \
           0 == STRICMP(BOOST_PP_TUPLE_ELEM(1, data), X__ENUM_TUPLE_TO_STRING(elemTuple))) { \
    *BOOST_PP_TUPLE_ELEM(2, data) = BOOST_PP_TUPLE_ELEM(0, data)::X__ENUM_NAME(elemTuple);   \
    return true;                                                                                   \
  }

// Internal helper to help declare enum entries
#define X__ENUM(r, data, elemTuple) X__ENUM_NAME(elemTuple) = X__ENUM_VALUE(elemTuple),

// Macro to define an enum with a checked cast function.  name is the name of
// the enumeration to be defined and enumerators is the preprocessing sequence
// of enumerators to be defined.  See the usage example below.
#define DEFINE__BASIC_ENUM(namespaces, name, type, enumerators)                                              \
  BEGIN_NAMESPACE(namespaces)                                                                                      \
                                                                                                                   \
  enum class name : type { BOOST_PP_SEQ_FOR_EACH(X__ENUM, 0, enumerators) };                                 \
                                                                                                                   \
  CLOSE_NAMESPACE(namespaces)                                                                                      \
                                                                                                                   \
  BEGIN_JUST_FIRST_NAMESPACE(namespaces)                                                                           \
                                                                                                                   \
  template <class T>                                                                                               \
  struct EnumUnderlyingType;                                                                                 \
                                                                                                                   \
  template <>                                                                                                      \
  struct EnumUnderlyingType<APPEND_NAMESPACE_TO(namespaces, name)> {                                         \
    using Type = type;                                                                                             \
  };                                                                                                               \
                                                                                                                   \
  inline type ToUnderlyingType(const APPEND_NAMESPACE_TO(namespaces, name) & a) { return static_cast<type>(a); }   \
                                                                                                                   \
  template <class T>                                                                                               \
  std::vector<T> ToVector();                                                                                       \
                                                                                                                   \
  template <>                                                                                                      \
  inline std::vector<APPEND_NAMESPACE_TO(namespaces, name)> ToVector<APPEND_NAMESPACE_TO(namespaces, name)>() {    \
    std::vector<APPEND_NAMESPACE_TO(namespaces, name)> returnVector = {                                            \
        BOOST_PP_SEQ_FOR_EACH(X__ENUM_CSV_TOVECTOR, APPEND_NAMESPACE_TO(namespaces, name), enumerators)};    \
    return returnVector;                                                                                           \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  std::vector<typename EnumUnderlyingType<T>::Type> ToUnderlyingTypeVector();                                \
                                                                                                                   \
  template <>                                                                                                      \
  inline std::vector<typename EnumUnderlyingType<APPEND_NAMESPACE_TO(namespaces, name)>::Type>               \
  ToUnderlyingTypeVector<APPEND_NAMESPACE_TO(namespaces, name)>() {                                                \
    std::vector<typename EnumUnderlyingType<APPEND_NAMESPACE_TO(namespaces, name)>::Type> returnVector = {   \
        BOOST_PP_SEQ_FOR_EACH(                                                                                     \
            X__ENUM_CSV_TOUNDERLYINGVECTOR, APPEND_NAMESPACE_TO(namespaces, name), enumerators)};            \
    return returnVector;                                                                                           \
  }                                                                                                                \
                                                                                                                   \
  inline std::string ToStdString(const APPEND_NAMESPACE_TO(namespaces, name) & a) {                                \
    switch (a) {                                                                                                   \
      BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE_TOSTRING, APPEND_NAMESPACE_TO(namespaces, name), enumerators)       \
      default: {                                                                                                   \
        std::stringstream errorMessage;                                                                            \
        errorMessage << "[Unknown " << BOOST_PP_STRINGIZE(APPEND_NAMESPACE_TO(namespaces, name)) << "="            \
                     << static_cast<unsigned>(a) << "]";                                                           \
        return errorMessage.str();                                                                                 \
      }                                                                                                            \
    }                                                                                                              \
  }                                                                                                                \
                                                                                                                   \
  inline const char* ToCString(const APPEND_NAMESPACE_TO(namespaces, name) & a) {                                  \
    switch (a) {                                                                                                   \
      BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE_TOSTRING, APPEND_NAMESPACE_TO(namespaces, name), enumerators)       \
      default: {                                                                                                   \
        return "Unknown";                                                                                          \
      }                                                                                                            \
    }                                                                                                              \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  bool TryFromString(const char* a, T* outEnum);                                                                   \
                                                                                                                   \
  template <>                                                                                                      \
  inline bool TryFromString<APPEND_NAMESPACE_TO(namespaces, name)>(                                                \
      const char* a, APPEND_NAMESPACE_TO(namespaces, name) * outEnum) {                                            \
    if (0) {                                                                                                       \
    }                                                                                                              \
    BOOST_PP_SEQ_FOR_EACH(                                                                                         \
        X__ENUM_CASE_TRYFROMSTRING, (APPEND_NAMESPACE_TO(namespaces, name), a, outEnum), enumerators)        \
    else { /* NOLINT(readability/braces) */                                                                        \
      return false;                                                                                                \
    }                                                                                                              \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  bool TryFromString(const std::string& a, T* outEnum);                                                            \
                                                                                                                   \
  template <>                                                                                                      \
  inline bool TryFromString<APPEND_NAMESPACE_TO(namespaces, name)>(                                                \
      const std::string& a, APPEND_NAMESPACE_TO(namespaces, name) * outEnum) {                                     \
    return TryFromString<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str(), outEnum);                               \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  bool TryFromStringCaseInsensitive(const char* a, T* outEnum);                                                    \
                                                                                                                   \
  template <>                                                                                                      \
  inline bool TryFromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(                                 \
      const char* a, APPEND_NAMESPACE_TO(namespaces, name) * outEnum) {                                            \
    if (0) {                                                                                                       \
    }                                                                                                              \
    BOOST_PP_SEQ_FOR_EACH(                                                                                         \
        X__ENUM_CASE_TRYFROMSTRING_CASE_INSENSITIVE,                                                         \
        (APPEND_NAMESPACE_TO(namespaces, name), a, outEnum),                                                       \
        enumerators)                                                                                               \
    else { /* NOLINT(readability/braces) */                                                                        \
      return false;                                                                                                \
    }                                                                                                              \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  bool TryFromStringCaseInsensitive(const std::string& a, T* outEnum);                                             \
                                                                                                                   \
  template <>                                                                                                      \
  inline bool TryFromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(                                 \
      const std::string& a, APPEND_NAMESPACE_TO(namespaces, name) * outEnum) {                                     \
    return TryFromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str(), outEnum);                \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  T FromStringOr(const char* a, T defaultEnum);                                                                    \
                                                                                                                   \
  template <>                                                                                                      \
  inline APPEND_NAMESPACE_TO(namespaces, name) FromStringOr<APPEND_NAMESPACE_TO(namespaces, name)>(                \
      const char* a, APPEND_NAMESPACE_TO(namespaces, name) defaultEnum) {                                          \
    APPEND_NAMESPACE_TO(namespaces, name) returnEnum = defaultEnum;                                                \
    TryFromString<APPEND_NAMESPACE_TO(namespaces, name)>(a, &returnEnum);                                          \
    return returnEnum;                                                                                             \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  T FromStringCaseInsensitiveOr(const char* a, T defaultEnum);                                                     \
                                                                                                                   \
  template <>                                                                                                      \
  inline APPEND_NAMESPACE_TO(namespaces, name) FromStringCaseInsensitiveOr<APPEND_NAMESPACE_TO(namespaces, name)>( \
      const char* a, APPEND_NAMESPACE_TO(namespaces, name) defaultEnum) {                                          \
    APPEND_NAMESPACE_TO(namespaces, name) returnEnum = defaultEnum;                                                \
    TryFromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(a, &returnEnum);                           \
    return returnEnum;                                                                                             \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  T FromStringOr(const std::string& a, T defaultEnum);                                                             \
                                                                                                                   \
  template <>                                                                                                      \
  inline APPEND_NAMESPACE_TO(namespaces, name) FromStringOr<APPEND_NAMESPACE_TO(namespaces, name)>(                \
      const std::string& a, APPEND_NAMESPACE_TO(namespaces, name) defaultEnum) {                                   \
    return FromStringOr<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str(), defaultEnum);                            \
  }                                                                                                                \
                                                                                                                   \
  template <class T>                                                                                               \
  T FromStringCaseInsensitiveOr(const std::string& a, T defaultEnum);                                              \
                                                                                                                   \
  template <>                                                                                                      \
  inline APPEND_NAMESPACE_TO(namespaces, name) FromStringCaseInsensitiveOr<APPEND_NAMESPACE_TO(namespaces, name)>( \
      const std::string& a, APPEND_NAMESPACE_TO(namespaces, name) defaultEnum) {                                   \
    return FromStringCaseInsensitiveOr<APPEND_NAMESPACE_TO(namespaces, name)>(a.c_str(), defaultEnum);             \
  }                                                                                                                \
  CLOSE_JUST_FIRST_NAMESPACE(namespaces)                                                                           \
  BEGIN_NAMESPACE(namespaces)                                                                                      \
                                                                                                                   \
  inline std::size_t hash_value(APPEND_NAMESPACE_TO(namespaces, name) const& v) {                                  \
    std::size_t seed = 0;                                                                                          \
    boost::hash_combine(seed, static_cast<uint64_t>(v));                                                           \
    return seed;                                                                                                   \
  }                                                                                                                \
                                                                                                                   \
  inline std::ostream& operator<<(std::ostream& stream, const APPEND_NAMESPACE_TO(namespaces, name) & a) {         \
    switch (a) {                                                                                                   \
      BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE_TOSTREAM, APPEND_NAMESPACE_TO(namespaces, name), enumerators)       \
      default:                                                                                                     \
        return stream << "[Unknown " << BOOST_PP_STRINGIZE(APPEND_NAMESPACE_TO(namespaces, name)) << "="           \
                      << static_cast<unsigned>(a) << "]";                                                          \
    }                                                                                                              \
  }                                                                                                                \
                                                                                                                   \
  inline std::istream& operator>>(std::istream& stream, APPEND_NAMESPACE_TO(namespaces, name) & a) {               \
    std::string string;                                                                                            \
    stream >> string;                                                                                              \
    if (!TryFromStringCaseInsensitive<APPEND_NAMESPACE_TO(namespaces, name)>(string, &a)) {                        \
      stream.setstate(std::ios::failbit);                                                                          \
      return stream;                                                                                               \
    }                                                                                                              \
                                                                                                                   \
    return stream;                                                                                                 \
  }                                                                                                                \
                                                                                                                   \
  CLOSE_NAMESPACE(namespaces)                                                                                      \
                                                                                                                   \
                                                                                                 \
  namespace system {                                                                                               \
                                                                                                                   \
  template <typename Source>                                                                                       \
  struct CheckedEnumCastImpl<APPEND_NAMESPACE_TO(namespaces, name), Source> {                                      \
    static APPEND_NAMESPACE_TO(namespaces, name) DoCast(Source s) {                                                \
      switch ((APPEND_NAMESPACE_TO(namespaces, name))s) {                                                          \
        BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE, APPEND_NAMESPACE_TO(namespaces, name), enumerators)              \
        return static_cast<APPEND_NAMESPACE_TO(namespaces, name)>(s);                                              \
        default:                                                                                                   \
          throw InvalidEnumCast(BOOST_PP_STRINGIZE(APPEND_NAMESPACE_TO(namespaces, name)));                        \
      }                                                                                                            \
      return APPEND_NAMESPACE_TO(namespaces, name)();                                                              \
    }                                                                                                              \
  };                                                                                                               \
                                                                                                                   \
  template <typename Source>                                                                                       \
  struct CheckedEnumTryCastImpl<APPEND_NAMESPACE_TO(namespaces, name), Source> {                                   \
    static bool TryCast(Source s, APPEND_NAMESPACE_TO(namespaces, name) * outEnum) {                               \
      switch ((APPEND_NAMESPACE_TO(namespaces, name))s) {                                                          \
        BOOST_PP_SEQ_FOR_EACH(X__ENUM_CASE, APPEND_NAMESPACE_TO(namespaces, name), enumerators)              \
        *outEnum = static_cast<APPEND_NAMESPACE_TO(namespaces, name)>(s);                                          \
        return true;                                                                                               \
        default:                                                                                                   \
          break;                                                                                                   \
      }                                                                                                            \
      return false;                                                                                                \
    }                                                                                                              \
  };                                                                                                               \
                                                                                                                   \
  } /* namespace system */                                                                                         \
  } /* namespace  */                                                                                         \
                                                                                                                   \
  namespace std {                                                                                                  \
                                                                                                                   \
  template <>                                                                                                      \
  struct hash<APPEND_NAMESPACE_TO(namespaces, name)> {                                                             \
    size_t operator()(const APPEND_NAMESPACE_TO(namespaces, name) & v) const {                                     \
      return APPEND_NAMESPACE(namespaces)::hash_value(v);                                                          \
    }                                                                                                              \
  };                                                                                                               \
                                                                                                                   \
  } /* namespace std */
