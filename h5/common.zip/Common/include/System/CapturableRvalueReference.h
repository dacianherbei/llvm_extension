
#pragma once

#include <memory>


namespace system {

template <typename T>
class CapturableRvalueReference final {
 public:
  static std::shared_ptr<CapturableRvalueReference<T>> CreateCapturableRvalueReference(T&& value) {
    return std::shared_ptr<CapturableRvalueReference<T>>(new CapturableRvalueReference<T>(std::move(value)));
  }

  static CapturableRvalueReference<T> CreateCapturableRvalueReferenceOnStack(T&& value) {
    return CapturableRvalueReference<T>(std::move(value));
  }

  CapturableRvalueReference(CapturableRvalueReference&& other) noexcept : value_(std::move(other.value_)) {}
  CapturableRvalueReference(const CapturableRvalueReference& other) : value_(std::move(other.value_)) {}

  CapturableRvalueReference& operator=(const CapturableRvalueReference&) = delete;

  T&& Move() { return std::move(value_); }

  T* GetPointerToContainedValue() { return &value_; }

 private:
  mutable typename std::remove_cv<typename std::remove_reference<T>::type>::type value_;

 private:
  explicit CapturableRvalueReference(T&& value) : value_(std::move(value)) {}  // NOLINT(whitespace/operators)
};

class CapturableRvalueReferenceFactory final {
 public:
  template <typename T>
  static std::shared_ptr<CapturableRvalueReference<T>> CreateCapturableRvalueReference(T&& value) {
    return CapturableRvalueReference<T>::CreateCapturableRvalueReference(std::forward<T>(value));
  }

  template <typename T>
  static CapturableRvalueReference<T> CreateCapturableRvalueReferenceOnStack(T&& value) {
    return CapturableRvalueReference<T>::CreateCapturableRvalueReferenceOnStack(std::forward<T>(value));
  }
};

}  //  namespace system

