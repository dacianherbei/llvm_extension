
#pragma once


namespace system {

template <typename T>
struct ExtractValueType final {
  using type = T;
};

}  // namespace system

