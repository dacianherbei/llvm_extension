
#pragma once

#include <atomic>
#include <memory>

#include "Threading/Mutex.h"


namespace system {

// See: http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2014/n4162.pdf
template <typename T, template <typename> class PointerType = std::shared_ptr>
class AtomicSharedPtr final {
 public:
  AtomicSharedPtr();

  AtomicSharedPtr(const AtomicSharedPtr<T, PointerType>& other);

  AtomicSharedPtr(AtomicSharedPtr<T, PointerType>&& other);

  AtomicSharedPtr(const PointerType<T>& pointer);  // NOLINT(runtime/explicit)

  PointerType<T> operator=(const PointerType<T>& other);

  AtomicSharedPtr<T, PointerType>& operator=(const AtomicSharedPtr<T, PointerType>& other);

  bool operator==(const PointerType<T>& other) const;

  bool operator!=(const PointerType<T>& other) const;

  explicit operator bool() const;

  bool IsLockFree() const;

  void Store(const PointerType<T>& newPointer, const std::memory_order order = std::memory_order_seq_cst);

  void Store(PointerType<T>&& newPointer, const std::memory_order order = std::memory_order_seq_cst);

  PointerType<T> Load(const std::memory_order order = std::memory_order_seq_cst) const;

  void Reset();

  operator PointerType<T>() const;

  PointerType<T> Exchange(const PointerType<T>& newPointer, const std::memory_order order = std::memory_order_seq_cst);

  bool CompareExchangeWeak(
      PointerType<T>& expected,  // NOLINT(runtime/references)
      const PointerType<T>& desired,
      const std::memory_order success,
      const std::memory_order failure);

  bool CompareExchangeWeak(
      PointerType<T>& expected,  // NOLINT(runtime/references)
      const PointerType<T>& desired,
      const std::memory_order order = std::memory_order_seq_cst);

  bool CompareExchangeStrong(
      PointerType<T>& expected,  // NOLINT(runtime/references)
      const PointerType<T>& desired,
      const std::memory_order success,
      const std::memory_order failure);

  bool CompareExchangeStrong(
      PointerType<T>& expected,  // NOLINT(runtime/references)
      const PointerType<T>& desired,
      const std::memory_order order = std::memory_order_seq_cst);

 private:
  using Lock = ::threading::Mutex;

 private:
  PointerType<T> inner_;
  mutable Lock lock_;
};

template <typename T, template <typename> class PointerType>
bool operator==(const PointerType<T>& left, const AtomicSharedPtr<T, PointerType>& right);

template <typename T, template <typename> class PointerType>
bool operator!=(const PointerType<T>& left, const AtomicSharedPtr<T, PointerType>& right);

}  // namespace system


#define COMMON_INCLUDE_SYSTEM_ATOMICSHAREDPTR_H_
#include "System/AtomicSharedPtr-inl.h"
