
#pragma once

#include <cstdint>
#include <type_traits>

#include <boost/preprocessor.hpp>

#include "System/NamespacePreprocessorHelper.h"

#define DEFINE_ENUM_BITWISE_OPERATIONS(namespaces, name)                                               \
  BEGIN_NAMESPACE(namespaces)                                                                          \
                                                                                                       \
  inline typename std::underlying_type<name>::type __ToUnderlyingType(const name& value) {             \
    return static_cast<typename std::underlying_type<name>::type>(value);                              \
  }                                                                                                    \
                                                                                                       \
  inline name operator&(const name& value1, const name& value2) {                                      \
    return static_cast<name>(__ToUnderlyingType(value1) & __ToUnderlyingType(value2));                 \
  }                                                                                                    \
                                                                                                       \
  inline name operator|(const name& value1, const name& value2) {                                      \
    return static_cast<name>(__ToUnderlyingType(value1) | __ToUnderlyingType(value2));                 \
  }                                                                                                    \
                                                                                                       \
  inline name operator^(const name& value1, const name& value2) {                                      \
    return static_cast<name>(__ToUnderlyingType(value1) ^ __ToUnderlyingType(value2));                 \
  }                                                                                                    \
                                                                                                       \
  inline name operator~(const name& value1) { return static_cast<name>(~__ToUnderlyingType(value1)); } \
                                                                                                       \
  inline name& operator&=(name& value1, const name& value2) {                                          \
    value1 = static_cast<name>(__ToUnderlyingType(value1) & __ToUnderlyingType(value2));               \
    return value1;                                                                                     \
  }                                                                                                    \
                                                                                                       \
  inline name& operator|=(name& value1, const name& value2) {                                          \
    value1 = static_cast<name>(__ToUnderlyingType(value1) | __ToUnderlyingType(value2));               \
    return value1;                                                                                     \
  }                                                                                                    \
                                                                                                       \
  inline name& operator^=(name& value1, const name& value2) {                                          \
    value1 = static_cast<name>(__ToUnderlyingType(value1) ^ __ToUnderlyingType(value2));               \
    return value1;                                                                                     \
  }                                                                                                    \
                                                                                                       \
  CLOSE_NAMESPACE(namespaces)
