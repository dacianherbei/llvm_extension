
#pragma once

#include <cstring>
#include <iostream>
#include <string>

#include <boost/current_function.hpp>
#include <boost/preprocessor.hpp>

#include "Logging/LoggingVerbosityHelper.h"

#if defined(__FUNCTION__)
#define _CURRENT_FUNCTION __FUNCTION__
#else
#define _CURRENT_FUNCTION BOOST_CURRENT_FUNCTION
#endif

#define _CURRENT_FUNCTION_STREAM_EXPRESSION _CURRENT_FUNCTION << ", line " << __LINE__

#define _CONSTRUCT_STREAM_CURRENT_FUNCTION_MESSAGE(outputString, message)                           \
  {                                                                                                 \
    std::stringstream __stream;                                                                     \
    __stream << _CURRENT_FUNCTION_STREAM_EXPRESSION << ": " << ::logging::Verbose << message; \
    outputString = __stream.str();                                                                  \
  }

#define _CURRENT_FUNCTION_MESSAGE(message)                                                                       \
  static_cast<const std::stringstream&>(std::stringstream() << _CURRENT_FUNCTION_STREAM_EXPRESSION << ": " << message) \
      .str()
