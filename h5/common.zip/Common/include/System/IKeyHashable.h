
#pragma once

#include <sstream>

#include "System/Noncopyable.h"


namespace system {

class IKeyHashable {
 public:
  virtual ~IKeyHashable() {}

  virtual size_t KeyHash() const = 0;

 protected:
  IKeyHashable() {}
};

inline std::size_t hash_value(IKeyHashable const& v) { return v.KeyHash(); }

}  //  namespace system


namespace std {

template <>
struct hash<::system::IKeyHashable> {
  size_t operator()(const ::system::IKeyHashable& v) const { return ::system::hash_value(v); }
};

}  // namespace std
