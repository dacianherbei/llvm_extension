
#pragma once

#include <atomic>

#include <boost/optional.hpp>

#include "Boost/OptionalUtilities.h"
#include "Threading/Mutex.h"


namespace system {

template <typename T, typename TLockType = ::threading::Mutex>
class AtomicOptional final {
 public:
  AtomicOptional();

  AtomicOptional(const AtomicOptional<T, TLockType>& other);

  AtomicOptional(const boost::optional<T>& value);  // NOLINT(runtime/explicit)

  AtomicOptional<T, TLockType>& operator=(T&& other);

  AtomicOptional<T, TLockType>& operator=(boost::optional<T>&& other);

  AtomicOptional<T, TLockType>& operator=(const boost::optional<T>& other);

  AtomicOptional<T, TLockType>& operator=(const AtomicOptional<T, TLockType>& other);

  bool operator==(const AtomicOptional<T, TLockType>& other) const;

  bool operator!=(const AtomicOptional<T, TLockType>& other) const;

  explicit operator bool() const;

  bool IsLockFree() const;

  void Store(const boost::optional<T>& newValue, const std::memory_order order = std::memory_order_seq_cst);

  void Store(boost::optional<T>&& newValue, const std::memory_order order = std::memory_order_seq_cst);

  boost::optional<T> Load(const std::memory_order order = std::memory_order_seq_cst) const;

  operator boost::optional<T>() const;

  boost::optional<T> Exchange(
      const boost::optional<T>& newValue, const std::memory_order order = std::memory_order_seq_cst);

  bool CompareExchangeWeak(
      boost::optional<T>& expected,  // NOLINT(runtime/references)
      const boost::optional<T>& desired,
      const std::memory_order success,
      const std::memory_order failure);

  bool CompareExchangeWeak(
      boost::optional<T>& expected,  // NOLINT(runtime/references)
      const boost::optional<T>& desired,
      const std::memory_order order = std::memory_order_seq_cst);

  bool CompareExchangeStrong(
      boost::optional<T>& expected,  // NOLINT(runtime/references)
      const boost::optional<T>& desired,
      const std::memory_order success,
      const std::memory_order failure);

  bool CompareExchangeStrong(
      boost::optional<T>& expected,  // NOLINT(runtime/references)
      const boost::optional<T>& desired,
      const std::memory_order order = std::memory_order_seq_cst);

 private:
  boost::optional<T> inner_;
  mutable TLockType lock_;
};

template <typename T, typename TLockType>
bool operator==(const boost::optional<T>& left, const AtomicOptional<T>& right);

template <typename T, typename TLockType>
bool operator!=(const boost::optional<T>& left, const AtomicOptional<T>& right);

}  // namespace system


#define COMMON_INCLUDE_SYSTEM_ATOMICOPTIONAL_H_
#include "System/AtomicOptional-inl.h"
