
#pragma once

#include <memory>
#include <sstream>
#include <type_traits>


namespace system {

template <typename T>
class IKeyEquatable {
 public:
  virtual ~IKeyEquatable() {}

  virtual bool KeyEquals(const T& other) const = 0;

 protected:
  IKeyEquatable() {}
};

template <typename T>
struct KeyEquals final {
  bool operator()(const T& v1, const T& v2) const { return v1.KeyEquals(v2); }
  bool operator()(const std::shared_ptr<T>& v1, const std::shared_ptr<T>& v2) const {
    return v1 && v2 && (v1 == v2 || v1->KeyEquals(*v2));
  }

 private:
  static_assert(std::is_base_of<IKeyEquatable<T>, T>::value, "Type T must be derived from IKeyEquatable<T>");
};

}  //  namespace system

