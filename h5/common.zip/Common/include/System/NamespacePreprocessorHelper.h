
#pragma once

#include <boost/functional/hash.hpp>
#include <boost/preprocessor.hpp>

#define X_BEGIN_NAMESPACE(r, _, __namespace) namespace __namespace {
#define X_CLOSE_NAMESPACE(r, _, __namespace) }
#define X_APPEND_NAMESPACE(r, state, __namespace) state::__namespace
#define X_APPEND_NAMESPACE_1(namespaces) BOOST_PP_SEQ_HEAD(namespaces)
#define X_APPEND_NAMESPACE_N(namespaces) \
  BOOST_PP_SEQ_FOLD_LEFT(X_APPEND_NAMESPACE, BOOST_PP_SEQ_HEAD(namespaces), BOOST_PP_SEQ_TAIL(namespaces))

#define BEGIN_NAMESPACE(namespaces) BOOST_PP_SEQ_FOR_EACH(X_BEGIN_NAMESPACE, ~, namespaces)
#define CLOSE_NAMESPACE(namespaces) BOOST_PP_SEQ_FOR_EACH(X_CLOSE_NAMESPACE, ~, namespaces)
#define BEGIN_JUST_FIRST_NAMESPACE(namespaces) \
  BOOST_PP_SEQ_FOR_EACH(X_BEGIN_NAMESPACE, ~, BOOST_PP_SEQ_FIRST_N(1, namespaces))
#define CLOSE_JUST_FIRST_NAMESPACE(namespaces) \
  BOOST_PP_SEQ_FOR_EACH(X_CLOSE_NAMESPACE, ~, BOOST_PP_SEQ_FIRST_N(1, namespaces))

#define APPEND_NAMESPACE(namespaces)                                                                           \
  BOOST_PP_IIF(BOOST_PP_GREATER(BOOST_PP_SEQ_SIZE(namespaces), 1), X_APPEND_NAMESPACE_N, X_APPEND_NAMESPACE_1) \
  (namespaces)
#define APPEND_NAMESPACE_TO(namespaces, name) APPEND_NAMESPACE(BOOST_PP_SEQ_PUSH_BACK(namespaces, name))
