
#pragma once

#include "System/MakeStatic.h"


namespace system {

class RelationalOperatorsUtilities final {
 public:
  template <class T>
  static bool IsBinaryEqual(const T& lhs, const T& rhs);

 private:
  MAKE_STATIC(RelationalOperatorsUtilities);
};

}  // namespace system


#define SYSTEM_INCLUDE_RELATIONALOPERATORSUTILITIES_H_
#include "System/RelationalOperatorsUtilities-inl.h"
