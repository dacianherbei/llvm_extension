
#pragma once


namespace system {

template <typename TIn, typename TOut, typename TConverter>
struct TypeAdapter final {
  TypeAdapter(const TIn& _value) : value(_value) {}  // NOLINT(runtime/explicit)
  operator TOut() const { return TConverter()(value); }
  TIn value;
};

}  // namespace system

