
#pragma once

#include <cstring>
#include <sstream>
#include <stdexcept>
#include <string>

#include <boost/preprocessor.hpp>

#include "Logging/LoggingVerbosityHelper.h"
#include "CurrentFunctionMessage.h"
#include "PrintfMacros.h"


namespace system {

class Exception : public std::exception {
 public:
  explicit Exception(const std::string& message);
  explicit Exception(std::string&& message);
  Exception(const std::string& errorString, const char* file, int line);

  Exception(const Exception&) = default;
  Exception(Exception&& that);

  Exception& operator=(const Exception&) = default;
  Exception& operator=(Exception&& that);

  const char* what() const throw() override;
  const std::string& GetMessageString() const;

 protected:
  std::string message_;
};

}  // namespace system


#define _ERROR_MESSAGE_SIZE 1024

#define _CONSTRUCT_ERROR_MESSAGE_0(outMessage, size, format, ...) strncpy(outMessage, format, size - 1)
#define _CONSTRUCT_ERROR_MESSAGE_N(outMessage, size, format, ...) SNPRINTF(outMessage, size, format, __VA_ARGS__)

#define _CONSTRUCT_ERROR_MESSAGE(outMessage, size, ...)           \
  {                                                               \
    BOOST_PP_IIF(                                                 \
        BOOST_PP_GREATER(BOOST_PP_VARIADIC_SIZE(__VA_ARGS__), 1), \
        _CONSTRUCT_ERROR_MESSAGE_N,                               \
        _CONSTRUCT_ERROR_MESSAGE_0)                               \
    (outMessage, size, __VA_ARGS__);                              \
    outMessage[_ERROR_MESSAGE_SIZE - 1] = '\x0';            \
  }

#define _CONSTRUCT_STREAM_ERROR_MESSAGE(outMessage, size, message) \
  {                                                                \
    std::stringstream __stream;                                    \
    __stream << ::logging::Verbose << message;               \
    __stream.read(outMessage, size - 1);                           \
    outMessage[__stream.gcount()] = '\0';                          \
  }

#define _FORMAT_ERROR_MESSAGE(outputString, file, line, errorString) \
  {                                                                        \
    std::ostringstream _stringStream;                                      \
    _stringStream << file << ":" << line << ": " << errorString;           \
    outputString = _stringStream.str();                                    \
  }

#define _LOG_WITH_FILE_AND_LINE(logger, level, errorString)                         \
  {                                                                                       \
    std::string __formattedErrorString;                                                   \
    _FORMAT_ERROR_MESSAGE(__formattedErrorString, __FILE__, __LINE__, errorString); \
    _LOG(logger, level, __formattedErrorString.c_str());                            \
  }

#define _THROTTLE_LOG_WITH_FILE_AND_LINE(logger, level, errorString)                                 \
  {                                                                                                        \
    std::string __formattedErrorString;                                                                    \
    _FORMAT_ERROR_MESSAGE(__formattedErrorString, __FILE__, __LINE__, errorString);                  \
    _THROTTLE_LOG_WITH_TIME(logger, level, std::chrono::seconds(5), __formattedErrorString.c_str()); \
  }

#if __EXCEPTIONS == 1
#define _THROW_FMT(errorFormatString, ...)                                                                \
  {                                                                                                             \
    char __throwErrorMessage[_ERROR_MESSAGE_SIZE];                                                        \
    _CONSTRUCT_ERROR_MESSAGE(__throwErrorMessage, _ERROR_MESSAGE_SIZE, errorFormatString, ##__VA_ARGS__); \
    throw ::system::Exception(__throwErrorMessage, __FILE__, __LINE__);                             \
  }

#define _THROW(exception, message)                                 \
  {                                                                      \
    std::string __throwMessage;                                          \
    _CONSTRUCT_STREAM_CURRENT_FUNCTION_MESSAGE(__throwMessage, message); \
    throw exception(std::move(__throwMessage));                          \
  }

#define _THROW_WITH_NESTED(exception, message)                     \
  {                                                                      \
    std::string __throwMessage;                                          \
    _CONSTRUCT_STREAM_CURRENT_FUNCTION_MESSAGE(__throwMessage, message); \
    std::throw_with_nested(exception(std::move(__throwMessage)));        \
  }
#else
#define _THROW_FMT(errorString) \
  { ; }

#define _THROW(exception, message) \
  { ; }

#define _THROW_WITH_NESTED(exception, message) \
  { ; }
#endif  // __EXCEPTIONS
