
#pragma once

#include <type_traits>


namespace system {

template <typename Condition>
using EnableIf = typename std::enable_if<Condition::value, void>::type;

template <typename ConditionA, typename ConditionB>
using ConditionAnd =
    typename std::conditional<ConditionA::value && ConditionB::value, std::true_type, std::false_type>::type;

template <typename Condition>
using NotCondition = typename std::conditional<Condition::value, std::false_type, std::true_type>::type;

template <typename Iterator, typename IteratorTag>
using IsBaseOfIteratorCondition =
    typename std::is_base_of<IteratorTag, typename std::iterator_traits<Iterator>::iterator_category>;

template <typename T, template <typename...> class Template>
struct IsSpecialization : public std::false_type {};

template <template <typename...> class Template, typename... Args>
struct IsSpecialization<Template<Args...>, Template> : public std::true_type {};

template <typename T, typename... Rest>
struct AreAllTheSame : std::true_type {};

template <typename T, typename First>
struct AreAllTheSame<T, First> : std::is_same<T, First> {};

template <typename T, typename First, typename... Rest>
struct AreAllTheSame<T, First, Rest...>
    : std::integral_constant<bool, std::is_same<T, First>::value && AreAllTheSame<T, Rest...>::value> {};

}  // namespace system

