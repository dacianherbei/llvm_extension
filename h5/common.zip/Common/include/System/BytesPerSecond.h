
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/derived_dimension.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/physical_dimensions/time.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/reduce_unit.hpp>
#include <boost/units/systems/si/time.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"
#include "System/BitsPerSecond.h"
#include "System/ByteCount.h"


namespace system {

struct BytesPerSecondBaseUnit final
    : boost::units::base_unit<BytesPerSecondBaseUnit, BytesPerSecondDimension, __COUNTER__> {};

using BytesPerSecondSystem = boost::units::make_system<ByteCountBaseUnit, boost::units::si::second_base_unit>::type;

using BytesPerSecondUnit = boost::units::unit<BytesPerSecondDimension, BytesPerSecondSystem>;
using BytesPerSecond = boost::units::quantity<BytesPerSecondUnit, size_t>;

}  // namespace system


namespace boost {
namespace units {

inline std::string name_string(const reduce_unit<::system::BytesPerSecondUnit>::type&) {
  return "bytes per second";
}
inline std::string symbol_string(const reduce_unit<::system::BytesPerSecondUnit>::type&) { return "Bps"; }

}  // namespace units
}  // namespace boost
