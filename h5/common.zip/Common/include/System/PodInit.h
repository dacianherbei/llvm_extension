
#pragma once


namespace system {

template <class T>
inline void PodInit(T* t) {
  memset(t, 0, sizeof(*t));
}

}  // namespace system

