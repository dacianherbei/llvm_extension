
#pragma once

#define BOOST_ENABLE_ASSERT_DEBUG_HANDLER  // Enable custom assert handler

#include <cstdio>

#include <boost/assert.hpp>
#include <boost/lexical_cast.hpp>

#include "Logging/LoggerSingleton.h"
#include "System/MakeStatic.h"
#include "System/Exception.h"
#include "System/ScopeExit.h"


namespace system {

class DebugAssert final {
 public:
  static const char* const kAssertDisableEnvironmentVariableName;
  static const char* const kAssertThrottleLoggingDisableEnvironmentVariableName;

 public:
  static bool IsThrottleLoggingEnabled();
  static ScopeExit SetThrottleLoggingInScope(const bool value);
  static void SetThrottleLoggingGlobally(const bool value);
  static bool IsEnabled();
  static ScopeExit SetEnabledInScope(const bool value);
  static void SetEnabledGlobally(const bool value);

 private:
  static std::atomic<bool> throttleLogging_;
  static std::atomic<bool> throttleLoggingCurrentlyOverridden_;
  static std::atomic<bool> enabled_;
  static std::atomic<bool> assertEnablementCurrentlyOverridden_;

 private:
  static bool GetInitialEnabledValue();
  static bool GetInitialThrottleLoggingValue();
  MAKE_STATIC(DebugAssert);
};

}  // namespace system


#define _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(condition, format, ...)                       \
  do {                                                                                            \
    char __errorMessage[_ERROR_MESSAGE_SIZE];                                               \
    if (!(condition)) {                                                                           \
      _CONSTRUCT_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, format, ##__VA_ARGS__); \
                                                                                                  \
      if (::system::DebugAssert::IsThrottleLoggingEnabled()) {                                 \
        _THROTTLE_LOG_WITH_FILE_AND_LINE(                                                   \
            ::logging::LoggerSingleton::GetAssertionInstance(),                             \
            ::logging::LogLevel::kWarn,                                                     \
            __errorMessage);                                                                      \
      } else {                                                                                    \
        _LOG_WITH_FILE_AND_LINE(                                                            \
            ::logging::LoggerSingleton::GetAssertionInstance(),                             \
            ::logging::LogLevel::kWarn,                                                     \
            __errorMessage);                                                                      \
      }                                                                                           \
                                                                                                  \
      if (::system::DebugAssert::IsEnabled()) {                                       \
        BOOST_ASSERT_MSG(condition, __errorMessage);                                              \
      }                                                                                           \
    }                                                                                             \
  } while (false)

#define _INTERNAL__DEBUG_ASSERT_WITH_BOOL_OR_THROW_FMT(condition, format, ...)              \
  do {                                                                                            \
    char __errorMessage[_ERROR_MESSAGE_SIZE];                                               \
    if (!(condition)) {                                                                           \
      _CONSTRUCT_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, format, ##__VA_ARGS__); \
                                                                                                  \
      if (::system::DebugAssert::IsThrottleLoggingEnabled()) {                                 \
        _THROTTLE_LOG_WITH_FILE_AND_LINE(                                                   \
            ::logging::LoggerSingleton::GetAssertionInstance(),                             \
            ::logging::LogLevel::kWarn,                                                     \
            __errorMessage);                                                                      \
      } else {                                                                                    \
        _LOG_WITH_FILE_AND_LINE(                                                            \
            ::logging::LoggerSingleton::GetAssertionInstance(),                             \
            ::logging::LogLevel::kWarn,                                                     \
            __errorMessage);                                                                      \
      }                                                                                           \
                                                                                                  \
      if (::system::DebugAssert::IsEnabled()) {                                       \
        BOOST_ASSERT_MSG(condition, __errorMessage);                                              \
      }                                                                                           \
      _THROW_FMT(__errorMessage);                                                           \
    }                                                                                             \
  } while (false)

#define _DEBUG_ASSERT_FMT(expression, format, ...)                                  \
  do {                                                                                    \
    bool __conditionValue = !!(expression);                                               \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(__conditionValue, format, ##__VA_ARGS__); \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_FALSE_FMT(expression, format, ...)                  \
  do {                                                                                    \
    bool __conditionValue = !!(expression);                                               \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(__conditionValue, format, ##__VA_ARGS__); \
    if (!__conditionValue) {                                                              \
      return false;                                                                       \
    }                                                                                     \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_NONE_FMT(expression, format, ...)                   \
  do {                                                                                    \
    bool __conditionValue = !!(expression);                                               \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(__conditionValue, format, ##__VA_ARGS__); \
    if (!__conditionValue) {                                                              \
      return boost::none;                                                                 \
    }                                                                                     \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_FMT(expression, format, ...)                        \
  do {                                                                                    \
    bool __conditionValue = !!(expression);                                               \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_FMT(__conditionValue, format, ##__VA_ARGS__); \
    if (!__conditionValue) {                                                              \
      return;                                                                             \
    }                                                                                     \
  } while (false)

#define _DEBUG_ASSERT_OR_THROW_FMT(expression, format, ...)                                  \
  do {                                                                                             \
    bool __conditionValue = !!(expression);                                                        \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_OR_THROW_FMT(__conditionValue, format, ##__VA_ARGS__); \
  } while (false)

#define _INTERNAL__DEBUG_ASSERT_WITH_BOOL(condition, message)                        \
  do {                                                                                     \
    if (!(condition)) {                                                                    \
      char __errorMessage[_ERROR_MESSAGE_SIZE];                                      \
      _CONSTRUCT_STREAM_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, message); \
                                                                                           \
      if (::system::DebugAssert::IsThrottleLoggingEnabled()) {                          \
        _THROTTLE_LOG_WITH_FILE_AND_LINE(                                            \
            ::logging::LoggerSingleton::GetAssertionInstance(),                      \
            ::logging::LogLevel::kWarn,                                              \
            __errorMessage);                                                               \
      } else {                                                                             \
        _LOG_WITH_FILE_AND_LINE(                                                     \
            ::logging::LoggerSingleton::GetAssertionInstance(),                      \
            ::logging::LogLevel::kWarn,                                              \
            __errorMessage);                                                               \
      }                                                                                    \
                                                                                           \
      if (::system::DebugAssert::IsEnabled()) {                                \
        BOOST_ASSERT_MSG(condition, __errorMessage);                                       \
      }                                                                                    \
    }                                                                                      \
  } while (false)

#define _INTERNAL__DEBUG_ASSERT_WITH_BOOL_OR_THROW(condition, message)               \
  do {                                                                                     \
    if (!(condition)) {                                                                    \
      char __errorMessage[_ERROR_MESSAGE_SIZE];                                      \
      _CONSTRUCT_STREAM_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, message); \
                                                                                           \
      if (::system::DebugAssert::IsThrottleLoggingEnabled()) {                          \
        _THROTTLE_LOG_WITH_FILE_AND_LINE(                                            \
            ::logging::LoggerSingleton::GetAssertionInstance(),                      \
            ::logging::LogLevel::kWarn,                                              \
            __errorMessage);                                                               \
      } else {                                                                             \
        _LOG_WITH_FILE_AND_LINE(                                                     \
            ::logging::LoggerSingleton::GetAssertionInstance(),                      \
            ::logging::LogLevel::kWarn,                                              \
            __errorMessage);                                                               \
      }                                                                                    \
                                                                                           \
      if (::system::DebugAssert::IsEnabled()) {                                \
        BOOST_ASSERT_MSG(condition, __errorMessage);                                       \
      }                                                                                    \
      _THROW_FMT(__errorMessage);                                                    \
    }                                                                                      \
  } while (false)

#define _DEBUG_ASSERT(expression, message)                        \
  do {                                                                  \
    bool __conditionValue = !!(expression);                             \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL(__conditionValue, message); \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_FALSE(expression, message)        \
  do {                                                                  \
    bool __conditionValue = !!(expression);                             \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL(__conditionValue, message); \
    if (!__conditionValue) {                                            \
      return false;                                                     \
    }                                                                   \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_NONE(expression, message)         \
  do {                                                                  \
    bool __conditionValue = !!(expression);                             \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL(__conditionValue, message); \
    if (!__conditionValue) {                                            \
      return boost::none;                                               \
    }                                                                   \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN(expression, message)              \
  do {                                                                  \
    bool __conditionValue = !!(expression);                             \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL(__conditionValue, message); \
    if (!__conditionValue) {                                            \
      return;                                                           \
    }                                                                   \
  } while (false)

#define _DEBUG_ASSERT_OR_THROW(expression, message)                        \
  do {                                                                           \
    bool __conditionValue = !!(expression);                                      \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL_OR_THROW(__conditionValue, message); \
  } while (false)

#define _DEBUG_ASSERT_OR_RETURN_VALUE(expression, message, returnValue) \
  do {                                                                        \
    bool __conditionValue = !!(expression);                                   \
    _INTERNAL__DEBUG_ASSERT_WITH_BOOL(__conditionValue, message);       \
    if (!__conditionValue) {                                                  \
      return returnValue;                                                     \
    }                                                                         \
  } while (false)
