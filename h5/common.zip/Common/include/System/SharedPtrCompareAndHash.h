
#pragma once

#include <memory>


namespace system {

template <typename T>
struct SharedPointerEquals final {
  bool operator()(const std::shared_ptr<T>& v1, const std::shared_ptr<T>& v2) const {
    return v1.get() == v2.get() || (v1 && v2 && *v1 == *v2);
  }
};

template <typename T>
struct SharedPointerLess final {
  bool operator()(const std::shared_ptr<T>& v1, const std::shared_ptr<T>& v2) const {
    if (v1 && v2) {
      return *v1 < *v2;
    } else {
      return !v1 && v2;
    }
  }
};

template <typename T>
struct SharedPointerHash final {
  size_t operator()(const std::shared_ptr<T>& v) const { return v ? std::hash<T>()(*v) : 0; }
};

}  // namespace system

