
#pragma once

#define BOOST_ENABLE_ASSERT_DEBUG_HANDLER  // Enable custom assert handler

#include <cstdio>

#include <boost/assert.hpp>

#include "Logging/LoggerSingleton.h"
#include "System/Exception.h"
#include "System/TerminateHandlerUtilities.h"

#if defined(NDEBUG) && !defined(HAS_STACKTRACE_IN_TERMINATE_HANDLER)
// Boost will define an empty BOOST_ASSERT_MSG macro in this case.
// Since an exception will not produce a usable stack trace, we are directly calling our own assertion handling
// function, which will print the assertion and call abort, which will terminate the process.

namespace boost {
// We need to declare this function here, because boost will not when in release mode:
void assertion_failed_msg(
    char const* expr,
    char const* msg,
    char const* function,
    char const* file,
    long line);  // NOLINT(runtime/int)
}  // namespace boost

#define _INTERNAL_ASSERT_WITH_MESSAGE(expression, message) \
  ::boost::assertion_failed_msg(#expression, message, BOOST_CURRENT_FUNCTION, __FILE__, __LINE__)

#else
#define _INTERNAL_ASSERT_WITH_MESSAGE(expression, message) BOOST_ASSERT_MSG(expression, message)
#endif

#define _INTERNAL__ASSERT_FMT_WITH_BOOL(condition, format, ...)                                                  \
  {                                                                                                                    \
    char __errorMessage[_ERROR_MESSAGE_SIZE];                                                                    \
    if (!(condition)) {                                                                                                \
      _CONSTRUCT_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, format, ##__VA_ARGS__);                      \
                                                                                                                       \
      _LOG_WITH_FILE_AND_LINE(                                                                                   \
          ::logging::LoggerSingleton::GetAssertionInstance(), ::logging::LogLevel::kWarn, __errorMessage); \
      ::logging::Logger::Flush();                                                                                \
      _INTERNAL_ASSERT_WITH_MESSAGE(condition, __errorMessage);                                                        \
      _THROW_FMT(__errorMessage);                                                                                \
    }                                                                                                                  \
  }

#define _ASSERT_FMT(expression, format, ...)                                  \
  {                                                                                 \
    bool __conditionValue = !!(expression);                                         \
    _INTERNAL__ASSERT_FMT_WITH_BOOL(__conditionValue, format, ##__VA_ARGS__); \
  }

#define _INTERNAL__ASSERT_WITH_BOOL(condition, message)                              \
  {                                                                                        \
    if (!condition) {                                                                      \
      char __errorMessage[_ERROR_MESSAGE_SIZE];                                      \
      _CONSTRUCT_STREAM_ERROR_MESSAGE(__errorMessage, _ERROR_MESSAGE_SIZE, message); \
                                                                                           \
      _LOG_WITH_FILE_AND_LINE(                                                       \
          ::logging::LoggerSingleton::GetAssertionInstance(),                        \
          ::logging::LogLevel::kError,                                               \
          __errorMessage);                                                                 \
      ::logging::Logger::Flush();                                                    \
      _INTERNAL_ASSERT_WITH_MESSAGE(condition, __errorMessage);                            \
      _THROW_FMT(__errorMessage);                                                    \
    }                                                                                      \
  }

#define _ASSERT(expression, message)                        \
  {                                                               \
    bool __conditionValue = !!(expression);                       \
    _INTERNAL__ASSERT_WITH_BOOL(__conditionValue, message); \
  }
