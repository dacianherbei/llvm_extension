
#pragma once

#include <atomic>
#include <chrono>

#include "System/Noncopyable.h"


namespace system {

#if __GNUC__ == 4 && __GNUC_MINOR__ < 9
#define _NEED_CUSTOM_ATOMIC_TIME_POINT
#endif  // __GNUC__ == 4 && __GNUC_MINOR__ < 9

#if !defined(_NEED_CUSTOM_ATOMIC_TIME_POINT)

template <typename TClock, typename TDuration = typename TClock::duration>
using AtomicTimePoint = std::atomic<std::chrono::time_point<TClock, TDuration>>;

#else

// A wrapper which has the exact same interface as std::atomic<std::chrono::time_point<TClock, TDuration>>
template <typename TClock, typename TDuration = typename TClock::duration>
class AtomicTimePoint final {
 public:
  using TimePointType = std::chrono::time_point<TClock, TDuration>;

 public:
  AtomicTimePoint();
  // Want to be compatible with std::atomic as much as possible:
  AtomicTimePoint(TimePointType timePoint);  // NOLINT(runtime/explicit)

  AtomicTimePoint& operator=(TimePointType timePoint);
  AtomicTimePoint& operator=(TimePointType timePoint) volatile;

  bool is_lock_free() const;
  bool is_lock_free() const volatile;

  void store(TimePointType timePoint, std::memory_order order = std::memory_order_seq_cst);
  void store(TimePointType timePoint, std::memory_order order = std::memory_order_seq_cst) volatile;

  TimePointType load(std::memory_order order = std::memory_order_seq_cst) const;
  TimePointType load(std::memory_order order = std::memory_order_seq_cst) const volatile;

  operator TimePointType() const;
  operator TimePointType() const volatile;

  TimePointType exchange(TimePointType timePoint, std::memory_order order = std::memory_order_seq_cst);
  TimePointType exchange(TimePointType timePoint, std::memory_order order = std::memory_order_seq_cst) volatile;

  bool compare_exchange_weak(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order success,
      std::memory_order failure);
  bool compare_exchange_weak(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order success,
      std::memory_order failure) volatile;

  bool compare_exchange_weak(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order order = std::memory_order_seq_cst);
  bool compare_exchange_weak(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order order = std::memory_order_seq_cst) volatile;

  bool compare_exchange_strong(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order success,
      std::memory_order failure);
  bool compare_exchange_strong(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order success,
      std::memory_order failure) volatile;

  bool compare_exchange_strong(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order order = std::memory_order_seq_cst);
  bool compare_exchange_strong(
      TimePointType& expected,  // NOLINT(runtime/references)
      TimePointType desired,
      std::memory_order order = std::memory_order_seq_cst) volatile;

 private:
  using TickType = typename TClock::duration::rep;

 private:
  std::atomic<TickType> atomicTimePointInTicks_;

 private:
  static inline TickType ToTicks(TimePointType timePoint) { return timePoint.time_since_epoch().count(); }

  static inline TimePointType ToTimePoint(TickType ticks) {
    return TimePointType(typename TimePointType::duration(ticks));
  }

  DISALLOW_COPY_AND_ASSIGN(AtomicTimePoint);
};

#endif  // _NEED_CUSTOM_ATOMIC_TIME_POINT

}  // namespace system


#define COMMON_INCLUDE_SYSTEM_ATOMICTIMEPOINT_H_
#include "System/AtomicTimePoint-inl.h"
