
#pragma once

#include "System/NamespacePreprocessorHelper.h"

// NOTE(DP): Clang compiler obliges us to use in forwarding declaration the same keyword (class or struct)
//           as in the real declaration.

#define __FORWARD_DECLARE(namespaces, keyword, type) \
  BEGIN_NAMESPACE(namespaces)                              \
  keyword type;                                            \
  CLOSE_NAMESPACE(namespaces)

#define _FORWARD_DECLARE_CLASS(namespaces, type) __FORWARD_DECLARE(namespaces, class, type)

#define _FORWARD_DECLARE_STRUCT(namespaces, type) __FORWARD_DECLARE(namespaces, struct, type)
