
#pragma once

#include <cstdint>

#include "Boost/StrongTypedefUtilities.h"

_DEFINE_STRONG_TYPEDEF(()(system), KiloBitsPerSecond, uint64_t)
