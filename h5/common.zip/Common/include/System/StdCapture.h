
#pragma once

#include <fcntl.h>
#include <stdio.h>

#include <string>

#include "System/Noncopyable.h"
#include "System/Enum.h"
#include "Threading/Mutex.h"

DEFINE__ENUM(
    ()(system),
    StdCaptureMode,
    int,
    // stderr
    ((kStderr, 0x0001, "Stderr"))
    // stdout
    ((kStdout, 0x0002, "Stdout"))
    // stderr+stdout
    ((kBoth, 0x0003, "Both")))


namespace system {

class StdCapture final {
 public:
  StdCapture();
  explicit StdCapture(const StdCaptureMode& captureMode);
  ~StdCapture();

  void BeginCapture();
  bool IsCapturing();
  bool EndCapture();

  std::string GetCapture();

 private:
  enum PIPES { READ, WRITE };

 private:
  static std::atomic_flag anInstanceExists_;
  static const uint32_t kMaxIterations = 50;
  // TODO(AW) Consider making a separate static bool for capturingStdErr and capturingStdOut.
  static bool capturing_;

  const StdCaptureMode captureMode_;
  int pipe_[2];
  int oldStdOut_;
  int oldStdErr_;
  ::threading::Mutex mutex_;
  std::string captured_;

 private:
  void Init();
  int secure_dup(int src);
  void secure_pipe(int* pipes);
  void secure_dup2(int src, int dest);
  void secure_close(int* fd);
  void AcquireGlobalLock();
  void ReleaseGlobalLock();

  DISALLOW_COPY_AND_ASSIGN(StdCapture);
};

}  // namespace system

