
#pragma once

#include <atomic>

#include <boost/optional.hpp>

#include "System/Noncopyable.h"
#include "System/ForwardDeclare.h"

_FORWARD_DECLARE_CLASS(()(logging), Logger)


namespace system {

/**
 * Recommended pattern is to use private inheritance when using this class:
 *
 * class Example final : private system::EnsureSingleLiveInstance<Example>
 */
template <typename TSubclass>
class EnsureSingleLiveInstance {
 public:
  explicit EnsureSingleLiveInstance(const boost::optional<std::shared_ptr<logging::Logger>>& logger = boost::none);
  ~EnsureSingleLiveInstance();

 private:
  static std::atomic<int> instanceCount_;

 private:
  DISALLOW_COPY_AND_ASSIGN(EnsureSingleLiveInstance);
};

}  // namespace system


#include "System/EnsureSingleLiveInstance-inl.h"
