
#pragma once

#include <limits>
#include <type_traits>

#include "System/ExtractValueType.h"
#include "System/IsBoostUnitsQuantity.h"
#include "System/IsDuration.h"


namespace system {

template <typename T>
class NumericLimits final {
 public:
  static constexpr T Min() { return Min<T>(); }
  static constexpr T Lowest() { return Lowest<T>(); }
  static constexpr T Max() { return Max<T>(); }
  static constexpr int Digits() { return Digits<T>(); }
  static constexpr bool IsSigned() { return IsSigned<T>(); }

 private:
  template <typename U, typename ReturnType>
  using EnableIfHasNestedType =
      typename std::enable_if<!std::is_same<typename ExtractValueType<U>::type, U>::value, ReturnType>::type;

  template <typename U, typename ReturnType>
  using EnableIfIsDuration = typename std::
      enable_if<std::is_same<typename ExtractValueType<U>::type, U>::value && IsDuration<U>::value, ReturnType>::type;

  template <typename U, typename ReturnType>
  using EnableIfIsBoostUnitsQuanity = typename std::enable_if<
      std::is_same<typename ExtractValueType<U>::type, U>::value && IsBoostUnitsQuantity<U>::value,
      ReturnType>::type;

  template <typename U, typename ReturnType>
  using EnableIfSpecialized = typename std::enable_if<
      std::is_same<typename ExtractValueType<U>::type, U>::value && std::numeric_limits<U>::is_specialized,
      ReturnType>::type;

  template <typename U, typename ReturnType>
  using EnableIfNotSpecialized = typename std::enable_if<
      std::is_same<typename ExtractValueType<U>::type, U>::value &&
          (!std::numeric_limits<U>::is_specialized && !IsDuration<U>::value && !IsBoostUnitsQuantity<U>::value),
      ReturnType>::type;

  template <typename U>
  static constexpr EnableIfIsDuration<U, U> Min();

  template <typename U>
  static constexpr EnableIfIsBoostUnitsQuanity<U, U> Min();

  template <typename U>
  static constexpr EnableIfSpecialized<U, U> Min();

  template <typename U>
  static constexpr EnableIfNotSpecialized<U, U> Min();

  template <typename U>
  static constexpr EnableIfHasNestedType<U, U> Min();

  template <typename U>
  static constexpr EnableIfIsDuration<U, U> Lowest();

  template <typename U>
  static constexpr EnableIfIsBoostUnitsQuanity<U, U> Lowest();

  template <typename U>
  static constexpr EnableIfSpecialized<U, U> Lowest();

  template <typename U>
  static constexpr EnableIfNotSpecialized<U, U> Lowest();

  template <typename U>
  static constexpr EnableIfHasNestedType<U, U> Lowest();

  template <typename U>
  static constexpr EnableIfIsDuration<U, U> Max();

  template <typename U>
  static constexpr EnableIfIsBoostUnitsQuanity<U, U> Max();

  template <typename U>
  static constexpr EnableIfSpecialized<U, U> Max();

  template <typename U>
  static constexpr EnableIfNotSpecialized<U, U> Max();

  template <typename U>
  static constexpr EnableIfHasNestedType<U, U> Max();

  template <typename U>
  static constexpr EnableIfIsDuration<U, int> Digits();

  template <typename U>
  static constexpr EnableIfIsBoostUnitsQuanity<U, int> Digits();

  template <typename U>
  static constexpr EnableIfSpecialized<U, int> Digits();

  template <typename U>
  static constexpr EnableIfNotSpecialized<U, int> Digits();

  template <typename U>
  static constexpr EnableIfHasNestedType<U, int> Digits();

  template <typename U>
  static constexpr EnableIfIsDuration<U, bool> IsSigned();

  template <typename U>
  static constexpr EnableIfIsBoostUnitsQuanity<U, bool> IsSigned();

  template <typename U>
  static constexpr EnableIfSpecialized<U, bool> IsSigned();

  template <typename U>
  static constexpr EnableIfNotSpecialized<U, bool> IsSigned();

  template <typename U>
  static constexpr EnableIfHasNestedType<U, bool> IsSigned();
};

}  // namespace system


#include "System/NumericLimits-inl.h"
