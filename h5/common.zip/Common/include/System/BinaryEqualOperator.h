
#pragma once

#include "System/RelationalOperatorsUtilities.h"

// NOTE(DP): 1) It's only for simple structs
//           2) Don't use this if your struct has floating point type fields

#define _DEFINE_BINARY_EQUAL_OPERATOR_FOR(TypeName)                 \
  inline bool operator==(const TypeName& lhs, const TypeName& rhs) {      \
    return system::RelationalOperatorsUtilities::IsBinaryEqual(lhs, rhs); \
  }                                                                       \
                                                                          \
  inline bool operator!=(const TypeName& lhs, const TypeName& rhs) { return !(lhs == rhs); }
