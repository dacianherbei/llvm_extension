
#pragma once

// Needs to be included to define _LIBCPP_VERSION
// See: http://stackoverflow.com/questions/31657499/how-to-detect-stdlib-libc-in-the-preprocessor
#include <ciso646>

// See: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=55917
// The problem with the GNU stdlib is that if an uncaught exception is detected, the stack is unwound before
// the terminate handler gets called. This means that we cannot get a useful stack trace from the terminate handler.
// The only work around appears to be to use boost::thread instead of std::thread. Another option is to use
// libc++ instead of stdlibc++

#if defined(_LIBCPP_VERSION) || defined(_MSC_VER)
#define HAS_STACKTRACE_IN_TERMINATE_HANDLER 1
#endif  // defined(_LIBCPP_VERSION) || defined(_MSC_VER)
