
#pragma once

#include <boost/predef/other/endian.h>

#include "System/Uint24_t.h"
#include "System/Uint48_t.h"

#define _BIG_ENDIAN BOOST_ENDIAN_BIG_BYTE
#define _LITTLE_ENDIAN BOOST_ENDIAN_LITTLE_BYTE

#if _BIG_ENDIAN
#define _HTON64(x) x
#define _NTOH64(x) x
#define _HTON48(x) x
#define _NTOH48(x) x
#define _HTON32(x) x
#define _NTOH32(x) x
#define _HTON24(x) x
#define _NTOH24(x) x
#define _HTON16(x) x
#define _NTOH16(x) x
#define _HTON8(x) (x)
#define _NTOH8(x) (x)

#elif _LITTLE_ENDIAN
#define _HTON48(x) ::system::Uint48_t((x).AsHtonlUint64())
#define _NTOH48(x) ::system::Uint48_t((x).AsNtohlUint64())
#define _HTON24(x) ::system::Uint24_t((x).AsHtonlUint32())
#define _NTOH24(x) ::system::Uint24_t((x).AsNtohlUint32())
#include <boost/asio/ip/detail/socket_option.hpp>
#define _HTON32(x) boost::asio::detail::socket_ops::host_to_network_long(x)
#define _NTOH32(x) boost::asio::detail::socket_ops::network_to_host_long(x)
#define _HTON16(x) boost::asio::detail::socket_ops::host_to_network_short(x)
#define _NTOH16(x) boost::asio::detail::socket_ops::network_to_host_short(x)
#define _HTON8(x) (x)
#define _NTOH8(x) (x)
#define _HTON64(x) ((_HTON32((x)&0xffffffff) & 0xffffffffffffffff) << 32) ^ _HTON32((x) >> 32)
#define _NTOH64(x) ((_NTOH32((x)&0xffffffff) & 0xffffffffffffffff) << 32) ^ _NTOH32((x) >> 32)
#else
static_assert(false, "Endianness not supported")
#endif


namespace system {

template <typename IntegralType, size_t size>
struct EndiannessConversionSelector;

template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 1> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON8(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH8(value); }
};
template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 2> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON16(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH16(value); }
};
template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 3> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON24(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH24(value); }
};
template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 4> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON32(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH32(value); }
};
template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 6> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON48(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH48(value); }
};
template <typename IntegralType>
struct EndiannessConversionSelector<IntegralType, 8> final {
  static IntegralType HostToNetwork(IntegralType value) { return _HTON64(value); }
  static IntegralType NetworkToHost(IntegralType value) { return _NTOH64(value); }
};

template <typename IntegralType>
struct EndiannessConverter final {
  static IntegralType HostToNetwork(IntegralType value) {
    return EndiannessConversionSelector<IntegralType, sizeof(IntegralType)>::HostToNetwork(value);
  }
  static IntegralType NetworkToHost(IntegralType value) {
    return EndiannessConversionSelector<IntegralType, sizeof(IntegralType)>::NetworkToHost(value);
  }
};

}  // namespace system

