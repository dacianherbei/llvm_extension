
#pragma once

#include <ostream>
#include <utility>

namespace std {

template <typename T1, typename T2>
inline ostream& operator<<(ostream& stream, const pair<T1, T2>& pairToPrint) {
  stream << "(" << pairToPrint.first << "," << pairToPrint.second << ")";

  return stream;
}

}  // namespace std
