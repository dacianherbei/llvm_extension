
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/derived_dimension.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/physical_dimensions/time.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/reduce_unit.hpp>
#include <boost/units/systems/si/time.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"
#include "System/PacketCount.h"


namespace system {

using PacketsPerSecondDimension =
    boost::units::derived_dimension<PacketCountBaseDimension, 1, boost::units::time_base_dimension, -1>::type;

struct PacketsPerSecondBaseUnit final
    : boost::units::base_unit<PacketsPerSecondBaseUnit, PacketsPerSecondDimension, __COUNTER__> {};

using PacketsPerSecondSystem = boost::units::make_system<PacketCountBaseUnit, boost::units::si::second_base_unit>::type;

using PacketsPerSecondUnit = boost::units::unit<PacketsPerSecondDimension, PacketsPerSecondSystem>;
using PacketsPerSecond = boost::units::quantity<PacketsPerSecondUnit, size_t>;

}  // namespace system


namespace boost {
namespace units {

inline std::string name_string(const reduce_unit<::system::PacketsPerSecondUnit>::type&) {
  return "packets per second";
}
inline std::string symbol_string(const reduce_unit<::system::PacketsPerSecondUnit>::type&) { return "PPS"; }

}  // namespace units
}  // namespace boost
