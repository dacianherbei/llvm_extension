
#pragma once

#include <string>


namespace system {

void SetCrashInfo(
    const std::string& message,
    const std::string& signature,
    const std::string& backtrace,
    const std::string& message2);

}  // namespace system


#ifdef __APPLE__

extern const char* __crashreporter_info__;

#define CRASH_ALIGN __attribute__((aligned(8)))

typedef struct final {
  unsigned version CRASH_ALIGN;
  const char* message CRASH_ALIGN;
  const char* signature CRASH_ALIGN;
  const char* backtrace CRASH_ALIGN;
  const char* message2 CRASH_ALIGN;
  void* reserved CRASH_ALIGN;
  void* reserved2 CRASH_ALIGN;
} crashInfoT;

#endif
