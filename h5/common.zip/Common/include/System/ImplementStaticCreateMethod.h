
#pragma once

#include <memory>

#define IMPLEMENT_STATIC_CREATE_METHOD(ClassName) \
  template <typename... TArguments> \
  static std::shared_ptr<ClassName> Create(TArguments... arguments) { \
    return std::shared_ptr<ClassName>(new ClassName(arguments...)); \
  }
