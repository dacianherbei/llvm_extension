
#pragma once

// A macro to disallow the construction and destruction
#define MAKE_STATIC(TypeName) \
 public:                      \
  TypeName() = delete;        \
  ~TypeName() = delete
