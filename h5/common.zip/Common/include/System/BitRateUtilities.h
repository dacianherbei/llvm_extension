
#pragma once

#include "System/BitsPerSecond.h"
#include "System/KiloBitsPerSecond.h"
#include "System/MakeStatic.h"


namespace system {

class BitRateUtilities final {
 public:
  static BitsPerSecond ToBitsPerSecond(const KiloBitsPerSecond& kiloBitsPerSecondValue);
  static KiloBitsPerSecond ToKiloBitsPerSecond(const BitsPerSecond& bitsPerSecondValue);

 private:
  MAKE_STATIC(BitRateUtilities);
};

}  // namespace system

