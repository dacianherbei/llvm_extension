
#pragma once

#include <chrono>


namespace system {

template <typename T>
struct IsDuration final : std::false_type {};

template <typename R, typename P>
struct IsDuration<std::chrono::duration<R, P>> final : std::true_type {};

}  // namespace system

