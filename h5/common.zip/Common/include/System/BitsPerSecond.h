
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/derived_dimension.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/physical_dimensions/time.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/reduce_unit.hpp>
#include <boost/units/systems/si/time.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"
#include "System/BitCount.h"


namespace system {

using BytesPerSecondDimension =
    boost::units::derived_dimension<SizeBaseDimension, 1, boost::units::time_base_dimension, -1>::type;

struct BitsPerSecondBaseUnit final
    : boost::units::base_unit<BitsPerSecondBaseUnit, BytesPerSecondDimension, __COUNTER__> {};

using BitsPerSecondSystem = boost::units::make_system<BitCountBaseUnit, boost::units::si::second_base_unit>::type;

using BitsPerSecondUnit = boost::units::unit<BytesPerSecondDimension, BitsPerSecondSystem>;
using BitsPerSecond = boost::units::quantity<BitsPerSecondUnit, uint64_t>;

}  // namespace system


namespace boost {
namespace units {

inline std::string name_string(const reduce_unit<::system::BitsPerSecondUnit>::type&) {
  return "bits per second";
}
inline std::string symbol_string(const reduce_unit<::system::BitsPerSecondUnit>::type&) { return "bps"; }

}  // namespace units
}  // namespace boost
