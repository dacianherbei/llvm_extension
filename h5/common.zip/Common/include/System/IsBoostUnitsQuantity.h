
#pragma once

#include <boost/units/quantity.hpp>


namespace system {

template <typename T>
struct IsBoostUnitsQuantity final : std::false_type {};

template <class Unit, class Y>
struct IsBoostUnitsQuantity<boost::units::quantity<Unit, Y>> final : std::true_type {};

}  // namespace system

