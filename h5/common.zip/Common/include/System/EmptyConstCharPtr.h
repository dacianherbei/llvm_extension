
#pragma once


namespace system {

static const char* const kEmptyConstCharPtr = "";

}  // namespace system

