
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"


namespace system {

struct SizeBaseDimension final : boost::units::base_dimension<SizeBaseDimension, __COUNTER__> {};

#include BOOST_TYPEOF_INCREMENT_REGISTRATION_GROUP()

BOOST_TYPEOF_REGISTER_TYPE(SizeBaseDimension)

using SizeDimension = SizeBaseDimension::dimension_type;

struct BitCountBaseUnit final : boost::units::base_unit<BitCountBaseUnit, SizeDimension, __COUNTER__> {
  static std::string name() { return ("bit count"); }
  static std::string symbol() { return ("b"); }
};

using BitCountSystem = boost::units::make_system<BitCountBaseUnit>::type;

using BitCountUnit = boost::units::unit<SizeDimension, BitCountSystem>;
using BitCount = boost::units::quantity<BitCountUnit, size_t>;

}  // namespace system

