
#pragma once

#include "System/Assert.h"

#define _FAIL(message) \
  do { _INTERNAL__ASSERT_WITH_BOOL(false, message); } while (false)
