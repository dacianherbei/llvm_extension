
#pragma once

#include <functional>

#include "System/Noncopyable.h"


namespace system {

class ScopeExit final {
 public:
  using FunctionOnExit = std::function<void(void)>;

 public:
  explicit ScopeExit(FunctionOnExit&& functionOnExit);
  ScopeExit(ScopeExit&& source);
  ~ScopeExit();

  void Dismiss();

 private:
  FunctionOnExit functionOnExit_;
  bool dismissed_;

 private:
  DISALLOW_COPY_AND_ASSIGN(ScopeExit);
};

}  // namespace system

