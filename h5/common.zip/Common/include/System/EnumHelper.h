
#pragma once

#include <boost/optional.hpp>

#include "System/MakeStatic.h"


namespace system {

class EnumHelper final {
 public:
  template <class DestinationType, class SourceType>
  static boost::optional<DestinationType> TryCastTo(const SourceType value);

 private:
  MAKE_STATIC(EnumHelper);
};

}  // namespace system


#define SYSTEM_INCLUDE_ENUMHELPER_H_
#include "System/EnumHelper-inl.h"
