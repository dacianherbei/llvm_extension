
#pragma once

#include <cstdint>

#include <boost/lexical_cast.hpp>
#include <boost/optional.hpp>


namespace system {

template <typename Target, typename Source>
inline boost::optional<Target> NumericCast(const Source& arg) {
  Target result;
  if (!boost::detail::noexcept_numeric_convert<Target>(arg, result)) {
    return boost::none;
  }

  return result;
}

}  // namespace system

