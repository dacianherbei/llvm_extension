
#pragma once

#include <cstdint>

#include <boost/units/base_dimension.hpp>
#include <boost/units/base_unit.hpp>
#include <boost/units/io.hpp>
#include <boost/units/make_system.hpp>
#include <boost/units/quantity.hpp>
#include <boost/units/unit.hpp>

#include "Boost/UnitsUtilities.h"
#include "System/BitCount.h"


namespace system {

struct ByteCountBaseUnit final : boost::units::base_unit<ByteCountBaseUnit, SizeDimension, __COUNTER__> {
  static std::string name() { return ("byte count"); }
  static std::string symbol() { return ("B"); }
};

using ByteCountSystem = boost::units::make_system<ByteCountBaseUnit>::type;

using ByteCountUnit = boost::units::unit<SizeDimension, ByteCountSystem>;
using ByteCount = boost::units::quantity<ByteCountUnit, size_t>;
BOOST_UNITS_STATIC_CONSTANT(Bytes, ByteCountUnit);

}  // namespace system


BOOST_UNITS_DEFINE_CONVERSION_FACTOR(::system::ByteCountBaseUnit, ::system::BitCountBaseUnit, double, 8);
