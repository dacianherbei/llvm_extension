
#pragma once

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include "Container/ThreadsafeLookupTable.h"
#include "Exceptions/IStackTraceProvider.h"
#include "System/Assert.h"


namespace system {

template <class TValueType>
class enable_shared_from_this_with_tracking;

template <typename TValueType>
class TrackingSharedPtr;

template <class TValueType, class TSharedFromThisType>
void _Do_enable(TrackingSharedPtr<TValueType>*, enable_shared_from_this_with_tracking<TSharedFromThisType>*);

template <class TValueType>
inline void _Enable_tracking_shared(
    TrackingSharedPtr<TValueType>* trackingSharedPointer,
    TValueType* pointer,
    typename TValueType::EnableSharedFromThisWithTrackingType* = 0) {  // reset internal weak pointer
  if (pointer) {
    _Do_enable(
        trackingSharedPointer,
        (enable_shared_from_this_with_tracking<typename TValueType::EnableSharedFromThisWithTrackingType>*)pointer);
  }
}

inline void _Enable_tracking_shared(const volatile void*, const volatile void*) {
  // not derived from enable_shared_from_this; do nothing
}

/*
  This class is meant to be used to track usages of shared pointers, and should not be used in production!
  To use this class:

  1.  Replace:
      a. shared_ptr<OBJECT> with system::TrackingSharedPtr<OBJECT>
      b. AtomicSharedPtr<OBJECT> with AtomicSharedPtr<OBJECT, system::TrackingSharedPtr>
      c. ITransparentDecorator<OBJECT> with ITransparentDecorator<OBJECT, system::TrackingSharedPtr>
      d. std::dynamic_pointer_cast<OBJECT> with system::dynamic_pointer_cast<OBJECT>
  2.  Replace enable_shared_from_this and shared_from_this() on OBJECT with system::enable_shared_from_this_with_tracking
      and shared_from_this_with_tracking()
  3.  Use GetStackTraceMap() to get a map from shared pointer instance to stack trace where that object got created

  NOTE:
    i.  Anytime a TrackingSharedPtr is new'ed up, be sure to do so within the context of a TrackingSharedPtr. It isn't
          always sufficient enough to new one up as a shared_ptr and then return it as a TrackingSharedPtr. This is
          especially true if you new up a pointer of a derived class and return a pointer to its base class.
    ii. weak_ptr's aren't truly fully supported with this code. An estimate works if enable_shared_from_this is
          inherited from. You can use the "LockWeakPointer" method to approximate the functionality.
*/
template <typename TValueType>
class TrackingSharedPtr {
  template <typename>
  friend class TrackingSharedPtr;

 public:
  using StackTraceByInstanceType = container::ThreadsafeLookupTable<void*, std::string>;

  TrackingSharedPtr();
  TrackingSharedPtr(std::nullptr_t);  // NOLINT(runtime/explicit)
  explicit TrackingSharedPtr(const TrackingSharedPtr& other);

  template <typename TOtherValueType>
  TrackingSharedPtr(
      const TrackingSharedPtr<TOtherValueType>& other,
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  TrackingSharedPtr(
      const std::shared_ptr<TValueType>& p,
      const std::shared_ptr<StackTraceByInstanceType>& stackTraceByInstance =
          std::make_shared<StackTraceByInstanceType>());

  template <typename TOtherValueType>
  explicit TrackingSharedPtr(
      const std::shared_ptr<TOtherValueType>& p,
      const std::shared_ptr<StackTraceByInstanceType>& stackTraceByInstance =
          std::make_shared<StackTraceByInstanceType>(),
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  template <typename TOtherValueType>
  explicit TrackingSharedPtr(
      std::shared_ptr<TOtherValueType>&& p,
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  template <typename TOtherValueType>
  explicit TrackingSharedPtr(
      std::unique_ptr<TOtherValueType>&& p,
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  template <typename TOtherValueType>
  explicit TrackingSharedPtr(
      TOtherValueType* p,
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  template <typename TOtherValueType, typename TDeleterType>
  explicit TrackingSharedPtr(
      TOtherValueType* p,
      TDeleterType d,
      typename std::enable_if<std::is_convertible<TOtherValueType*, TValueType*>::value, void*>::type = 0);

  template <typename TOtherValueType>
  TrackingSharedPtr(TrackingSharedPtr<TOtherValueType> const& own, TValueType* p);

  ~TrackingSharedPtr();

  TrackingSharedPtr<TValueType> operator=(const TrackingSharedPtr<TValueType>& other);
  TrackingSharedPtr<TValueType> operator=(TrackingSharedPtr<TValueType>&& other);
  TrackingSharedPtr<TValueType> operator=(std::nullptr_t);

  template <typename TInternalValueType = TValueType, typename TOtherValueType>
  typename std::enable_if<
      std::is_convertible<TOtherValueType*, TInternalValueType*>::value,
      TrackingSharedPtr<TInternalValueType>&>::type
  operator=(const TrackingSharedPtr<TOtherValueType>& other);

  template <typename TInternalValueType = TValueType, typename TOtherValueType>
  typename std::enable_if<
      std::is_convertible<TOtherValueType*, TInternalValueType*>::value,
      TrackingSharedPtr<TInternalValueType>&>::type
  operator=(TrackingSharedPtr<TOtherValueType>&& other);

  void reset();

  TValueType& operator*() const;
  TValueType* operator->() const;
  explicit operator bool() const;
  TValueType* get() const;
  bool unique() const;
  long use_count() const;  // NOLINT(runtime/int)
  void swap(TrackingSharedPtr& other);

  operator std::shared_ptr<TValueType>() const;
  operator std::weak_ptr<TValueType>() const;

  template <
      typename TOtherValueType,
      typename std::enable_if<std::is_convertible<TValueType*, TOtherValueType*>::value, void>::type>
  operator std::shared_ptr<TOtherValueType>() const;

  template <
      typename TOtherValueType,
      typename std::enable_if<std::is_convertible<TValueType*, TOtherValueType*>::value>::type>
  operator std::weak_ptr<TOtherValueType>() const;

  template <class TOtherValueType>
  bool owner_before(const TrackingSharedPtr& ptr) const;

  template <class TOtherValueType>
  bool owner_before(const std::shared_ptr<TOtherValueType>& ptr) const;

  template <class TDeleterType, class TOtherValueType>
  TDeleterType* get_deleter(TrackingSharedPtr<TOtherValueType> const& ptr) const;

  std::map<void*, std::string> GetStackTraceMap() const;
  std::shared_ptr<TValueType> GetSharedPointer() const;

 private:
  static const std::shared_ptr<exceptions::IStackTraceProvider> stackTraceProvider_;
  std::shared_ptr<StackTraceByInstanceType> stackTraceByInstance_;
  std::shared_ptr<TValueType> pointer_;

  template <class TInternalValueType, class TSharedFromThisType>
  friend void _Do_enable(
      TrackingSharedPtr<TInternalValueType>*, enable_shared_from_this_with_tracking<TSharedFromThisType>*);

  template <class TReturnValueType, class TInternalValueType>
  friend TrackingSharedPtr<TReturnValueType> static_pointer_cast(const TrackingSharedPtr<TInternalValueType>& p);

  template <class TReturnValueType, class TInternalValueType>
  friend TrackingSharedPtr<TReturnValueType> const_pointer_cast(const TrackingSharedPtr<TInternalValueType>& p);

  template <class TReturnValueType, class TInternalValueType>
  friend TrackingSharedPtr<TReturnValueType> dynamic_pointer_cast(const TrackingSharedPtr<TInternalValueType>& p);
};

template <class TValueType>
bool operator!(const TrackingSharedPtr<TValueType>& a) {
  return a == nullptr;
}

template <class TValueType, class TOtherValueType>
bool operator==(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() == b.get();
}

template <class TValueType, class TOtherValueType>
bool operator==(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() == b.get();
}

template <class TValueType, class TOtherValueType>
bool operator==(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() == b.get();
}

template <class TValueType>
bool operator==(std::nullptr_t, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) == b.get();
}

template <class TValueType>
bool operator==(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() == reinterpret_cast<TValueType*>(0);
}

template <class TValueType, class TOtherValueType>
bool operator!=(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() != b.get();
}

template <class TValueType, class TOtherValueType>
bool operator!=(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() != b.get();
}

template <class TValueType, class TOtherValueType>
bool operator!=(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() != b.get();
}

template <class TValueType>
bool operator!=(std::nullptr_t a, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) != b.get();
}

template <class TValueType>
bool operator!=(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() != reinterpret_cast<TValueType*>(0);
}

template <class TValueType, class TOtherValueType>
bool operator<(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() < b.get();
}

template <class TValueType, class TOtherValueType>
bool operator<(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() < b.get();
}

template <class TValueType, class TOtherValueType>
bool operator<(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() < b.get();
}

template <class TValueType>
bool operator<(std::nullptr_t, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) < b.get();
}

template <class TValueType>
bool operator<(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() < reinterpret_cast<TValueType*>(0);
}

template <class TValueType, class TOtherValueType>
bool operator>(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() > b.get();
}

template <class TValueType, class TOtherValueType>
bool operator>(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() > b.get();
}

template <class TValueType, class TOtherValueType>
bool operator>(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() > b.get();
}

template <class TValueType>
bool operator>(std::nullptr_t, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) > b.get();
}

template <class TValueType>
bool operator>(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() > reinterpret_cast<TValueType*>(0);
}

template <class TValueType, class TOtherValueType>
bool operator>=(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() >= b.get();
}

template <class TValueType, class TOtherValueType>
bool operator>=(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() >= b.get();
}

template <class TValueType, class TOtherValueType>
bool operator>=(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() >= b.get();
}

template <class TValueType>
bool operator>=(std::nullptr_t, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) >= b.get();
}

template <class TValueType>
bool operator>=(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() >= reinterpret_cast<TValueType*>(0);
}

template <class TValueType, class TOtherValueType>
bool operator<=(const TrackingSharedPtr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() <= b.get();
}

template <class TValueType, class TOtherValueType>
bool operator<=(const std::shared_ptr<TValueType>& a, const TrackingSharedPtr<TOtherValueType>& b) {
  return a.get() <= b.get();
}

template <class TValueType, class TOtherValueType>
bool operator<=(const TrackingSharedPtr<TValueType>& a, const std::shared_ptr<TOtherValueType>& b) {
  return a.get() <= b.get();
}

template <class TValueType>
bool operator<=(std::nullptr_t, const TrackingSharedPtr<TValueType>& b) {
  return reinterpret_cast<TValueType*>(0) <= b.get();
}

template <class TValueType>
bool operator<=(const TrackingSharedPtr<TValueType>& a, std::nullptr_t) {
  return a.get() <= reinterpret_cast<TValueType*>(0);
}

template <class E, class TValueType, class TOtherValueType>
std::basic_ostream<E, TValueType>& operator<<(
    std::basic_ostream<E, TValueType>& out, const TrackingSharedPtr<TOtherValueType>& p) {
  return out << p.get();
}

template <class TValueType>
void swap(TrackingSharedPtr<TValueType>& a, TrackingSharedPtr<TValueType>& b) {
  a.swap(b);
}

template <class TValueType>
TValueType* get_pointer(TrackingSharedPtr<TValueType> const& p) {
  return p.get();
}

template <class TValueType>
inline std::size_t hash_value(TrackingSharedPtr<TValueType> const& p) {
  std::size_t seed = 0;
  boost::hash_combine(seed, p.get());
  return seed;
}

template <class TValueType, class TOtherValueType>
TrackingSharedPtr<TValueType> static_pointer_cast(const TrackingSharedPtr<TOtherValueType>& p) {
  return TrackingSharedPtr<TValueType>(
      std::static_pointer_cast<TValueType>(std::shared_ptr<TOtherValueType>(p)), p.stackTraceByInstance_);
}

template <class TValueType, class TOtherValueType>
TrackingSharedPtr<TValueType> const_pointer_cast(const TrackingSharedPtr<TOtherValueType>& p) {
  return TrackingSharedPtr<TValueType>(
      std::const_pointer_cast<TValueType>(std::shared_ptr<TOtherValueType>(p)), p.stackTraceByInstance_);
}

template <class TValueType, class TOtherValueType>
TrackingSharedPtr<TValueType> dynamic_pointer_cast(const TrackingSharedPtr<TOtherValueType>& p) {
  auto castSharedPointer = std::dynamic_pointer_cast<TValueType>(p.GetSharedPointer());
  if (castSharedPointer) {
    return TrackingSharedPtr<TValueType>(castSharedPointer, p.stackTraceByInstance_);
  } else {
    return nullptr;
  }
}

//
// enable_shared_from_this_with_tracking
//
// A TrackingSharedPtr version of enable_shared_from_this.
// So that an object may get TrackingSharedPtr objects to itself.
//

template <class TValueType>
class enable_shared_from_this_with_tracking {
 public:
  using EnableSharedFromThisWithTrackingType = TValueType;

  TrackingSharedPtr<TValueType> shared_from_this_with_tracking() {
    auto lockedPointer = weakPointer_.lock();
    auto lockedLookupTable = weakLookupTable_.lock();

    _ASSERT(
        lockedPointer && lockedLookupTable,
        "weakPointer_ or weakLookupTable_ is expired. This is most likely a sign that not all instances of this class "
        "were created with a TrackingSharedPtr");
    return TrackingSharedPtr<TValueType>(lockedPointer, lockedLookupTable);
  }

  TrackingSharedPtr<TValueType const> shared_from_this_with_tracking() const {
    auto lockedPointer = weakPointer_.lock();
    auto lockedLookupTable = weakLookupTable_.lock();

    _ASSERT(
        lockedPointer && lockedLookupTable,
        "weakPointer_ or weakLookupTable_ is expired. This is most likely a sign that not all instances of this class "
        "were created with a TrackingSharedPtr");

    return TrackingSharedPtr<TValueType const>(lockedPointer, lockedLookupTable);
  }

  TrackingSharedPtr<TValueType> try_shared_from_this_with_tracking() {
    auto lockedPointer = weakPointer_.lock();
    auto lockedLookupTable = weakLookupTable_.lock();

    if (!lockedPointer || !lockedLookupTable) {
      return nullptr;
    }

    return TrackingSharedPtr<TValueType>(lockedPointer, lockedLookupTable);
  }

  TrackingSharedPtr<TValueType> LockWeakPointer(const std::weak_ptr<TValueType>& weakPointer) {
    auto lockedPointer = weakPointer.lock();
    return lockedPointer->try_shared_from_this_with_tracking();
  }

 protected:
  enable_shared_from_this_with_tracking() {}

  enable_shared_from_this_with_tracking(const enable_shared_from_this_with_tracking& other) {}

  enable_shared_from_this_with_tracking& operator=(const enable_shared_from_this_with_tracking& other) { return *this; }

  ~enable_shared_from_this_with_tracking() {}

  template <class TInternalValueType, class TSharedFromThisType>
  friend void _Do_enable(
      TrackingSharedPtr<TInternalValueType>*, enable_shared_from_this_with_tracking<TSharedFromThisType>*);

  std::weak_ptr<TValueType> weakPointer_;
  std::weak_ptr<typename TrackingSharedPtr<TValueType>::StackTraceByInstanceType> weakLookupTable_;
};

template <class TValueType, class TSharedFromThisType>
void _Do_enable(
    TrackingSharedPtr<TValueType>* pointer,
    enable_shared_from_this_with_tracking<TSharedFromThisType>* sharedFromThisPointer) {
  sharedFromThisPointer->weakPointer_ =
      std::weak_ptr<TSharedFromThisType>(const_pointer_cast<TSharedFromThisType>(pointer->pointer_));
  sharedFromThisPointer->weakLookupTable_ = pointer->stackTraceByInstance_;
}

}  // namespace system


namespace std {
template <typename TValueType>
struct hash<::system::TrackingSharedPtr<TValueType>> {
  size_t operator()(const ::system::TrackingSharedPtr<TValueType>& p) const {
    return ::system::hash_value(p);
  }
};

}  // namespace std

#define COMMON_INCLUDE_SYSTEM_TRACKINGSHAREDPTR_H_
#include "System/TrackingSharedPtr-inl.h"
