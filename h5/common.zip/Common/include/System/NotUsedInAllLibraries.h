
#pragma once

#if (__GNUC__ > 2) || (__GNUC__ == 2 && __GNUC_MINOR__ > 4)
#define NOT_USED_IN_ALL_LIBRARIES __attribute__((__unused__))
#else
#define NOT_USED_IN_ALL_LIBRARIES
#endif
