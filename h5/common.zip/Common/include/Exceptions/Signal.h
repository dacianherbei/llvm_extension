
#pragma once

#if defined(_MSC_VER)

#include <windows.h>

#include "Boost/Asio.h"

#else

#include <signal.h>

#endif  // defined(_MSC_VER)


namespace exceptions {

struct Signal final {
#if !defined(_MSC_VER)
  siginfo_t* info;
  void* context;
#endif
};

}  // namespace exceptions

