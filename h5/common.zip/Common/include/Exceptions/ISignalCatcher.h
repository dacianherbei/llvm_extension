
#pragma once

#include <functional>
#include <string>

#include "Exceptions/IExceptionPrinter.h"
#include "Exceptions/IStackTraceProvider.h"
#include "Exceptions/SignalType.h"
#include "Logging/Logger.h"
#include "System/Noncopyable.h"
#include "Threading/Thread.h"


namespace exceptions {

class ISignalCatcher {
 public:
  using AfterSignalHandler =
      std::function<void(const SignalType& /* signalType */, const std::string& /* signalMessage */)>;
  using Main = std::function<void()>;

 public:
  ISignalCatcher() {}
  virtual ~ISignalCatcher() {}

  virtual void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) = 0;
  virtual void Destroy() = 0;
  virtual void SetFunctionToBeCalledAfterSignalIsHandled(const AfterSignalHandler& function) = 0;
  virtual bool TestSignalCalledFlag(int64_t* signalCode) const = 0;
  virtual void RunAndEnableThreadSpecificSignals(const Main& function) = 0;
  virtual void TriggerStackDumpOnThread(const threading::Thread& thread) const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(ISignalCatcher);
};

}  // namespace exceptions

