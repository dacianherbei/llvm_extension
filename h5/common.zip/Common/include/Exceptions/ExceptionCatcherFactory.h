#pragma once

#include <functional>
#include <memory>

#include "Exceptions/IExceptionCatcher.h"
#include "Exceptions/IExceptionPrinter.h"
#include "Exceptions/IStackTraceProvider.h"
#include "Logging/Logger.h"
#include "System/Noncopyable.h"

namespace exceptions {

class ExceptionCatcherFactory final {
 public:
  explicit ExceptionCatcherFactory(const std::shared_ptr<logging::Logger>& logger);
  ~ExceptionCatcherFactory();

  std::shared_ptr<IExceptionCatcher> CreateExceptionCatcher() const;
  std::shared_ptr<IExceptionPrinter> CreateExceptionPrinter() const;
  std::shared_ptr<IStackTraceProvider> CreateStackTraceProvider() const;

 private:
  const std::shared_ptr<logging::Logger> logger_;
  const std::shared_ptr<IStackTraceProvider> stackTraceProvider_;
  const std::shared_ptr<IExceptionPrinter> exceptionPrinter_;

 private:
  DISALLOW_COPY_AND_ASSIGN(ExceptionCatcherFactory);
};

}  // namespace exceptions
