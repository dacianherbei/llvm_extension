
#pragma once

#include <memory>

#include "Exceptions/ISignalCatcher.h"
#include "System/Noncopyable.h"


namespace exceptions {

class SignalCatcherFactory final {
 public:
  SignalCatcherFactory();
  ~SignalCatcherFactory();

  std::shared_ptr<ISignalCatcher> CreateSignalCatcher() const;

 private:
  DISALLOW_COPY_AND_ASSIGN(SignalCatcherFactory);
};

}  // namespace exceptions

