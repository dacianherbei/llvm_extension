
#pragma once

#include <windows.h>


namespace exceptions {

typedef void(__cdecl* _PMFN)(void);  // despite the static typing, function pointers of
//   type _PMFN are usually used as pointers to other
//   function types

#pragma warning(disable : 4200)
#pragma pack(push, _TypeDescriptor, 8)
typedef struct _TypeDescriptor final {
  const void* pVFTable;
  void* spare;
  char name[];
} _TypeDescriptor;
#pragma pack(pop, _TypeDescriptor)
#pragma warning(default : 4200)

struct _PMD final {
  int mdisp;  // member offset
  int pdisp;  // offset of the vtable
  int vdisp;  // offset to displacment inside the vtable
};

struct _s__CatchableType final {
  unsigned int properties;  // bit 1: is a simple type
  //   bit 2: can be caught by reference only
  //   bit 3: has virtual base
  _TypeDescriptor* pType;  // pointer to std::type_info object.
  _PMD thisDisplacement;   // displacement of the object for this type
  int sizeOrOffset;        // size of the type
  _PMFN copyFunction;      // pointer to copy constructor or 0
};
typedef const _s__CatchableType _CatchableType;

#pragma warning(disable : 4200)
struct _s__CatchableTypeArray final {
  int nCatchableTypes;                      // number of entries in arrayOfCatchableTypes
  _CatchableType* arrayOfCatchableTypes[];  // array of pointers to all base types of the object
                                            //   including types that it can be implicitly cast to
};
#pragma warning(default : 4200)

typedef const _s__CatchableTypeArray _CatchableTypeArray;

struct _s__ThrowInfo final {
  unsigned int attributes;                   // bit 1 for const, bit 2 for volatile
  _PMFN pmfnUnwind;                          // function to destroy the exception object
  int(__cdecl* pForwardCompat)(...);         // NOLINT(readability/casting)
  _CatchableTypeArray* pCatchableTypeArray;  // pointer to array of pointers to type information
};
typedef const _s__ThrowInfo _ThrowInfo;

struct UntypedException final {
  explicit UntypedException(const EXCEPTION_RECORD& er)
      : exception_object(reinterpret_cast<void*>(er.ExceptionInformation[1])),
        type_array(reinterpret_cast<_ThrowInfo*>(er.ExceptionInformation[2])->pCatchableTypeArray) {}
  void* exception_object;
  _CatchableTypeArray* type_array;
};

}  // namespace exceptions

