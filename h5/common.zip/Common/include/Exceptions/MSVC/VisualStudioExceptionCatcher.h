
#pragma once

#include <functional>
#include <memory>
#include <string>

#include <windows.h>

#include "Boost/Asio.h"
#include "Exceptions/IExceptionCatcher.h"
#include "Exceptions/MSVC/VisualStudioExceptionPrinter.h"
#include "Exceptions/MSVC/VisualStudioExceptionTypes.h"
#include "Exceptions/MSVC/VisualStudioStackTraceProvider.h"
#include "Logging/Logger.h"
#include "System/Noncopyable.h"
#include "Threading/SafeStartStop.h"


namespace exceptions {

class VisualStudioExceptionCatcher final : public IExceptionCatcher {
 public:
  static std::shared_ptr<VisualStudioExceptionCatcher> GetInstance();

  // IExceptionCatcher
  void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) override;
  void Destroy() override;
  void RunAndLogExceptionAndStackTraceOnException(Main&& function) override;
  void SetFunctionToBeCalledAfterExceptionIsHandled(const AfterExceptionHandler& function) override;

 private:
  std::shared_ptr<VisualStudioStackTraceProvider> stackTraceProvider_;
  std::shared_ptr<VisualStudioExceptionPrinter> exceptionPrinter_;
  std::shared_ptr<logging::Logger> logger_;
  AfterExceptionHandler functionToBeCalledAfterExceptionIsHandled_;
  threading::SafeStartStop safeStartStop_;
  LPTOP_LEVEL_EXCEPTION_FILTER originalUnhandledExceptionHandler_;
  PVOID vectoredExceptionHandler_;

 private:
  DWORD ExceptionFilter(EXCEPTION_POINTERS* exceptionPointers, DWORD exceptionCode);
  void HandleException(EXCEPTION_POINTERS* exceptionPointers);

  VisualStudioExceptionCatcher();
  DISALLOW_COPY_AND_ASSIGN(VisualStudioExceptionCatcher);
};

}  // namespace exceptions

