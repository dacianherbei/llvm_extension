
#pragma once

#include <string>

#include <windows.h>

#include "Boost/Asio.h"
#include "Exceptions/IExceptionPrinter.h"
#include "Exceptions/MSVC/VisualStudioExceptionTypes.h"
#include "System/Noncopyable.h"


namespace exceptions {

class VisualStudioExceptionPrinter final : public IExceptionPrinter {
 public:
  VisualStudioExceptionPrinter();
  ~VisualStudioExceptionPrinter();

  std::string GetExceptionAsString(const EXCEPTION_RECORD& exceptionRecord) const;

 private:
  DISALLOW_COPY_AND_ASSIGN(VisualStudioExceptionPrinter);
};

}  // namespace exceptions

