
#pragma once

#include <StackWalker.h>
#include <mutex>
#include <sstream>

#include "Boost/Asio.h"
#include "Container/ThreadsafeLookupTable.h"
#include "Exceptions/IStackTraceProvider.h"
#include "System/Noncopyable.h"
#include "Threading/Mutex.h"
#include "Threading/ThreadType.h"


namespace exceptions {

class VisualStudioStackTraceProvider final : public IStackTraceProvider {
 public:
  VisualStudioStackTraceProvider();
  ~VisualStudioStackTraceProvider() override;

  std::string GetStackTrace() const override;
  std::string GetStackTraceAfterSignal(const Signal& signalInfo) const override;
  std::string GetStackTrace(PCONTEXT pExp) const;

 private:
  class StackTraceCollector final : public StackWalker {
   public:
    StackTraceCollector();
    ~StackTraceCollector() override;
    std::string GetStackTrace() const;

   protected:
    void OnOutput(LPCSTR szText) override;

   private:
    std::stringstream stackTraceStream_;

   private:
    DISALLOW_COPY_AND_ASSIGN(StackTraceCollector);
  };

 private:
  static threading::RecursiveMutex mutex_;
  static container::ThreadsafeLookupTable<threading::ThreadType::ThreadIdType, std::shared_ptr<StackTraceCollector>>
      stackTraceCollectors_;

 private:
  std::shared_ptr<StackTraceCollector> GetStackTraceCollector() const;
  DISALLOW_COPY_AND_ASSIGN(VisualStudioStackTraceProvider);
};

}  // namespace exceptions

