
#pragma once

#include <atomic>
#include <functional>
#include <memory>
#include <string>

#include "Exceptions/ISignalCatcher.h"
#include "Exceptions/MSVC/VisualStudioExceptionPrinter.h"
#include "Exceptions/MSVC/VisualStudioExceptionTypes.h"
#include "Exceptions/MSVC/VisualStudioStackTraceProvider.h"
#include "Exceptions/Signal.h"
#include "Logging/Logger.h"
#include "System/Noncopyable.h"
#include "Threading/SafeStartStop.h"


namespace exceptions {

class VisualStudioSignalCatcher final : public ISignalCatcher {
 public:
  static std::shared_ptr<VisualStudioSignalCatcher> GetInstance();

  // ISignalCatcher
  void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) override;
  void Destroy() override;
  void SetFunctionToBeCalledAfterSignalIsHandled(const AfterSignalHandler& function) override;
  bool TestSignalCalledFlag(int64_t* signalCode) const override;
  void RunAndEnableThreadSpecificSignals(const Main& function) override;
  void TriggerStackDumpOnThread(const threading::Thread& thread) const override;

 private:
  std::shared_ptr<VisualStudioStackTraceProvider> stackTraceProvider_;
  std::shared_ptr<VisualStudioExceptionPrinter> exceptionPrinter_;
  std::shared_ptr<logging::Logger> logger_;
  AfterSignalHandler functionToBeCalledAfterSignalIsHandled_;
  std::atomic<bool> signalCalled_;
  std::atomic<int64_t> signalCode_;
  threading::SafeStartStop safeStartStop_;

 private:
  static void GetExceptionPointers(DWORD dwExceptionCode, EXCEPTION_POINTERS** ppExceptionPointers);

  void SetProcessSignalHandlers();

  static void SigabrtHandler(int errorCode);
  static void SigintHandler(int errorCode);
  static void SigtermHandler(int errorCode);
  static void SigfpeHandler(int errorCode, int subcode);
  static void SigillHandler(int errorCode);
  static void SigsegvHandler(int errorCode);

  static int NewHandler(size_t errorCode);

  static void TerminateHandler();
  static void UnexpectedHandler();
  static void PureCallHandler();

  static void InvalidParameterHandler(
      const wchar_t* expression, const wchar_t* function, const wchar_t* file, unsigned int line, uintptr_t pReserved);

  void HandleSignal(const std::string& exceptionName, int errorCode, const SignalType& signalType);
  void HandleException(EXCEPTION_POINTERS* exceptionPointers, const SignalType& signalType);
  void SetThreadSignalHandlers();

  VisualStudioSignalCatcher();
  DISALLOW_COPY_AND_ASSIGN(VisualStudioSignalCatcher);
};

}  // namespace exceptions

