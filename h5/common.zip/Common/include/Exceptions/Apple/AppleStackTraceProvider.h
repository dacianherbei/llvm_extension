
#pragma once

#include "Exceptions/IStackTraceProvider.h"
#include "System/Noncopyable.h"


namespace exceptions {

class AppleStackTraceProvider final : public IStackTraceProvider {
 public:
  AppleStackTraceProvider();
  ~AppleStackTraceProvider() override;

  std::string GetStackTrace() const override;
  std::string GetStackTraceAfterSignal(const Signal& signalInfo) const override;

 private:
  static const size_t kMaxStackDepth = 256;

 private:
  void DemangleFunction(char* functionName, std::stringstream* stackTraceStream) const;
  DISALLOW_COPY_AND_ASSIGN(AppleStackTraceProvider);
};

}  // namespace exceptions

