
#pragma once

#include "System/Enum.h"

DEFINE__ENUM(
    ()(exceptions),
    SignalType,
    int,
    // Program should be aborted due to an unrecoverable error
    ((kAbortProgram, 1, "AbortProgram"))
    // Exit program, not due to error
    ((kExitProgram, 2, "ExitProgram"))
    // Dump stack trace but don't abort the program
    ((kDumpStackTrace, 3, "DumpStackTrace")))
