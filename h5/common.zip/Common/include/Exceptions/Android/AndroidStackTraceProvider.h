
#pragma once

#include <unwind.h>

#include "Exceptions/IStackTraceProvider.h"
#include "System/Noncopyable.h"


namespace exceptions {

class AndroidStackTraceProvider final : public IStackTraceProvider {
 public:
  AndroidStackTraceProvider();
  ~AndroidStackTraceProvider() override;

  std::string GetStackTrace() const override;
  std::string GetStackTraceAfterSignal(const Signal& signalInfo) const override;

 private:
  void DemangleFunction(const char* functionNameIn, std::ostringstream* stackTraceStream) const;
  size_t CaptureUnwindBacktrace(void** buffer, size_t max) const;
  static _Unwind_Reason_Code UnwindCallback(struct _Unwind_Context* context, void* arg);
  std::string GetStackTraceAfterSignalCorkscrew(const Signal& signalInfo) const;
  std::string GetStackTraceAfterSignalLibunwind(const Signal& signalInfo) const;
  std::string GetStackTraceAfterSignalUnwind(const Signal& signalInfo) const;
  DISALLOW_COPY_AND_ASSIGN(AndroidStackTraceProvider);
};

}  // namespace exceptions

