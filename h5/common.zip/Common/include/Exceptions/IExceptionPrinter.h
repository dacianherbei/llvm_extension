
#pragma once

#include "System/Noncopyable.h"


namespace exceptions {

class IExceptionPrinter {
 public:
  IExceptionPrinter() {}
  virtual ~IExceptionPrinter() {}

 private:
  DISALLOW_COPY_AND_ASSIGN(IExceptionPrinter);
};

}  // namespace exceptions

