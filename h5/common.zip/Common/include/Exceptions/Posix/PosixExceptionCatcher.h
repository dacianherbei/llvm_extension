
#pragma once

#include <signal.h>
#include <exception>
#include <functional>

#include "Exceptions/IExceptionCatcher.h"
#include "Exceptions/IStackTraceProvider.h"
#include "Exceptions/Posix/PosixExceptionPrinter.h"
#include "Logging/Logger.h"
#include "System/EnsureSingleLiveInstance.h"
#include "System/Noncopyable.h"
#include "Threading/SafeStartStop.h"


namespace exceptions {

class PosixExceptionCatcher final : public IExceptionCatcher,
                                    private system::EnsureSingleLiveInstance<PosixExceptionCatcher> {
 public:
  static std::shared_ptr<PosixExceptionCatcher> GetInstance();

  // IExceptionCatcher
  void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) override;
  void Destroy() override;
  void RunAndLogExceptionAndStackTraceOnException(Main&& function) override;
  void SetFunctionToBeCalledAfterExceptionIsHandled(const AfterExceptionHandler& function) override;

 private:
  static const std::shared_ptr<PosixExceptionCatcher> instance_;

  std::shared_ptr<IStackTraceProvider> stackTraceProvider_;
  std::shared_ptr<PosixExceptionPrinter> exceptionPrinter_;
  std::shared_ptr<logging::Logger> logger_;
  AfterExceptionHandler functionToBeCalledAfterExceptionIsHandled_;
  std::terminate_handler originalTerminateHandler_;
  threading::SafeStartStop safeStartStop_;

 private:
  static void TerminateHandler();

  PosixExceptionCatcher();
  void HandleException(const std::string& exceptionName);
  void HandleNestedException(const std::exception& exception);
  void HandleTerminate();

  DISALLOW_COPY_AND_ASSIGN(PosixExceptionCatcher);
};

}  // namespace exceptions

