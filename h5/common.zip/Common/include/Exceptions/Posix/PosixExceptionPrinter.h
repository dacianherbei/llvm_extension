
#pragma once

#include <signal.h>
#include <string>

#include "Exceptions/IExceptionPrinter.h"
#include "System/Noncopyable.h"


namespace exceptions {

class PosixExceptionPrinter final : public IExceptionPrinter {
 public:
  PosixExceptionPrinter();
  ~PosixExceptionPrinter();

  std::string GetExceptionAsString(const std::exception& exceptionRecord);

  std::string GetSignalAsString(const char* signalName);

  std::string GetSignalAsString(const char* signalName, int signalNumber, siginfo_t* info, void* sigcontext);

 private:
  static std::string GetSiginfoAsString(siginfo_t* info);
  static std::string GetSigillCodeAsString(siginfo_t* info);
  static std::string GetSigfpeCodeAsString(siginfo_t* info);
  static std::string GetSigsegvCodeAsString(siginfo_t* info);
  static std::string GetSigbusCodeAsString(siginfo_t* info);
  static std::string GetSigtrapCodeAsString(siginfo_t* info);
  static std::string GetSigchldCodeAsString(siginfo_t* info);
  static std::string GetSigpollCodeAsString(siginfo_t* info);
  static std::string GetAnyCodeAsString(siginfo_t* info);

  DISALLOW_COPY_AND_ASSIGN(PosixExceptionPrinter);
};

}  // namespace exceptions

