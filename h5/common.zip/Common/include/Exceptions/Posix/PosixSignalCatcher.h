
#pragma once

#include <signal.h>
#include <atomic>
#include <exception>
#include <functional>
#include <memory>
#include <string>

#include "Exceptions/ISignalCatcher.h"
#include "Exceptions/IStackTraceProvider.h"
#include "Exceptions/Signal.h"
#include "Exceptions/Posix/PosixExceptionPrinter.h"
#include "Logging/Logger.h"
#include "System/EnsureSingleLiveInstance.h"
#include "System/Noncopyable.h"
#include "Threading/SafeStartStop.h"


namespace exceptions {

class PosixSignalCatcher final : public ISignalCatcher, private system::EnsureSingleLiveInstance<PosixSignalCatcher> {
 public:
  static std::shared_ptr<PosixSignalCatcher> GetInstance();

  // ISignalCatcher
  void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) override;
  void Destroy() override;
  void SetFunctionToBeCalledAfterSignalIsHandled(const AfterSignalHandler& function) override;
  bool TestSignalCalledFlag(int64_t* signalCode) const override;
  void RunAndEnableThreadSpecificSignals(const Main& function) override;
  void TriggerStackDumpOnThread(const threading::Thread& thread) const override;

 private:
  static const std::shared_ptr<PosixSignalCatcher> instance_;

  std::shared_ptr<IStackTraceProvider> stackTraceProvider_;
  std::shared_ptr<PosixExceptionPrinter> exceptionPrinter_;
  std::shared_ptr<logging::Logger> logger_;
  AfterSignalHandler functionToBeCalledAfterSignalIsHandled_;
  std::atomic<bool> signalCalled_;
  std::atomic<int64_t> signalCode_;
  threading::SafeStartStop safeStartStop_;

 private:
  void SetProcessSignalHandlers();
  void AttachSignal(int signal, void (*signalHandler)(int, siginfo_t*, void*));

  static void SigabrtHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void SigintHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void SigtermHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void SigfpeHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void SigillHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void SigsegvHandler(int signalNumber, siginfo_t* info, void* sigcontext);
  static void Sigusr1Handler(int signalNumber, siginfo_t* info, void* sigcontext);

  void HandleSignal(
      const char* signalName, int signalNumber, siginfo_t* info, void* sigcontext, const SignalType& signalType);
  void HandleSignal(
      const char* errorToPrint, const SignalType& signalType, siginfo_t* info = nullptr, void* sigcontext = nullptr);

  PosixSignalCatcher();
  DISALLOW_COPY_AND_ASSIGN(PosixSignalCatcher);
};

}  // namespace exceptions

