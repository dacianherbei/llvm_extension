#pragma once

#include <functional>
#include <string>

#include "Exceptions/IExceptionPrinter.h"
#include "Exceptions/IStackTraceProvider.h"
#include "Logging/Logger.h"
#include "System/Noncopyable.h"


namespace exceptions {

class IExceptionCatcher {
 public:
  using AfterExceptionHandler = std::function<void(const std::string& /* exceptionMessage */)>;
  using Main = std::function<void()>;

 public:
  virtual ~IExceptionCatcher() {}

  virtual void Initialize(
      const std::shared_ptr<IStackTraceProvider>& stackTraceProvider,
      const std::shared_ptr<IExceptionPrinter>& exceptionPrinter,
      const std::shared_ptr<logging::Logger>& logger) = 0;
  virtual void Destroy() = 0;
  virtual void SetFunctionToBeCalledAfterExceptionIsHandled(const AfterExceptionHandler& function) = 0;
  virtual void RunAndLogExceptionAndStackTraceOnException(Main&& function) = 0;

 protected:
  IExceptionCatcher() {}

 private:
  DISALLOW_COPY_AND_ASSIGN(IExceptionCatcher);
};

}  // namespace exceptions

