
#pragma once

#include "Exceptions/IStackTraceProvider.h"
#include "System/Noncopyable.h"


namespace exceptions {

class GlibcStackTraceProvider final : public IStackTraceProvider {
 public:
  GlibcStackTraceProvider();
  ~GlibcStackTraceProvider() override;

  std::string GetStackTrace() const override;
  std::string GetStackTraceAfterSignal(const Signal& signalInfo) const override;

 private:
  void DemangleFunction(char* functionName, std::stringstream* stackTraceStream) const;
  DISALLOW_COPY_AND_ASSIGN(GlibcStackTraceProvider);
};

}  // namespace exceptions

