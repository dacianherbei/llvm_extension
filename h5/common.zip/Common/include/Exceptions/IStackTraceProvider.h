
#pragma once

#include <string>

#include "Exceptions/Signal.h"
#include "System/Noncopyable.h"


namespace exceptions {

class IStackTraceProvider {
 public:
  virtual ~IStackTraceProvider() {}

  virtual std::string GetStackTrace() const = 0;

  virtual std::string GetStackTraceAfterSignal(const Signal& signalInfo) const = 0;

 protected:
  IStackTraceProvider() {}

 private:
  DISALLOW_COPY_AND_ASSIGN(IStackTraceProvider);
};

}  // namespace exceptions

