
#pragma once

#include <boost/optional.hpp>

#include "Boost/OptionalUtilities.h"
#include "Memory/BufferFactory.h"
#include "Memory/IBuffer.h"
#include "Memory/IBufferReaderWriter.h"


namespace memory {

class MemoryStreamReaderWriter final : public IBufferReaderWriter {
 public:
  static const size_t kInitialBufferSize = 4096;

 public:
  MemoryStreamReaderWriter(
      const std::shared_ptr<const BufferFactory>& bufferFactory,
      const boost::optional<std::string>& name = boost::none);
  ~MemoryStreamReaderWriter() override;

  size_t WriteByte(const uint8_t byte) override;
  size_t Write(const std::shared_ptr<const IBuffer>& buffer) override;
  size_t Write(const memory::Buffer2View<const uint8_t*>& buffer) override;

  void Flush() override;
  void Print(std::ostream* stream) const override;
  bool TrySeek(const uint64_t offset) override;
  uint64_t GetCurrentPosition() const override;
  boost::optional<uint64_t> TryGetTotalSize() const override;
  void Close() override;

  bool TryReadByte(const size_t offset, uint8_t* byte) const override;
  int64_t TryReadDefaultLengthBlock(const size_t offset, std::shared_ptr<const IBuffer>* outBuffer) const override;
  int64_t TryReadVariableLengthBlock(
      const size_t offset, const size_t length, std::shared_ptr<const IBuffer>* outBuffer) const override;
  int64_t TryReadDefaultLengthBlock(const size_t offset, Buffer2* outBuffer) const override;
  int64_t TryReadVariableLengthBlock(const size_t offset, const size_t length, Buffer2* outBuffer) const override;

  uint64_t GetTotalSize() const;
  bool TryGetName(std::string* name) const;
  void Clear();

 private:
  const std::shared_ptr<const memory::BufferFactory> bufferFactory_;
  const boost::optional<std::string> name_;
  memory::Buffer2 data_;

  size_t currentIndex_;

 private:
  void GrowBufferIfNeeded(const size_t incomingSize);
  void UpdateIndex(const size_t newDataSize);

  DISALLOW_COPY_AND_ASSIGN(MemoryStreamReaderWriter);
};

}  // namespace memory

