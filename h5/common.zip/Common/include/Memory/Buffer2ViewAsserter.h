
#pragma once

#include <atomic>
#include <cstddef>

#include "System/Noncopyable.h"


namespace memory {

class Buffer2ViewAsserter final {
 public:
  Buffer2ViewAsserter();
  ~Buffer2ViewAsserter();

  void IncrementViewCount();
  void DecrementViewCount();

  bool AssertNoViewsExist() const;

 private:
  std::atomic<size_t> viewCount_;

 private:
  DISALLOW_COPY_AND_ASSIGN(Buffer2ViewAsserter);
};

}  // namespace memory

