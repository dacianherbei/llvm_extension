
#pragma once

#include <cstddef>
#include <cstdint>

#include "Memory/MoveAsserter.h"
#include "Memory/NullMoveAsserter.h"
#include "System/ForwardDeclare.h"

_FORWARD_DECLARE_CLASS(()(memory), Buffer2)


namespace memory {

/**
 * Buffer2View provides a view towards a Buffer2 instance
 * Buffer2View implementation triggers a strong assertion in debug mode when the underlying Buffer2 instance is moved
 * as well as when the Buffer2View instance was moved. This is valid for all calls to the public interface.
 * Since the Buffer2View instance can exist without a Buffer2 instance the first type of assertions always check the presence of a Buffer2 instance.
 */
template <typename TMemoryPointer>
class Buffer2View final {
 public:
  static constexpr auto kIsReadOnly = std::is_const<std::remove_pointer_t<TMemoryPointer>>::value;

 public:
  Buffer2View();
  Buffer2View(const Buffer2View& other);
  Buffer2View(Buffer2View&& other);

  template <typename TOtherMemoryPointer>
  Buffer2View(Buffer2View<TOtherMemoryPointer>&& other);

  ~Buffer2View();

  Buffer2View& operator=(Buffer2View&& other);
  Buffer2View& operator=(const Buffer2View& other);

  size_t GetSize() const;
  bool IsContiguous() const;

  operator const Buffer2View<const uint8_t*>&() const;

  Buffer2View Slice(const size_t offset) const;
  Buffer2View Slice(const size_t offset, const size_t length) const;

  /**
   * Equality means: Both views are pointing to the exact same buffer fragment(s) addresses in memory. The views may
   * have been derived from different Buffer2 instances.
   *
   * This does not perform a deep memcmp. Views are not considered equal just because the buffer fragments, to which
   * they are pointing contain the same data. Use BufferUtilities::CompareBuffer2View for that purpose.
   */
  bool operator==(const Buffer2View& other) const;
  bool operator!=(const Buffer2View& other) const;

  void AssertOnAccessToMovedObject(const char* const caller) const;

 private:
  friend class Buffer2;
  friend class Buffer2ViewAccessor;
  friend class Buffer2IBufferAdapter;

 private:
  struct FragmentInfo final {
    TMemoryPointer pointer;
    const size_t numberOfBytes;

    FragmentInfo(TMemoryPointer _pointer, const size_t _numberOfBytes)
        : pointer(_pointer), numberOfBytes(_numberOfBytes) {}
  };

  class BufferFragmentIterator final {
   public:
    friend class Buffer2View;

    BufferFragmentIterator(BufferFragmentIterator&&) = default;
    BufferFragmentIterator(const BufferFragmentIterator&) = default;
    BufferFragmentIterator& operator=(const BufferFragmentIterator&) = default;

    FragmentInfo GetFragment() const;
    BufferFragmentIterator GetNext() const;
    bool HasNext() const;

   private:
    static const FragmentInfo kNullFragmentInfo;

    const Buffer2* buffer_;
    size_t currentFragmentIndex_;
    size_t offsetIntoCurrentFragment_;
    size_t sizeLeft_;

   private:
    BufferFragmentIterator(
        const Buffer2* buffer,
        const size_t currentFragmentIndex,
        const size_t offsetIntoCurrentFragment,
        const size_t sizeLeft);
  };

 private:
  const Buffer2* buffer_;
  size_t size_;
  size_t currentFragmentIndex_;
  size_t currentFragmentOffset_;
#ifdef NDEBUG
  mutable NullMoveAsserter moveAsserter_;
#else
  mutable MoveAsserter moveAsserter_;
#endif

 private:
  // Prevent allocation on heap:
  // TODO(AS): This still doesn't prevent std::make_shared, because it uses placement new, which is a global operator
  // that cannot be deleted like this.
  static void* operator new(size_t) = delete;
  static void* operator new[](size_t) = delete;
  static void operator delete[](void*) = delete;

  BufferFragmentIterator GetCurrentFragmentIterator() const;

  void Clear();

  inline const Buffer2* GetBuffer() const { return buffer_; }
  inline Buffer2* GetBuffer() { return const_cast<Buffer2*>(buffer_); }

  void IncrementViewCount();
  void DecrementViewCount();

  explicit Buffer2View(const Buffer2& buffer);
  Buffer2View(const Buffer2& buffer, const size_t offset, const size_t size);
  Buffer2View(
      const Buffer2* buffer, const size_t size, const size_t currentFragmentIndex, const size_t currentFragmentOffset);
  void AdvanceBy(const size_t numberOfBytes, size_t* outFragmentIndex, size_t* outFragmentOffset) const;
};

}  // namespace memory


#include "Memory/Buffer2View-inl.h"
