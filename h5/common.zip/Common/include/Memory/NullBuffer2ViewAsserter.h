
#pragma once

#include "System/Noncopyable.h"


namespace memory {

class NullBuffer2ViewAsserter final {
 public:
  NullBuffer2ViewAsserter() {}
  ~NullBuffer2ViewAsserter() {}

  void IncrementViewCount() {}
  void DecrementViewCount() {}

  bool AssertNoViewsExist() const { return true; }

 private:
  DISALLOW_COPY_AND_ASSIGN(NullBuffer2ViewAsserter);
};

}  // namespace memory

