
#pragma once

#include <boost/optional.hpp>

#include "Memory/Buffer.h"
#include "Memory/Buffer2.h"
#include "Memory/CompositeBuffer.h"
#include "Memory/IBuffer.h"
#include "System/Noncopyable.h"
#include "System/ForwardDeclare.h"
#include "System/TypeTraitsHelper.h"

_FORWARD_DECLARE_CLASS(()(exceptions), IStackTraceProvider)


namespace memory {

class BufferFactory final : public std::enable_shared_from_this<BufferFactory> {
 public:
  static constexpr size_t kPageSize = 4 * 1024;

  // Currently we only allocate memory in powers of 2, so we use a bitwise AND (&) to make the value a power of 2
  static constexpr size_t kMaxBufferSize = std::numeric_limits<uint32_t>::max() & 0x80000000;

 public:
  static bool CompositionRequiresFlattening(
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end);

  template <
      typename IteratorType,
      typename = typename std::enable_if<
          !std::is_same<IteratorType, std::vector<std::reference_wrapper<const Buffer2>>::const_iterator>::value,
          void>::type>
  static bool CompositionRequiresFlattening(const IteratorType& begin, const IteratorType& end);

  explicit BufferFactory(
      const std::allocator<uint8_t>& allocator,
      const boost::optional<std::shared_ptr<exceptions::IStackTraceProvider>> stackTraceProvider = boost::none);

  ~BufferFactory();

  Buffer2 CreateBuffer2(const size_t size) const;
  Buffer2 CreateAlignedBuffer2(const size_t size, const size_t alignment) const;
  Buffer2 CreateBuffer2(const size_t size, const size_t capacity) const;

  template <
      typename... BufferType,
      typename = typename std::enable_if_t<system::AreAllTheSame<Buffer2, BufferType...>::value, Buffer2>>
  Buffer2 CreateBuffer2(const BufferType&... moreBuffers) const;

  template <
      typename IteratorType,
      typename = typename std::enable_if<!std::is_same<IteratorType, Buffer2>::value, void>::type>
  Buffer2 CreateBuffer2(const IteratorType& begin, const IteratorType& end) const;

  template <
      typename... BufferType,
      typename = typename std::enable_if_t<system::AreAllTheSame<Buffer2, BufferType...>::value, Buffer2>>
  Buffer2 CreateBuffer2(BufferType&&... moreBuffers) const;

  template <typename IteratorType>
  Buffer2 CreateBuffer2(
      const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const;

  template <
      typename... BufferType,
      typename = typename std::enable_if_t<system::AreAllTheSame<Buffer2, BufferType...>::value, Buffer2>>
  Buffer2 CreateBuffer2AllowAutoFlatten(const BufferType&... moreBuffers) const;

  template <
      typename IteratorType,
      typename = typename std::enable_if<!std::is_same<IteratorType, Buffer2>::value, void>::type>
  Buffer2 CreateBuffer2AllowAutoFlatten(const IteratorType& begin, const IteratorType& end) const;

  template <
      typename... BufferType,
      typename = typename std::enable_if_t<system::AreAllTheSame<Buffer2, BufferType...>::value, Buffer2>>
  Buffer2 CreateBuffer2AllowAutoFlatten(BufferType&&... moreBuffers) const;

  template <typename IteratorType>
  Buffer2 CreateBuffer2AllowAutoFlatten(
      const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const;

  std::shared_ptr<Buffer> CreateBuffer(const size_t size) const;
  std::shared_ptr<Buffer> CreateBuffer(const size_t size, const size_t capacity) const;

  std::shared_ptr<CompositeBuffer> CreateBuffer(const std::vector<std::shared_ptr<const IBuffer>>& buffers) const;
  std::shared_ptr<CompositeBuffer> CreateBuffer(std::vector<std::shared_ptr<const IBuffer>>&& buffers) const;

  const std::allocator<uint8_t>& GetAllocator() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
  const boost::optional<std::shared_ptr<exceptions::IStackTraceProvider>> stackTraceProvider_;

 private:
  static size_t GetCumulativeBufferSize(
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end);

  template <
      typename IteratorType,
      typename = typename std::enable_if<
          !std::is_same<IteratorType, std::vector<std::reference_wrapper<const Buffer2>>::const_iterator>::value,
          void>::type>
  static size_t GetCumulativeBufferSize(const IteratorType& begin, const IteratorType& end);

  template <typename IteratorType>
  Buffer2 CreateBuffer2MovingFragmentsFromRange(
      const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const;

  template <typename IteratorType>
  Buffer2 CreateBuffer2ShallowCopyingFragmentsFromRange(const IteratorType& begin, const IteratorType& end) const;

  Buffer2 FlattenRange(
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& begin,
      const std::vector<std::reference_wrapper<const Buffer2>>::const_iterator& end) const;

  template <
      typename IteratorType,
      typename = typename std::enable_if<
          !std::is_same<IteratorType, std::vector<std::reference_wrapper<const Buffer2>>::const_iterator>::value,
          void>::type>
  Buffer2 FlattenRange(const IteratorType& begin, const IteratorType& end) const;

  template <typename IteratorType>
  Buffer2 FlattenRangeAndMarkAsMoved(
      const std::move_iterator<IteratorType>& begin, const std::move_iterator<IteratorType>& end) const;

  uint32_t CalculateBufferCapacity(const size_t size) const;

  void AssertOnCompositionFailure() const;

  DISALLOW_COPY_AND_ASSIGN(BufferFactory);
};

}  // namespace memory


#include "Memory/BufferFactory-inl.h"
