
#pragma once

#include <cstddef>


namespace memory {

template <typename TMemoryPointer>
class BufferSegment final {
 public:
  BufferSegment(const size_t sizeInBytes, TMemoryPointer pointer);
  BufferSegment(const BufferSegment&) = default;
  BufferSegment(BufferSegment&&) = default;

  BufferSegment& operator=(const BufferSegment&) = default;
  BufferSegment& operator=(BufferSegment&&) = default;

  size_t GetSize() const;
  TMemoryPointer GetPointer() const;

  bool operator==(const BufferSegment& other) const;
  bool operator!=(const BufferSegment& other) const;

 private:
  size_t sizeInBytes_;
  TMemoryPointer pointer_;

 private:
  // Prevent allocation on heap:
  static void* operator new(size_t) = delete;
  static void* operator new[](size_t) = delete;
};

}  // namespace memory

