
#pragma once

#include "System/Noncopyable.h"


namespace memory {

class NullMoveAsserter final {
 public:
  inline NullMoveAsserter() {}
  inline ~NullMoveAsserter() {}

  inline void Initialize() {}
  inline void AssertOnAccessToMovedObject(const char* const caller) const {}
  inline void Move(const char* const caller) {}

 private:
  DISALLOW_COPY_AND_ASSIGN(NullMoveAsserter);
};

}  // namespace memory

