
#pragma once

#include <atomic>

#include <boost/current_function.hpp>

#include "System/Noncopyable.h"
#include "System/Assert.h"

#define _ASSERT_ON_ACCESS_TO_MOVED_OBJECT(object) object.AssertOnAccessToMovedObject(BOOST_CURRENT_FUNCTION);

#define _MOVE_ASSERTER_MOVE(object) object.Move(BOOST_CURRENT_FUNCTION);


namespace memory {

class MoveAsserter final {
 public:
  MoveAsserter();
  ~MoveAsserter();

  void Initialize();
  void AssertOnAccessToMovedObject(const char* const caller) const;
  void Move(const char* const caller);

 private:
  std::atomic<bool> moved_;

 private:
  DISALLOW_COPY_AND_ASSIGN(MoveAsserter);
};

}  // namespace memory


#include "Memory/MoveAsserter-inl.h"
