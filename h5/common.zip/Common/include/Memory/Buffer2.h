
#pragma once

#include <cstdint>
#include <memory>

#include "Memory/Buffer2View.h"
#include "Memory/Buffer2ViewAsserter.h"
#include "Memory/MoveAsserter.h"
#include "Memory/NullBuffer2ViewAsserter.h"
#include "Memory/NullMoveAsserter.h"
#include "System/Noncopyable.h"


namespace memory {

class Buffer2;
class BufferFactory;
class IBuffer;

class BufferFragment final {
 public:
  BufferFragment();
  BufferFragment(
      const std::shared_ptr<uint8_t>& data, const size_t size, const size_t capacity, const size_t offset = 0);
  BufferFragment(std::shared_ptr<uint8_t>&& data, const size_t size, const size_t capacity, const size_t offset = 0);
  BufferFragment(BufferFragment&& other);
  ~BufferFragment();

  BufferFragment& operator=(BufferFragment&& other);
  uint8_t* GetRawPointer();
  void SetSize(const size_t newSize);

  BufferFragment Slice(const size_t offset, const size_t length) const;
  BufferFragment CreateShallowCopy() const;

  const uint8_t* GetRawPointer() const;
  size_t GetSize() const;
  size_t GetAvailableBytesAfterOffset() const;
  size_t GetCapacity() const;
  size_t GetOffset() const;
  bool IsValid() const;

 private:
  friend class Buffer2;
  friend class Buffer2IBufferAdapter;

 private:
  std::shared_ptr<uint8_t> data_;
  size_t capacity_;

  size_t size_;
  size_t offset_;

 private:
  void Clear();
  void ValidateConstructorParameters();
  DISALLOW_COPY_AND_ASSIGN(BufferFragment);
};

class Buffer2 final {
 public:
  static constexpr const size_t kMaximumNumberOfCompositeFragments = 4;

 public:
  Buffer2();
  Buffer2(Buffer2&& other);
  explicit Buffer2(const Buffer2View<const uint8_t*>& bufferView);
  explicit Buffer2(Buffer2View<uint8_t*>&& bufferView);
  Buffer2 CreateShallowCopy() const;
  ~Buffer2();

  Buffer2(const std::shared_ptr<uint8_t>& data, const size_t size, const size_t capacity);
  Buffer2(std::shared_ptr<uint8_t>&& data, const size_t size, const size_t capacity);

  Buffer2& operator=(Buffer2&& other);
  Buffer2& operator=(Buffer2View<uint8_t*>&& view);
  Buffer2& operator=(const Buffer2View<const uint8_t*>& view);

  void SetSize(const size_t newSize);

  size_t GetSize() const;
  size_t GetCapacity() const;
  size_t GetValidFragmentsCount() const;

  operator Buffer2View<const uint8_t*>() const;
  operator Buffer2View<uint8_t*>();

  Buffer2View<const uint8_t*> GetConstView() const;
  Buffer2View<const uint8_t*> GetView() const;
  Buffer2View<uint8_t*> GetView();

  Buffer2View<const uint8_t*> Slice(const size_t offset) const;
  Buffer2View<const uint8_t*> Slice(const size_t offset, const size_t length) const;

  Buffer2View<uint8_t*> Slice(const size_t offset);
  Buffer2View<uint8_t*> Slice(const size_t offset, const size_t length);

  bool operator==(const Buffer2View<const uint8_t*>& other) const;
  bool operator!=(const Buffer2View<const uint8_t*>& other) const;

  std::shared_ptr<const IBuffer> AsIBuffer(const std::shared_ptr<const BufferFactory>& bufferFactory) const;
  std::shared_ptr<const IBuffer> MoveAsIBuffer(const std::shared_ptr<const BufferFactory>& bufferFactory);

  void AssertOnAccessToMovedObject(const char* const caller) const;

  bool TryAppendWithShallowCopy(const Buffer2& buffer);
  bool TryAppendWithMove(Buffer2&& buffer);

 private:
  template <typename TMemoryPointer>
  friend class Buffer2View;
  friend class Buffer2IBufferAdapter;

 private:
  BufferFragment fragments_[kMaximumNumberOfCompositeFragments];
  size_t size_;
  size_t validFragmentsCount_;

#ifdef NDEBUG
  mutable NullBuffer2ViewAsserter viewAsserter_;
  mutable NullMoveAsserter moveAsserter_;
#else
  mutable Buffer2ViewAsserter viewAsserter_;
  mutable MoveAsserter moveAsserter_;
#endif

 private:
  template <typename TBufferView>
  void InsertFragmentsFromView(TBufferView&& bufferView);

  void ForcedAppendWithShallowCopy(const Buffer2& buffer);
  void ForcedAppendWithMove(Buffer2&& buffer);

  void Clear();
  void EnsureValidFragmentsAreInFrontOfTheBuffer();

  DISALLOW_COPY_AND_ASSIGN(Buffer2);
};

std::ostream& operator<<(std::ostream& stream, const Buffer2& buffer2);

}  // namespace memory


#include "Memory/Buffer2-inl.h"
