
#pragma once

#include "Memory/IBuffer.h"
#include "System/MakeStatic.h"


namespace memory {

class BufferByteUtilities final {
 public:
  template <typename IntegralType>
  static IntegralType GetBytes(size_t index, const std::shared_ptr<const IBuffer>& buffer);

  static BufferVisitorType CreateRangeBufferVisitor(size_t start, size_t end, const BufferVisitorType& visitor);

 private:
  MAKE_STATIC(BufferByteUtilities);
};

}  // namespace memory

