
#pragma once

#include "Memory/Buffer2View.h"
#include "System/MakeStatic.h"
#include "System/ForwardDeclare.h"
#include "System/Uint24_t.h"
#include "System/Uint48_t.h"

_FORWARD_DECLARE_CLASS(()(memory), BufferFactory)


namespace memory {

class Buffer2ViewAccessor final {
 public:
  static int8_t ReadInt8(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static int16_t ReadInt16(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static int32_t ReadInt32(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static int64_t ReadInt64(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static uint8_t ReadUInt8(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static uint16_t ReadUInt16(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static system::Uint24_t ReadUInt24(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static uint32_t ReadUInt32(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static system::Uint48_t ReadUInt48(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static uint64_t ReadUInt64(const Buffer2View<const uint8_t*>& bufferView, const size_t index = 0);

  static void SetInt8(const int8_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetInt16(const int16_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetInt32(const int32_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetInt64(const int64_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt8(const uint8_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt16(const uint16_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt24(const system::Uint24_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt32(const uint32_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt48(const system::Uint48_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void SetUInt64(const uint64_t item, const Buffer2View<uint8_t*>& bufferView, const size_t index = 0);

  static void WriteBytes(
      const Buffer2View<uint8_t*>& bufferView, const size_t offset, const void* source, const size_t length);

  static void WriteBytes(
      const Buffer2View<uint8_t*>& bufferView, const Buffer2View<const uint8_t*>& source, const size_t length);

  static void WriteBytes(
      const Buffer2View<uint8_t*>& bufferView,
      const size_t destinationOffset,
      const Buffer2View<const uint8_t*>& source);

  static void WriteBytes(
      const Buffer2View<uint8_t*>& bufferView,
      const size_t destinationOffset,
      const Buffer2View<const uint8_t*>& source,
      const size_t sourceOffset);

  static void WriteBytes(
      const Buffer2View<uint8_t*>& bufferView,
      const size_t destinationOffset,
      const Buffer2View<const uint8_t*>& source,
      const size_t sourceOffset,
      const size_t length);

  static void WriteBytes(const Buffer2View<uint8_t*>& bufferView, const Buffer2View<const uint8_t*>& source);

  static void WriteBytes(const Buffer2View<uint8_t*>& bufferView, const void* source, const size_t length);

  static void ReadBytes(const Buffer2View<const uint8_t*>& bufferView, void* destination, const size_t length);

  static void ReadBytes(
      const Buffer2View<const uint8_t*>& bufferView, void* destination, const size_t offset, const size_t length);

  // Guarantee: `accessor` is called at most once. A temporary buffer is allocated, and contents copied, if necessary.
  template <typename TCallable>
  static void VisitContiguous(
      const std::shared_ptr<const BufferFactory>& bufferFactory,
      const Buffer2View<const uint8_t*>& bufferView,
      TCallable&& accessor);  // (const uint8_t* buffer, size_t numBytes)

  template <typename TCallable>
  static void Visit(const Buffer2& bufferView, TCallable&& accessor);

  template <typename DataType, typename TCallable>
  static void Visit(
      const Buffer2View<DataType*>& bufferView,
      TCallable&& accessor);  // ([const] uint8_t* buffer, size_t numBytes)

  static uint8_t* GetPointer(const Buffer2View<uint8_t*>& bufferView);
  static const uint8_t* GetConstPointer(const Buffer2View<const uint8_t*>& bufferView);

  static Buffer2 EnsureContiguous(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const Buffer2View<const uint8_t*>& bufferView);

 private:
  template <typename TCallable, typename... ArgTypes>
  static bool Execute(void* ptr, TCallable&& accessor, ArgTypes&&... args);

  template <typename TCallable, typename... ArgTypes>
  static bool Execute(bool* ptr, TCallable&& accessor, ArgTypes&&... args);

  template <typename IntegralType>
  static IntegralType GetBytesAsIntegralType(const Buffer2View<const uint8_t*>& bufferView, const size_t index);

  template <typename IntegralType>
  static void SetBytesAsIntegralType(
      const Buffer2View<uint8_t*>& bufferView, const size_t index, const IntegralType item);

  MAKE_STATIC(Buffer2ViewAccessor);
};

}  // namespace memory


#include "Memory/Buffer2ViewAccessor-inl.h"
