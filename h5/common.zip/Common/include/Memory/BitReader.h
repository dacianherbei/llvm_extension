
#pragma once

#include <stdint.h>

#include <boost/optional.hpp>

#include "Logging/Logging.h"
#include "Memory/IBitDecoder.h"
#include "System/Noncopyable.h"


namespace memory {

class BitReader final {
 public:
  BitReader(const std::shared_ptr<logging::Logger>& logger, const std::shared_ptr<const IBitDecoder>& bitDecoder);

  boost::optional<bool> TryReadBoolBit(
      const uint8_t* const data, size_t* const bitOffset, const size_t bitLength) const;

  boost::optional<uint32_t> TryReadBits(
      const uint8_t* const data, size_t* const bitOffset, const size_t bitLength, const size_t readBitCount) const;

 private:
  const std::shared_ptr<logging::Logger> logger_;
  const std::shared_ptr<const IBitDecoder> bitDecoder_;

 private:
  DISALLOW_COPY_AND_ASSIGN(BitReader);
};

}  // namespace memory

