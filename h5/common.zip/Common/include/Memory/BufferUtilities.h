
#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Memory/Buffer.h"
#include "Memory/Buffer2View.h"
#include "Memory/BufferFactory.h"
#include "Memory/IBuffer.h"
#include "System/Noncopyable.h"
#include "System/Uint24_t.h"
#include "System/Uint48_t.h"


namespace memory {

class BufferUtilities final {
 public:
  static const size_t npos;

 public:
  BufferUtilities();
  ~BufferUtilities();

  static void GetUnsignedValue(
      const std::shared_ptr<const IBuffer>& buffer, size_t offset, size_t length, void* outputValue);

  static std::shared_ptr<Buffer> CreateBufferWithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const void* data, size_t size);

  static std::shared_ptr<Buffer> CreateBufferWithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const std::shared_ptr<const IBuffer>& iBuffer);

  static std::shared_ptr<Buffer> CreateBufferWithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const std::string& data);

  static std::shared_ptr<Buffer> CreateBufferWithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const std::vector<uint8_t>& bytesVector);

  static std::shared_ptr<const DirectPointer> GetDirectPointerOrAllocateCopy(
      const std::shared_ptr<const IBuffer>& iBuffer, std::allocator<uint8_t> allocator);

  static std::shared_ptr<const DirectPointer> GetDirectPointerOrAllocateCopy(
      const std::shared_ptr<const IBuffer>& iBuffer, std::allocator<uint8_t> allocator, size_t offset, size_t length);

  static void BufferToStream(std::ostream* stream, const std::shared_ptr<const memory::IBuffer>& buffer);
  static void Buffer2ViewToStream(std::ostream* stream, const memory::Buffer2View<const uint8_t*>& bufferView);
  static std::string BufferToString(const std::shared_ptr<const memory::IBuffer>& buffer);

  static void CopyIBuffer(
      const std::shared_ptr<Buffer>& dst,
      size_t dstOffset,
      const std::shared_ptr<const IBuffer>& src,
      size_t srcOffset,
      size_t length);
  static void CopyIBuffer(uint8_t* dst, const std::shared_ptr<const IBuffer>& src, size_t srcOffset, size_t length);
  static void CopyIBuffer(
      uint8_t* dst, size_t dstOffset, const std::shared_ptr<const IBuffer>& src, size_t srcOffset, size_t length);
  // TODO(PJ): Write Unit test for this!
  static void CopyIBuffer(const std::shared_ptr<Buffer>& dst, size_t dstOffset, const void* src, size_t length);
  static void AssertBufferOffset(const size_t bufferSize, const size_t offset, const size_t length);

  static memory::Buffer2View<const uint8_t*> GetLine(
      const memory::Buffer2View<const uint8_t*>& bufferView, memory::Buffer2View<const uint8_t*>* remainingBuffer);

  static int CompareIBuffer(const std::shared_ptr<const IBuffer>& iBuffer, const std::string& data);
  static int CompareIBuffer(const std::shared_ptr<const IBuffer>& iBuffer, const void* data, size_t length);

  static int CompareIBuffer(
      const std::shared_ptr<const IBuffer>& iBuffer1, const std::shared_ptr<const IBuffer>& iBuffer2);

  static int CompareIBuffer(
      const std::shared_ptr<const IBuffer>& iBuffer1, const std::shared_ptr<const IBuffer>& iBuffer2, size_t length);

  static size_t Find(const std::shared_ptr<const IBuffer>& iBuffer, uint8_t value, size_t index = 0);
  static size_t Find(const memory::Buffer2View<const uint8_t*>& bufferView, uint8_t value, size_t index = 0);
  static size_t FindBuffer(
      const std::shared_ptr<const IBuffer>& haystack, const uint8_t* needle, size_t needleLength, size_t index = 0);

  // TVisitor should have the following signature: [](const uint8_t* data, size_t length){}
  template <typename TIterator, typename TVisitor>
  static void VisitBufferIterator(const TIterator& iterator, TVisitor&& visitor);

  // TVisitor should have the following signature: [](const uint8_t* data, size_t length){}
  template <typename TIterator, typename TVisitor>
  static void VisitBufferIterator(const TIterator& iterator, const size_t offset, TVisitor&& visitor);

  // TVisitor should have the following signature: [](const uint8_t* data, size_t length){}
  template <typename TIterator, typename TVisitor>
  static void VisitBufferIterator(
      const TIterator& iterator, const size_t offset, const size_t length, TVisitor&& visitor);

  static void GetUnsignedValue(
      const memory::Buffer2View<const uint8_t*>& bufferView, size_t offset, size_t length, void* outputValue);

  static Buffer2 CreateBuffer2WithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const void* data, size_t size);

  static Buffer2 CreateBuffer2WithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const Buffer2View<const uint8_t*>& bufferView);

  static Buffer2 CreateBuffer2WithData(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const std::string& data);

  static std::string Buffer2ViewToString(const Buffer2View<const uint8_t*>& bufferView);

  static void ZeroFillBuffer2View(
      const Buffer2View<uint8_t*>& destination, const size_t destinationOffset, const size_t length);

  static void ZeroFillBuffer2View(const Buffer2View<uint8_t*>& destination, const size_t length);

  static int CompareBuffer2View(const memory::Buffer2View<const uint8_t*>& bufferView, const std::string& data);
  static int CompareBuffer2View(const memory::Buffer2View<const uint8_t*>& bufferView, const void* data, size_t length);

  static int CompareBuffer2View(
      const memory::Buffer2View<const uint8_t*>& bufferView1, const memory::Buffer2View<const uint8_t*>& bufferView2);

  static int CompareBuffer2View(
      const memory::Buffer2View<const uint8_t*>& bufferView1,
      const memory::Buffer2View<const uint8_t*>& bufferView2,
      size_t length);

 private:
  struct CopyIBufferContext final {
    uint8_t* dst;
    size_t srcOffsetLeft;
    size_t lengthLeft;

    CopyIBufferContext(uint8_t* _dst, size_t _srcOffsetLeft, size_t _lengthLeft)
        : dst(_dst), srcOffsetLeft(_srcOffsetLeft), lengthLeft(_lengthLeft) {}
  };

  DISALLOW_COPY_AND_ASSIGN(BufferUtilities);
};

}  // namespace memory

