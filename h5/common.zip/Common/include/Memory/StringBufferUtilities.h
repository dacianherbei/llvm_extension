
#pragma once

#include "Memory/Buffer2.h"
#include "Memory/IBuffer.h"
#include "System/Noncopyable.h"


namespace memory {

class StringBufferUtilities {
 public:
  StringBufferUtilities();
  ~StringBufferUtilities();

  static std::string ToAsciiString(const std::shared_ptr<const IBuffer>& buffer);
  static std::string ToAsciiString(const std::shared_ptr<const IBuffer>& buffer, size_t numberOfCharactersToRead);
  static std::string ToAsciiString(const memory::Buffer2View<const uint8_t*>& view);
  static std::string ToAsciiString(const memory::Buffer2View<const uint8_t*>& buffer, size_t numberOfCharactersToRead);

 private:
  DISALLOW_COPY_AND_ASSIGN(StringBufferUtilities);
};

}  // namespace memory

