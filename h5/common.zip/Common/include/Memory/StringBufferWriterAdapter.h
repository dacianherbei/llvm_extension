
#pragma once

#include <memory>
#include <string>

#include "Memory/BufferFactory.h"
#include "Memory/IBufferWriter.h"
#include "System/Noncopyable.h"


namespace memory {

class StringBufferWriterAdapter final {
 public:
  StringBufferWriterAdapter(
      const std::shared_ptr<const BufferFactory>& bufferFactory, const std::shared_ptr<IBufferWriter>& bufferWriter);
  ~StringBufferWriterAdapter();

  size_t Write();
  size_t Write(const std::string& stringToWrite);

  template <typename T>
  StringBufferWriterAdapter& operator<<(const T& in) {
    stringStream_ << in;
    return *this;
  }

 private:
  const std::shared_ptr<const BufferFactory> bufferFactory_;
  const std::shared_ptr<IBufferWriter> bufferWriter_;
  std::ostringstream stringStream_;

 private:
  DISALLOW_COPY_AND_ASSIGN(StringBufferWriterAdapter);
};

}  // namespace memory

