
#pragma once

#include <memory>
#include <unordered_set>

#include "Math/ThroughputCalculatorsFactory.h"
#include "System/Noncopyable.h"
#include "Threading/IWorkloadMeterStatisticsCalculator.h"


namespace threading {

class WorkloadMeterStatisticsCalculator final : public IWorkloadMeterStatisticsCalculator {
 public:
  WorkloadMeterStatisticsCalculator(
      const std::string& description,
      const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
      const std::shared_ptr<const math::ThroughputCalculatorsFactory>& throughputCalculatorsFactory,
      const std::shared_ptr<logging::Logger>& logger);
  ~WorkloadMeterStatisticsCalculator() override;

  void MeasureWorkPerformed(const char* const description, const size_t workPerformed) override;

 private:
  static const std::chrono::milliseconds kLongTermPollingPeriod;
  static const std::chrono::milliseconds kShortTermPollingPeriod;

  const std::string description_;
  const std::shared_ptr<const math::ThroughputCalculatorsFactory> throughputCalculatorsFactory_;
  const std::shared_ptr<logging::Logger> logger_;

  std::unordered_set<std::string> stats_;
  std::shared_ptr<math::ThroughputCalculators<std::string>> longTermStatisticsCalculator_;
  std::shared_ptr<math::ThroughputCalculators<std::string>> shortTermStatisticsCalculator_;
  std::shared_ptr<math::ThroughputCalculators<std::string>> longTermStatisticsCountCalculator_;
  std::shared_ptr<math::ThroughputCalculators<std::string>> shortTermStatisticsCountCalculator_;

 private:
  void LogStatistics(
      const logging::LogLevel logLevel,
      const std::chrono::duration<double>& pollingPeriod,
      const std::unordered_map<std::string, math::ThroughputCalculation<>>& throughputs) const;

  DISALLOW_COPY_AND_ASSIGN(WorkloadMeterStatisticsCalculator);
};

}  // namespace threading

