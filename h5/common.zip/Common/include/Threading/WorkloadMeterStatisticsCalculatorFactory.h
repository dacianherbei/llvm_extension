
#pragma once

#include <memory>

#include "System/Noncopyable.h"
#include "System/ForwardDeclare.h"
#include "Threading/IWorkloadMeterStatisticsCalculator.h"
#include "Threading/WorkloadMeterStatisticsCalculator.h"


namespace threading {

class WorkloadMeterStatisticsCalculatorFactory final {
 public:
  WorkloadMeterStatisticsCalculatorFactory(
      const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
      const std::shared_ptr<const math::ThroughputCalculatorsFactory>& throughputCalculatorsFactory,
      const std::shared_ptr<logging::Logger>& logger);
  ~WorkloadMeterStatisticsCalculatorFactory();

  std::shared_ptr<IWorkloadMeterStatisticsCalculator> CreateWorkloadMeterStatisticsCalculator(
      const std::string& description) const;

 private:
  const std::shared_ptr<const environment::ITimeProvider> timeProvider_;
  const std::shared_ptr<const math::ThroughputCalculatorsFactory> throughputCalculatorsFactory_;
  const std::shared_ptr<logging::Logger> logger_;

 private:
  DISALLOW_COPY_AND_ASSIGN(WorkloadMeterStatisticsCalculatorFactory);
};

}  // namespace threading

