
#pragma once

#include <map>

#include "Threading/DispatcherTagType.h"
#include "Threading/IWorkloadProvider.h"


namespace threading {

using WorkloadsByDispatcher = std::map<threading::DispatcherTagType, IWorkloadProvider::Workloads>;

}  // namespace threading

