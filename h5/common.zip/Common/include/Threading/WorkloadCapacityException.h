
#pragma once

#include "System/Exception.h"


namespace threading {

class WorkloadCapacityException final : public system::Exception {
 public:
  using Exception::Exception;
};

}  // namespace threading

