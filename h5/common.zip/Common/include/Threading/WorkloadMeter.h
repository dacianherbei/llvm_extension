
#pragma once

#include <atomic>
#include <chrono>
#include <memory>

#include <boost/circular_buffer.hpp>

#include "System/Noncopyable.h"
#include "System/ForwardDeclare.h"
#include "System/ScopeExit.h"
#include "Threading/IWorkloadProvider.h"
#include "Threading/ThreadAsserter.h"

_FORWARD_DECLARE_CLASS(()(environment), ITimeProvider)
_FORWARD_DECLARE_CLASS(()(threading), IWorkloadMeterStatisticsCalculator)
_FORWARD_DECLARE_CLASS(()(threading), WorkloadMeterStatisticsCalculatorFactory)


namespace threading {

class WorkloadMeter final : public IWorkloadProvider, public std::enable_shared_from_this<IWorkloadProvider> {
 public:
  using TimePoint = environment::ITimeProvider::SteadyClockTimePoint;

 public:
  static constexpr size_t kMaxWorkPerformedSamples = 1000000;

 public:
  static std::shared_ptr<WorkloadMeter> CreateWorkloadMeter(
      const std::string& threadName,
      const std::shared_ptr<const WorkloadMeterStatisticsCalculatorFactory>& workloadMeterStatisticsCalculatorFactory,
      const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
      const Duration& shortTermWindowSize = std::chrono::seconds(1),
      const Duration& longTermWindowSize = std::chrono::seconds(10));

  ~WorkloadMeter() override = default;

  system::ScopeExit MeasureWorkPerformed(const char* const description);

  void UpdateWorkloadWindowsNow();

  Workloads GetWorkloads() const override;

 private:
  struct Work final {
    TimePoint started;
    Duration duration;
    const char* description;

    Work(TimePoint&& _started, Duration&& _duration, const char* const _description);
    Work(const Work&) = default;
  };

  using WorkPerformedBuffer = boost::circular_buffer<Work>;

  struct WorkPerformed final {
    WorkPerformedBuffer buffer;
    WorkPerformedBuffer::iterator shortTermWindowStart;
    WorkPerformedBuffer::iterator longTermWindowStart;

    WorkPerformed();
  };

 private:
  const std::shared_ptr<const environment::ITimeProvider> timeProvider_;
  const Duration shortTermWindowSize_;
  const Duration longTermWindowSize_;
  const threading::ThreadAsserter threadAsserter_;
  const std::shared_ptr<threading::IWorkloadMeterStatisticsCalculator> workloadMeterStatisticsCalculator_;

  WorkPerformed workPerformed_;
  std::atomic<Duration::rep> totalWorkPerformedInShortTermWindow_;
  std::atomic<Duration::rep> totalWorkPerformedInLongTermWindow_;
  std::atomic<size_t> totalUnitsOfWorkPerformedInShortTermWindow_;
  std::atomic<size_t> totalUnitsOfWorkPerformedInLongTermWindow_;

 private:
  WorkloadMeter(
      const std::string& threadName,
      const std::shared_ptr<const WorkloadMeterStatisticsCalculatorFactory>& workloadMeterStatisticsCalculatorFactory,
      const std::shared_ptr<const environment::ITimeProvider>& timeProvider,
      const Duration& shortTermWindowSize,
      const Duration& longTermWindowSize);

  void AddWork(Work&& workPerformed);
  void UpdateWorkloadWindows(const TimePoint& now);
  IWorkloadProvider::Workload GetWorkload(
      const size_t numberCalls, const Duration& windowSize, const Duration::rep& totalWorkPerformedInWindow) const;
  void EnsureIteratorWithinWindow(
      const TimePoint& windowStart,
      WorkPerformedBuffer::iterator* iterator,
      std::atomic<Duration::rep>* totalDuration,
      std::atomic<size_t>* totalNumberOfCalls) const;
  void MakeRoomInWorkPerformedBufferForCurrentThread();
  size_t GetCurrentNumberOfItemsInLongTermWindow() const;
  DISALLOW_COPY_AND_ASSIGN(WorkloadMeter);
};

}  // namespace threading

